<?php /* ATOM/digitalnature */

 //  Singular template, usually used to display a single post.
 //  For custom post types, a template named single-post_type.php will have priority over this one.

 get_header();
?>

<!-- main content: primary + sidebar(s) -->
<div id="mask-3" class="clear-block">
  <div id="mask-2">
    <div id="mask-1">

      <!-- primary content -->
      <div id="primary-content">
        <div class="blocks clear-block">


          <div id="bbp-view-<?php bbp_view_id(); ?>" class="bbp-view">

            <h1 class="title"><?php bbp_view_title(); ?></h1>

            <div class="entry-content">

              <?php

                $app->action('before_primary');
                bbp_breadcrumb();
                bbp_set_query_name('bbp_view');

                if(bbp_view_query())                  
                  bbp_get_template_part('bbpress/loop', 'topics');                  

                else
                  _ae('No topics found.');

                bbp_reset_query_name();

                $app->action('after_primary');
              ?>

            </div>
          </div>

        </div>
      </div>
      <!-- /primary content -->

      <?php get_sidebar(); ?>

    </div>
  </div>
</div>
<!-- /main content -->

<?php get_footer(); ?>
