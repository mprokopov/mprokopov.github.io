<?php
/*
  Mystique/digitalnature

  This file demonstrates the usage of internal pages, with an tag clould page.
*/
?>


<?php

  // since this page doesn't reside in the db, we manually set a title for it; this is requried
  $app->setDocumentTitle('Tags');

  $tags = AtomWidgetTagCloud::tagCloud(array(
    'taxonomy'       => 'post_tag',
    'number'         => 200,
    'smallest'       => 8,
    'largest'        => 48,
    'gradient_start' => 'cccccc',
    'gradient_end'   => '333333',
  ));


  get_header();
?>

  <!-- main content: primary + sidebar(s) -->
  <div id="mask-3" class="clear-block">
   <div id="mask-2">
    <div id="mask-1">
             
      <!-- primary content -->
      <div id="primary-content">
       <div class="blocks clear-block">

        <?php $app->action('before_primary'); ?>
         <h1 class="title"><?php _ae('Tag Clould'); ?></h1>

         <p><?php printf(_a('This is a list of the most used tags on %s.'), get_bloginfo('name')); ?></p>
         
         <div class="tagcloud large">
           <?php echo $tags; ?>
         </div>

        <?php $app->action('after_primary'); ?>

       </div>
      </div>
      <!-- /primary content -->

      <?php get_sidebar(); ?>
    </div>
   </div>
  </div>
  <!-- /main content -->

<?php get_footer(); ?>
