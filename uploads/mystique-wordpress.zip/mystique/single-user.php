<?php /* ATOM/digitalnature */

 //  Singular template, usually used to display a single post.
 //  For custom post types, a template named single-post_type.php will have priority over this one.

 get_header();
?>

<!-- main content: primary + sidebar(s) -->
<div id="mask-3" class="clear-block">
  <div id="mask-2">
    <div id="mask-1">

      <!-- primary content -->
      <div id="primary-content">
        <div class="blocks clear-block">

          <?php

            $app->action('before_primary');
            do_action('bbp_template_notices');

            // Profile details
            bbp_get_template_part('bbpress/user', 'details');

            // Subscriptions
            bbp_get_template_part('bbpress/user', 'subscriptions');

            // Favorite topics
            bbp_get_template_part('bbpress/user', 'favorites');

            // Topics created
            bbp_get_template_part('bbpress/user', 'topics-created');

            $app->action('after_primary');
          ?>

        </div>
      </div>
      <!-- /primary content -->

      <?php get_sidebar(); ?>

    </div>
  </div>
</div>
<!-- /main content -->

<?php get_footer(); ?>
