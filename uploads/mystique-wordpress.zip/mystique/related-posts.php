<?php /* ATOM/digitalnature */

   // Renders the "related posts" list (optional meta tab).
   // You can use any of the AtomPost ($app->post) methods within the iterator below, even do hierarchical related post queries...
   //
   // Notes:
   //  - The related post query can be altered with setContextArgs('related_posts', ...)
   //  - Just like in other Atom-exclusive templates, the global $post variable is not initialized by default;
   //    if you want to use it make sure you change $post below with something else to avoid conflicts, or just call $GLOBALS['post']...

 ?>

 <?php if($app->post->related): ?>

  <ol>
    <?php foreach($app->post->related as $post): ?>
    <li><a href="<?php $post->URL(); ?>" title="<?php printf(_a('Permanent Link: %s'), $post->getTitle()); ?>"><?php $post->Title(); ?></a></li>
    <?php endforeach; ?>
  </ol>

  <?php $app->controls('post-related'); ?>

 <?php else: ?>

  <p><?php _ae("Didn't find any related posts :("); ?></p>

 <?php endif; ?>
