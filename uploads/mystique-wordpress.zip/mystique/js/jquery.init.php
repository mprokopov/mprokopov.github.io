<?php
/**
 * jQuery initialization (ATOM framework)
 *
 * @package ATOM
 * @subpackage Template
 */

// get search query, if any
$referer = isset($_SERVER['HTTP_REFERER']) ? urldecode($_SERVER['HTTP_REFERER']) : false;

// -- @todo
if(preg_match('@^http://(.*)?\.?(google|yahoo|lycos).*@i', $referer)){
  //$search_query = $comment_filter_query = esc_attr(strip_tags(preg_replace('/^.*(&q|query|p)=([^&]+)&?.*$/i','$2', $referer)));
}else{
  //$search_query = get_search_query();
  //$comment_filter_query = Atom::app()->commentSearch();
}

// load separately as a javascript document ? -- removed, not worth making a new request + possible cache issues...
//if(Atom::app()->options('jquery_init_query')):
//  header("content-type: application/x-javascript");
//  header("Cache-Control: no-store, no-cache, must-revalidate");
//  header("Pragma: no-cache");
//endif;
?>

  /*<![CDATA[*/
  var blog_url = '<?php echo home_url('/'); ?>';

  jQuery(document).ready(function($){

    var atom_init = function(){

     <?php if($app->options('effects')): ?>
      $('body').removeClass('no-fx');
      $('.fadeThis').fadeLinks();
      $('.nudge').nudgeLinks();
      $('a.go-top').goTopControl();
     <?php endif; ?>

      $('.nav ul.menu').superfish();
      $('a.screenshot').webShots();
      $('.accordion, .collapsible').CollapsibleMenu();
      $('.toggle').toggleVisibility();
      $('a.tt').bubble();
      <?php if(is_singular() && comments_open()): ?>
      $('#comments').commentControls();
      <?php if(!empty($comment_filter_query)): ?>$('#comments').highlightText('<?php echo $comment_filter_query; ?>', 1, 'highlight'); <?php endif; ?>
      <?php endif; ?>

      $('.clearField').clearField();

      $('form').submit(function(){
        $('.clearField', this).each(function(){ $(this).clearFieldCheck(); });
        return true;
      });

      $('form').each(function(){
        $('a.submit', this).click(function(){ $(this).parents('form').submit(); });
      });

     <?php if(!empty($search_query)): ?>
      $('.posts').highlightText('<?php echo $search_query; ?>', 1, 'highlight');
     <?php endif; ?>

     $('.tabs').tabs();

     $('.iSlider').imageSlider();

     <?php if($app->options('lightbox')): // enable lightbox for any link which reference ends in jpg/gif/png ?>
      var images = $('a').filter(function(){
        return !!this.href.match(/.+\.(jpg|jpeg|png|gif)$/i);
      }).each(function(){
        this.rel += 'group-' + $(this).parents('div').index();
      });
      images.fancybox();
      $('a[rel="lightbox"]').fancybox();
      $('a').bind('href_updated', function(){
        if(this.href.match(/.+\.(jpg|jpeg|png|gif)$/i)) $(this).fancybox();
      });
     <?php endif; ?>


     <?php // read more - expand content ?>
     $('#related-posts').delegate('a.post-related', 'click', function(event){
       event.preventDefault();

       var related = $(this).parents('#related-posts');

       $.ajax({
         url: blog_url,
         type: 'GET',
         context: this,
         data: ({
           atom: 'more_related_posts',
           post_id: $(this).data('post'),
           offset: $(this).data('offset'),
         }),
         beforeSend: function(){
            $(this).text('<?php _ae('Loading...') ?>');
         },
         success: function(data){
            $(data).find('li').appendTo('#related-posts ol');
            $(this).parents('.sections').height($('#related-posts ol').height() + 15);
            $(this).remove();

          }
       });
     });




     <?php /*/ read more - expand content - disabled until I make this work correctly ?>
     $('.posts').delegate('.post-content .more-link', 'click', function(event){
       event.preventDefault();

       $.ajax({
         url: blog_url,
         type: 'GET',
         context: this,
         data: ({
           atom: 'read_more',
           post_id: $(this).data('post')
         }),
         beforeSend: function(){
            $(this).text('<?php _ae('Loading...') ?>');
         },
         success: function(data){
            $(this).closest('.post-content').html(data);
          }
       });
     });
     <?php /*/ ?>

     <?php // single post navi ?>
     $('.page-navi.single a').click(function(event){
       event.preventDefault();
       $.ajax({
         url: $(this).attr('href'),
         type: 'GET',
         context: this,
         beforeSend: function(){
            $(this).addClass('loading');
         },
         success: function(data){
            $(data).find('.posts .hentry').hide().appendTo($('.posts')).fadeIn(333);
            var new_page = $(data).find('.page-navi.single a').attr('href');
            if(new_page) $(this).attr('href', new_page).removeClass('loading'); else $(this).remove();
          }
       });
     });


     <?php if($app->options('generate_thumbs')): // auto resize thumbs -- @todo find a different way to use this in ajaxed-widgets than livequery()  ?>
     $('span.no-img.regen').livequery(function(){
        var id = $(this).attr('id').split(/-/g).slice(1);
        $(this).removeClass("regen");
        $.ajax({
          url: blog_url,
          type: "GET",
          context: this,
          data: ({
            atom: 'update_thumb',
            attachment_size: $(this).data('size'),
            post_id: id[0],
            thumb_id: id[1]
            }),
          beforeSend: function() { $(this).addClass('loading'); },
          success: function(data) {
            if(data != '') $(this).replaceWith(data); else $(this).removeClass('loading');
          }
    	});
     });
     <?php endif; ?>


     <?php if($app->previewMode()): // communication between the theme options page and the preview document ?>

     $('#page').gridOverlay();

     <?php if($app->isOptionEnabled('background_color')): ?>
     var current_bg_image = $("<?php echo $app->options('background_image_selector'); ?>").css("background-image");
     pm.bind("background-color", function(data){
        if(data != '#000000'){
         $("<?php echo $app->options('background_color_selector'); ?>").css("background-color", data);
         if(!$('body').hasClass('custom-bg')) $("<?php echo $app->options('background_image_selector'); ?>").css("background-image", "none");
       }else{
         $("<?php echo $app->options('background_color_selector'); ?>").css("background-color", "");
         if(!$('body').hasClass('custom-bg')) $("<?php echo $app->options('background_image_selector'); ?>").css("background-image", current_bg_image);

       }
     });
     <?php endif; ?>

     <?php if($app->isOptionEnabled('color_scheme')): ?>
     pm.bind("color-scheme", function(data){
       $('link#<?php echo ATOM; ?>-core-css, link#<?php echo ATOM; ?>-style-css').attr('disabled', 'disabled'); // we need this so the style unloads from browser memory
       $('link#<?php echo ATOM; ?>-core-css, link#<?php echo ATOM; ?>-style-css').remove();
       if(data != '')
         $('head').append('<link rel="stylesheet" id="<?php echo ATOM; ?>-core-css" href="<?php echo $app->get('theme_url'); ?>/css/core.css" type="text/css" />');
         $('head').append('<link rel="stylesheet" id="<?php echo ATOM; ?>-style-css" href="<?php echo $app->get('theme_url'); ?>/css/style-'+data+'.css" type="text/css" />');
     });
     <?php endif; ?>

     <?php if($app->isOptionEnabled('layout')): ?>

     pm.bind("layout", function(data) {
       $('body').attr('class',
              function(i, c){
                return c.replace(/\bc\S+/g, '');
              });
       $("body").addClass(data);
     });

     pm.bind("page_width", function(data){
       $('body').removeClass("fluid fixed");
       $("body").addClass(data);
      });

     pm.bind("page_width_max", function(data){
       data = parseInt(data);
       if(data > 400) $(".page-content").css("max-width", data+'px');
     });

     pm.bind("dimensions", function(data){
       var s = data.sizes.split(';');
       s[0] = parseInt(s[0]);
       s[1] = parseInt(s[1]);
       var unit = data.unit;
       var gs = data.gs;
       switch(data['layout']){
          case 'c1':
            $('#primary-content').css({'width': gs+unit, 'left': '0'});
            $('#mask-1').css({'right': 0});
            $('#mask-2').css({'right': 0});
            break;
          case 'c2left':
            $('#primary-content').css({'width': gs-s[0]+unit, 'left': gs+unit});
            $('#sidebar').css({'width': s[0]+unit, 'left': '0'});
            $('#mask-1').css({'right': gs-s[0]+unit});
            $('#mask-2').css({'right': 0});
            break;
          case 'c2right':
            $('#primary-content').css({'width': gs-(gs-s[0])+unit, 'left': gs-s[0]+unit});
            $('#sidebar').css({'width': gs-s[0]+unit, 'left': gs-s[0]+unit});
            $('#mask-1').css({'right': gs-s[0]+unit});
            $('#mask-2').css({'right': 0});
            break;
          case 'c3':
            $('#primary-content').css({'width': (gs-s[0]-(gs-s[1]))+unit, 'left': gs+unit});
            $('#sidebar').css({'width': s[0]+unit, 'left': gs-s[1]+unit});
            $('#sidebar2').css({'width': gs-s[1]+unit, 'left': (gs-s[0])+unit});
            $('#mask-2').css({'right': gs-s[1]+unit});
            $('#mask-1').css({'right': ((gs-s[0])-(gs-s[1]))+unit});
            break;
          case 'c3left':
            $('#primary-content').css({'width': (gs-s[1])+unit, 'left': (gs+(s[1]-s[0]))+unit});
            $('#sidebar').css({'width': s[0]+unit, 'left': (s[1]-s[0])+unit});
            $('#sidebar2').css({'width': (s[1]-s[0])+unit, 'left': (s[1]-s[0])+unit});
            $('#mask-2').css({'right': (gs-s[1])+unit});
            $('#mask-1').css({'right': (s[1]-s[0])+unit});
            break;
          case 'c3right':
            $('#primary-content').css({'width': s[0]+unit, 'left': ((gs-s[0]-(gs-s[1]))+(gs-s[1]))+unit});
            $('#sidebar').css({'width': (gs-s[0]-(gs-s[1]))+unit, 'left': (gs-s[0])+unit});
            $('#sidebar2').css({'width': (gs-s[1])+unit, 'left': (gs-s[0])+unit});
            $('#mask-2').css({'right': (gs-s[1])+unit});
            $('#mask-1').css({'right': (s[1]-s[0])+unit});
            break;
        }
     });

     <?php endif; ?>

     <?php if($app->isOptionEnabled('logo')): ?>
     pm.bind("logo", function(data) {
       $("#logo a img").remove();
       if (data != 'remove')
         $("#logo a").html('<img src="'+data+'" />');
       else $("#logo a").html('<?php echo apply_filters('atom_logo_title', get_bloginfo('name')); ?>');
     });
     <?php endif; ?>

     <?php if($app->isOptionEnabled('background_image')): ?>
     pm.bind("background_image", function(data){
       if (data != 'remove'){
         $("<?php echo $app->options('background_image_selector'); ?>").css('background-image', 'url("'+data+'")');
         $("body").removeClass("custom-bg");
       }else{
         $("<?php echo $app->options('background_image_selector'); ?>").css('background-image', 'none');
         $("body").addClass("custom-bg");
       }
     });
     <?php endif; ?>

     $('body a').each(function(){
       var link = $(this).attr('href'); // remove all links to other pages
       if(link && link.indexOf('#') != 0) $(this).attr('href', '#');
     });

     pm({ // notify the parent document that the current document has loaded
       target: parent,
       type: 'themepreview-load',
       data: true
     });

     <?php endif; ?>

     <?php $app->action("jquery_init"); // extra code may be added by widgets, plugins etc. ?>

    };

    atom_init();

  });




  /* ]]> */