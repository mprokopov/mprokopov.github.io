<?php

/**
 * Atom Meta Widget
 *
 * Displays login/logout/rss/credit links
 *
 * @since 1.0
 */


class AtomWidgetMeta extends AtomWidget{

  public function AtomWidgetMeta(){
    $this->WP_Widget('atom-meta', _a('Meta'), array('classname' => 'meta', 'description' => _a("Log in/out, admin, feed and WordPress links")));

    // default settings
    $this->setDefaults(array(
      'title'        => _a("Meta"),
      'login'        => true,
      'rss_posts'    => true,
      'rss_comments' => true,
      'wp'           => true,
      'dn'           => false,
    ));
  }

  public function widget($args, $instance){
    extract($args);
    $instance = wp_parse_args($instance, $this->getDefaults());
    $title = apply_filters('widget_title', $instance['title'], $instance, $this->id_base);

    echo $before_widget;
    if($title) echo $before_title.$title.$after_title;
    ?>
    <div class="box">
      <ul>

        <?php if($instance['login']): ?>
        <?php wp_register(); ?>
        <li><?php wp_loginout(); ?></li>
        <?php endif; ?>

        <?php if($instance['rss_posts']): ?>
        <li><a href="<?php bloginfo('rss2_url'); ?>" title="<?php _ae('Syndicate this site using RSS 2.0'); ?>"><?php _ae('Entries <abbr title="Really Simple Syndication">RSS</abbr>'); ?></a></li>
        <?php endif; ?>

        <?php if($instance['rss_comments']): ?>
        <li><a href="<?php bloginfo('comments_rss2_url'); ?>" title="<?php _ae('The latest comments to all posts in RSS'); ?>"><?php _ae('Comments <abbr title="Really Simple Syndication">RSS</abbr>'); ?></a></li>
        <?php endif; ?>

        <?php if($instance['wp']): ?>
        <li><a href="http://wordpress.org/" title="<?php _ae('Powered by WordPress, state-of-the-art semantic personal publishing platform.'); ?>">WordPress.org</a></li>
        <?php endif; ?>

        <?php if($instance['dn']): ?>
        <li><a href="http://digitalnature.eu/" title="<?php _ae('Theme developed by digitalnature'); ?>">digitalnature.eu</a></li>
        <?php endif; ?>

        <?php wp_meta(); ?>
      </ul>
    </div>
    <?php

    echo $after_widget;
  }

  public function update($new_instance, $old_instance){

    $instance['title']         = esc_attr($new_instance['title']);
    $instance['login']         = (bool)$new_instance['login'];
    $instance['rss_posts']     = (bool)$new_instance['rss_posts'];
    $instance['rss_comments']  = (bool)$new_instance['rss_comments'];
    $instance['wp']            = (bool)$new_instance['wp'];
    $instance['dn']            = (bool)$new_instance['dn'];

    return $instance;
  }

  public function form($instance){
    $instance = wp_parse_args($instance, $this->getDefaults());
    ?>
    <div <?php $this->formClass(); ?>>
    <p>
     <label for="<?php echo $this->get_field_id('title'); ?>"><?php _ae('Title:'); ?></label>
     <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($instance['title']); ?>" />
    </p>

    <p><strong><em><?php _ae("Links to display:"); ?></em></strong></p>

    <p>
     <input type="checkbox" <?php checked(isset($instance['login']) ? (bool)$instance['login'] : false); ?> id="<?php echo $this->get_field_id('login'); ?>" name="<?php echo $this->get_field_name('login'); ?>" />
     <label for="<?php echo $this->get_field_id('login'); ?>"><?php _ae('Login / Logout / Site Admin'); ?></label>

     <br />

     <input type="checkbox" <?php checked(isset($instance['rss_posts']) ? (bool)$instance['rss_posts'] : false); ?> id="<?php echo $this->get_field_id('rss_posts'); ?>" name="<?php echo $this->get_field_name('rss_posts'); ?>" />
     <label for="<?php echo $this->get_field_id('rss_posts'); ?>"><?php _ae('Post RSS'); ?></label>

     <br />

     <input type="checkbox" <?php checked(isset($instance['rss_comments']) ? (bool)$instance['rss_comments'] : false); ?> id="<?php echo $this->get_field_id('rss_comments'); ?>" name="<?php echo $this->get_field_name('rss_comments'); ?>" />
     <label for="<?php echo $this->get_field_id('rss_comments'); ?>"><?php _ae('Comment RSS'); ?></label>

     <br />

     <input type="checkbox" <?php checked(isset($instance['wp']) ? (bool)$instance['wp'] : false); ?> id="<?php echo $this->get_field_id('wp'); ?>" name="<?php echo $this->get_field_name('wp'); ?>" />
     <label for="<?php echo $this->get_field_id('wp'); ?>"><?php _ae('External: WordPress.org'); ?></label>

     <br />

     <input type="checkbox" <?php checked(isset($instance['dn']) ? (bool)$instance['dn'] : false); ?> id="<?php echo $this->get_field_id('dn'); ?>" name="<?php echo $this->get_field_name('dn'); ?>" />
     <label for="<?php echo $this->get_field_id('dn'); ?>"><?php _ae('External: digitalnature.eu'); ?></label>

     <br />

    </p>

    </div>
    <?php
  }
}