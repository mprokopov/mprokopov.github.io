<?php
/**
 * AJAX requests (ATOM framework)
 *
 * @link http://digitalnature.eu
 *
 * @package ATOM
 * @subpackage Template
 *
 */


defined('ATOM') or die();

$app->action('ajax_requests'); // widget requests are hooked here



// retrieve avatar image when email address field changes (inside the comment form)
if($app->request('get_avatar')){
  $app->ajaxHeader();
  $email = isset($_GET['email']) ? sanitize_email($_GET['email']) : '';
  $name = isset($_GET['name']) ? sanitize_user($_GET['name']) : '';
  die($app->getAvatar($email, 48, false, $name));
}



// update thumbnails (regenerateThumbnail will do the check if regeneration is needed)
if($app->request('update_thumb')){
  $app->ajaxHeader();

  $size = esc_attr(strip_tags((string)$_GET['attachment_size']));
  if(AtomObjectPost::regenerateThumbnail(abs((int)$_GET['thumb_id']), $size)){
    $app->post = abs((int)$_GET['post_id']);
    $app->post->thumbnail($size);
  }
  die();
}



// echo full post content on 'read more' click -- @todo more testing
if($app->request('read_more')){
  $app->ajaxHeader();
  $post_id = isset($_GET['post_id']) ? abs((int)$_GET['post_id']) : false;
  if($post_id){
    $query = new WP_Query(array('p' => $post_id));
    if($query->have_posts()){
      $query->the_post();
      $app->post->content($app->options('post_content_mode'), array('limit' => 0));
    }
  }
  die();
}



// echo full post content on 'read more' click -- @todo more testing
if($app->request('more_related_posts')){
  $app->ajaxHeader();
  $post_id = isset($_GET['post_id']) ? abs((int)$_GET['post_id']) : false;
  $offset = isset($_GET['offset']) ? abs((int)$_GET['offset']) : false;
  if($post_id && $offset){

    $app->setCurrentPost($post_id);
    $app->post->setRelatedPostsQuery(array(
      'offset'          => $offset,
      'posts_per_page'  => 10000,  // all remaining posts from $offset -
    ));

    $app->template('related-posts');
  }
  die();
}



// comment karma rating
if($app->request('comment_karma') && is_user_logged_in() && $app->options('comment_karma')){
  $app->ajaxHeader();
  global $user_ID;

  list($rate, $comment_id) = explode('/', $_GET['karma']);

  $comment_id = abs((int)$comment_id);
  $comment = get_comment($comment_id);
  $karma = $comment->comment_karma;
  if($comment->user_id == $user_ID) // the user shouldn't see these messages unless they hack the html or something
    die(_a("You can't vote your own comment :("));

  $ratings = get_user_meta($user_ID, 'comment_ratings', true);
  $ratings = empty($ratings) ? array() : explode(',', $ratings);
  if(in_array($comment_id, $ratings)) die(_a('You can only vote once :)'));

  $unit = 1; // + $unit
  if($rate !== '+' && $rate !== '-') _ae('Invalid vote');
  $karma = ($rate !== '+') ? ($karma - $unit) : ($karma + $unit);

  //$query = $wpdb->query($wpdb->prepare("UPDATE {$wpdb->comments} SET comment_karma = comment_karma {$rate} {$unit} WHERE comment_ID = {$comment_id} LIMIT 1"));
  //$wpdb->update($wpdb->comments, array('comment_karma' => $karma), array('comment_ID' => $comment_id));
  $comment->comment_karma = $karma;
  if(!wp_update_comment((array)$comment)) die(_a('Failed.'));

  $ratings[] = $comment_id;
  $ratings = implode(',', $ratings); // we could also send it as a array, which will automatically be serialized... maybe explode() is faster?
  update_user_meta($user_ID, 'comment_ratings', $ratings);

  if($comment->user_id){
    $user_karma = (int)get_user_meta($comment->user_id, 'karma', true);
    $new_karma = ($rate == '+') ? ($user_karma + $unit) : ($user_karma - $unit);
    if($new_karma < 0) $new_karma = 0; // no negative karma
    update_user_meta($comment->user_id, 'karma', $new_karma);
  }
  die(($karma != 0) ? str_replace('-', '&#8722;', $karma) : '');
}



// get a single comment
if($app->request('get_comment')){
  $app->ajaxHeader();
  define('RETRIEVING_BURIED_COMMENT', true);
  $comment_id = abs((int)$_GET['comment_id']);
  $comment = get_comment($comment_id);
  $app->setCurrentComment($comment);
  $app->template('comment');
  die();
}



// retrieve avatar image when email address field changes (inside the comment form)
if($app->request('debug') && $app->options('debug')){

  require_once ABSPATH.'wp-admin/includes/file.php';
  require_once(ABSPATH.'wp-admin/includes/admin.php');

  ob_start();
  ?>
  <style>

   h2{
     margin: 10px 0 5px;
   }


  /* clearfix */
  .clear-block:after{
    content:".";
    display:block;
    clear:both;
    visibility:hidden;
    line-height:0;
    height:0;
  }
  </style>


  <?php
  $style = ob_get_flush();


  $output = array($style);

  $output[] = '<h1>Debug info</h1>';
  $output[] = sprintf('<h2>Environment:</h2>PHP %1$s / WordPress %2$s / %3$s (%4$s %5$s)',
     PHP_VERSION,
     $GLOBALS['wp_version'],
     ATOM,
     $app->get('theme_name'),
     $app->get('theme_version')
     );

  $fs_transport_status = true;

  if( function_exists('getmyuid') && function_exists('fileowner') ){
    $temp_file = wp_tempnam();
    if(getmyuid() != fileowner($temp_file)) $fs_transport_status = false;
    unlink($temp_file);
  }

  $fs_transport_status = $fs_transport_status ? ' <span style="color: #339900">OK</span>' : ' <span style="color: #ee4546">FAILED</span>';

  $output[] = '<h2>Prefered FS Transport:</h2> '.get_filesystem_method(get_option('ftp_credentials')).$fs_transport_status;


  $output[] = '<h2>Active plugins:<h2>';
  foreach(get_plugins() as $path => $plugin)
    if(is_plugin_active($path))
      $output[] = '<li><a href="'.$plugin['PluginURI'].'" target="_blank">'.$plugin['Name'].'</a> '.$plugin['Version'].'</li>';

  wp_die(implode('<br />', $output));
}




// get a list of comments -- @todo
if($app->request('get_comments')){
  $offset = (int)$_GET['offset'];
//    echo $offset;
//    global $withcomments; $withcomments = true;
      global $post;
 //   echo '<pre>';

      $comments = get_comments(array(
        'type' => 'comment',
        'post_id' => $post->ID,
        'status' => 'approve',
        'offset' => $offset,
        'number' => $app->options("ajax_comments_count")
      ));

//    print_r($comments);
//    print_r($wp_query->comments);
//echo $post->ID;    $comments = get_comments();
//       atom_comments($comments);
//     wp_list_comments();


  die();
}
