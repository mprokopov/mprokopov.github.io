<?php


abstract class AtomObject{

  public
    $data,
    $controls = array();  // links such as "print", "edit", "more" etc.


    
  public function __call($name, $args = array()){
    $getter = "get{$name}";

    if(method_exists($this, $getter)) echo call_user_func_array(array(&$this, $getter), $args); else throw new Exception("Method {$getter} is not defined");
  }



  /**
   * __get magic method
   *
   * @since 1.0
   */
  public function __get($name){
    $getter = "getCurrent{$name}";
    if(method_exists($this, $getter)) return $this->$getter();

    throw new Exception("Property {$getter} is not defined.");
  }



  /**
   * __set magic method
   *
   * @since 1.0
   */
  public function __set($name, $value){
    $setter = "setCurrent{$name}";
    if(method_exists($this, $setter)) return $this->$setter($value);

    throw new Exception("Property {$setter} is not defined.");
  }



  /**
   * Get a $data field
   *
   * @since 1.0
   *
   * @param mixed $field field to get
   * @return mixed field value
   */
  public function get($field){
    return (isset($this->data->$field)) ? $this->data->$field : false;
  }



  /**
  * Get the blog ID of the current object.
  * Only relevant within a "Atom Site-Wide Content" query
  *
  * @since 1.7
  */
  function getBlogID(){
    if(isset($this->data->blog_id))
      return $this->data->blog_id;

    return get_current_blog_id();
  }

  

  /**
   * Get a control link
   *
   * @since 1.0
   *
   * @param mixed $field field to get
   * @return array control
   */
  public function getControl($control){
    return (isset($this->controls[$control])) ? $this->controls[$control] : false;
  }

}