<?php

/**
 * The Author object
 *
 * @since 1.7
 *
 * @author digitalnature
 */
class AtomObjectAuthor extends AtomObject{

  private

    $name,
    $post_count,
    $posts_url,
    $feed,
    $avatar,              // array
    $description,

    $meta,                // array, author meta

    $karma;



  /**
   * The constructor.
   * Gets all the author info from the WP globals or the db, if necessary
   *
   * @since 1.7
   *
   * @param mixed $author Author ID, object. Anything else forces the use of WP's $authordata global
   */
  public function __construct($author = false){

    if(is_numeric($author)){
      $this->data = new WP_User($author);
      if(!is_a($this->data, 'WP_User'))
        throw new Exception("Failed to get data for author {$author}");

    }elseif(is_a($author, 'WP_User')){
      $this->data = $author;

    }else{

      if(!isset($GLOBALS['authordata']))
        $GLOBALS['authordata'] = get_userdata(1); // admin

      $this->data = &$GLOBALS['authordata'];
    }

  }



  /**
   * Get the current user ID
   *
   * @since 1.7
   *
   * @return int ID
   */
  public function getID(){
    return (int)$this->data->ID;
  }



  /**
   * Get a user meta field
   *
   * @since 1.7
   *
   * @param string $field Field
   * @return string User display name
   */
  public function getMeta($field){
    if(!isset($this->meta[$field]))
      $this->meta[$field] = get_the_author_meta($field, $this->data->ID);

    return $this->meta[$field];
  }



  /**
   * Get the current user display name
   *
   * @since 1.7
   *
   * @return string User display name
   */
  public function getName(){
    if(!isset($this->name))
      $this->name = apply_filters('the_author', $this->data->display_name);

    return $this->name;
  }



  /**
   * Get the post count of the current user.
   * Should be avoided in favour of count_many_users_posts() if using it inside a loop
   *
   * @since 1.7
   *
   * @return int Post count
   */
  public function getPostCount(){
    if(!isset($this->post_count))
      $this->post_count = isset($this->data->post_count) ? (int)$this->data->post_count : (int)count_user_posts($this->data->ID);

    return $this->post_count;
  }



  /**
   * The link to the author page
   *
   * @since 1.7
   *
   * @return string URL
   */
  public function getPostsURL(){
    if(!isset($this->posts_url))
      $this->posts_url = get_author_posts_url($this->data->ID);

    return $this->posts_url;
  }



  /**
   * Get the "karm" meta field of the current user
   *
   * @since 1.7
   *
   * @return int karma value (At least 0)
   */
  public function getKarma(){
    if(!isset($this->karma))
      $this->karma = get_user_meta($this->data->ID, 'karma', true);

    return (int)$this->karma;
  }



  /**
   * Get the RSS Feed URL for the current user
   *
   * @since 1.7
   *
   * @return string URL
   */
  public function getFeedURL(){
    if(!isset($this->feed))
      $this->feed = get_author_feed_link($this->data->ID);

    return $this->feed;
  }



  /**
   * Get the current user's avatar image URI
   *
   * @since 1.7
   *
   * @param int $size Avatar size
   * @return string description as HTML
   */
  public function getAvatar($size = 160){
    if(!isset($this->avatar[$size]))
      $this->avatar[$size] = Atom::app()->getAvatar($this->data->user_email, $size, false, $this->getName());

    return $this->avatar[$size];
  }



  /**
   * Get user description field (bio)
   *
   * @since 1.7
   *
   * @param string $fallback Fallback description text if none is set
   * @return string description as HTML
   */
  public function getDescription($fallback = ''){
    if(!isset($this->description)){

      // author meta - highest priority
      if(isset($this->data->description))
        $description = $this->data->description;

      // fallback
      if(empty($description))
        $description = $fallback;

      $this->description = $description ? force_balance_tags(wpautop(convert_smilies($description))) : '';
    }

    return $this->description;
  }



  /**
   * Retrieve the post author as a link
   *
   * @since 1.7
   *
   * @param bool $count_posts Include post count inside the title attribute? This might increase db queries, depending on the context
   * @return string Post Author as link
   */
  public function getNameAsLink($count_posts = false){
    $title = $count_posts ? sprintf(_a('Posts by %1$s (%2$s)'), $this->getName(), $this->getPostCount()) : sprintf(_a('Posts by %s'), $this->getName());
    return '<a href="'.$this->getPostsURL().'" title="'.$title.' ">'.$this->getName().'</a>';
  }



  /**
   * Get the account role of the author of the current post in the Loop.
   * from - http://core.trac.wordpress.org/attachment/ticket/5290/author-template-the_author_role.diff
   *
   * @since 1.3
   * @global object $wpdb WordPress database layer.
   * @global object $wp_roles avaliable account roles and capabilities.
   *
   * @param string $display Return type, "label or "slug"
   * @return string The author's account role, eg. "Administrator"
   */
  public function getRole($display = 'label') {
    global $wpdb, $wp_roles;

    if(!isset($wp_roles)) $wp_roles = new WP_Roles();
    foreach($wp_roles->role_names as $role => $label){
      $caps = $wpdb->prefix.'capabilities';
      if(array_key_exists($role, $this->data->$caps)) return ($display !== 'label') ? $role : $label;
    }

    return false;
  }


}