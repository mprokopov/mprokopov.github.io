<?php


/**
 * Module class
 *
 * @since 1.7
 */
class AtomMod{

  public $name, $url, $dir, $options;

  final public function __construct($name, $type){
    $this->url = ($type === 'core') ? Atom::app()->get('theme_url').'/mods/'.$name : Atom::app()->get('child_theme_url').'/mods/'.$name;
    $this->dir = ($type === 'core') ? TEMPLATEPATH.'/mods/'.$name : STYLESHEETPATH.'/mods/'.$name;
  }

  final public function getOptions($prefix){
    if(!isset($this->options)){
      $this->options = array();
      $all_options = Atom::app()->options();
      foreach($all_options as $key => $value)
        if(strpos($key, "{$prefix}_") === 0) $this->options[$key] = $value;

    }

    return $this->options;
  }

}

