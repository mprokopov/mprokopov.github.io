<?php

/**
 * Atom Recent Comments Widget
 *
 * Show a list of comments order by date.
 * Can also get site-wide comments
 *
 * @since 1.0
 * @todo test cache
 * @todo test the comment content filter
 */
 


class AtomWidgetRecentComments extends AtomWidget{

  public function AtomWidgetRecentComments(){

    $this->WP_Widget('atom-recent-comments', _a('Recent Comments'), array('classname' => 'recent-comments', 'description' => _a('The most recent comments')), array('width' => 500));

    // set up default templates
    $this->registerTemplates(array(
      'default' =>  "<a class=\"clear-block\" href=\"{URL}\" title=\"".sprintf(_a('on %s'), '{TITLE}')."\">\n"
                   ." {AVATAR}\n"
                   ." <span class=\"base\">\n"
                   ."   <span class=\"tt\">{AUTHOR}</span>\n"
                   ."   <span class=\"c1\">{CONTENT}</span>\n"
                   ."   <span class=\"c2\">{DATE}</span>\n"
                   ." </span>\n"
                   ."</a>",
    ));

    // default settings
    $this->setDefaults(array(
      'title'               => _a('Recent Comments'),
      'number'              => 5,
      'word_count'          => 20,
      'avatar_size'         => 48,
      'more'                => true,
      'template'            => '',
      'site_wide'           => false,
      'allowed_tags'        => 'abbr,acronym,b,cite,code,del,dfn,em,i,ins,q,strong,sub,sup',  // internal
      'content_filter_more' => '[&hellip;]',                                                  // internal
    ));


    Atom::add('ajax_requests',              array(&$this, 'ajax'));

    // include in jQuery(document).ready()
    Atom::add('jquery_init',                array(&$this, 'js'));

    // flush cache when comments are changed
    add_action('comment_post',              array(&$this, 'flushCache'));
    add_action('transition_comment_status', array(&$this, 'flushCache'));
  }

  public function js(){

    // we need to process all instances because this function gets to run only once
    $widget_options = get_option($this->option_name);

    foreach((array)$widget_options as $instance => $options){
      // identify instance
      $id = "{$this->id_base}-{$instance}";
      if(!is_active_widget(false, $id, $this->id_base)) continue;

      $options = wp_parse_args($options, AtomWidget::getObject($id)->getDefaults());
      if(!empty($options['more']))
        echo "\$('#instance-{$id}').showMoreControl('{$instance}', 'get_recent_comments', '".wp_create_nonce('atom_get_recent_comments')."');\n";

    }
  }

  public function ajax(){
    // not our request
    if(!Atom::app()->request('get_recent_comments')) return;

    Atom::app()->ajaxHeader('get_recent_comments', 'application/json');

    $settings = get_option($this->option_name);
    $instance = (int)$_GET['instance'];
    $settings = wp_parse_args($settings[$instance], $this->getDefaults());

    $offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
    $output = $this->getComments($settings, $next, $offset);
    $offset = $offset + $settings['number'];
      //$next = ($this->getComments($settings, $offset)) ? true : false;

    echo json_encode(array('output' => $output, 'more' => $next, 'offset' => $offset));
    exit;
  }

  private function getComments($args, &$more, $offset = 0){
    extract($args);

    $app = &Atom::app();

    $query = $app->get('swc') ? new AtomSWCommentQuery(): new WP_Comment_Query();

    $comments = $query->query(array(
      'number' => $number + 1,
      'status' => 'approve',
      'offset' => (int)$offset,
    ));

    $more = (count($comments) > $number) ? true : false;
    $count = 1;
    $output = '';
    $template = $args['template'] ? $args['template'] : $this->getTemplate();

    foreach((array)$comments as $comment){

      if($count++ == $number + 1) break;
      $output .= '<li'.($count === 1 && $offset === 0  ? ' class="first"' : '').'>';

      $app->setCurrentComment($comment);

      $fields = array(
        'TITLE'     => $site_wide ? strip_tags($comment->post_title) : get_the_title($comment->comment_post_ID),
        'URL'       => $app->comment->getURL(),
        'AVATAR'    => $app->comment->getAvatar(),
        'AUTHOR'    => $comment->comment_author,
        'CONTENT'   => convert_smilies($app->getFilteredContent($comment->comment_content, array(
                         'limit'         => $word_count,
                         'allowed_tags'  => explode(',', $allowed_tags),
                         'more'          => $content_filter_more
          ))),
        'DATE'      => $app->comment->getDate('relative'),
        'EMAIL'     => esc_url($comment->comment_author_email), // should not be used
        'ID'        => $app->comment->getID(),
      );

      // extra fields for mu
      if($site_wide){
        $blog = get_blog_details($app->comment->getBlogID());
        $fields = array_merge($fields, array(
          'BLOG_ID'         => $blog->blog_id,
          'BLOG_NAME'       => $blog->blogname,
          'BLOG_POST_COUNT' => $blog->post_count,
          'BLOG_URL'        => $blog->path,
        ));
      }

      $fields = apply_filters('atom_widget_recent_comments_keywords', $fields, $comment, $args);

      // output template
      $output .= $app->getBlockTemplate($template, $fields);

      $output .= '</li>';
    }

    return $output;
  }

  public function widget($args, $instance){

    extract($args, EXTR_SKIP);

    // check for a cached instance and display it if we have it
    if($this->getAndDisplayCache($widget_id)) return;

    $instance = wp_parse_args($instance, $this->getDefaults());
    $comments = $this->getComments($instance, $next);
    if(!$comments) return Atom::app()->addDebugMessage("No comments were found in {$widget_id} ({$widget_name}). Widget marked as inactive");;;

    $title = apply_filters('widget_title', $instance['title'], $instance, $this->id_base);

    $output = $before_widget;
    if ($title) $output .= $before_title.$title.$after_title;

    $output .= "<ul class=\"menu fadeThis full recent-comments\">{$comments}</ul>";
    if($instance['more'] && $next && Atom::app()->options('jquery'))
      $output .= "<div class=\"fadeThis clear-block\"><a href=\"#\" class=\"more\" data-count=\"{$instance['number']}\">"._a("Show More")."</a></div>";

    $output .= $after_widget;

    echo $output;

    $this->addCache($widget_id, $output);
  }

  public function update($new_instance, $old_instance){

    $instance['title']        = esc_attr($new_instance['title']);
    $instance['number']       = min(max((int)$new_instance['number'], 1), 20);
    $instance['word_count']   = (int)$new_instance['word_count'];
    $instance['avatar_size']  = (int)$new_instance['avatar_size'];
    $instance['more']         = (bool)$new_instance['more'];

    // html template
    if(current_user_can('edit_themes'))
      $instance['template'] = $new_instance['template'];

    // mu option
    if(Atom::app()->get('swc'))
      $instance['site_wide'] = (bool)$new_instance['site_wide'];

    $this->flushCache();
    return $instance;
  }

  public function form($instance){
    $instance = wp_parse_args($instance, $this->getDefaults());
    ?>
    <div <?php $this->formClass(); ?>>

      <?php if(Atom::app()->get('swc')): // only on mu + swc ?>
      <div class="high-priority-block">

         <input type="checkbox" id="<?php echo $this->get_field_id('site_wide'); ?>" name="<?php echo $this->get_field_name('site_wide'); ?>" <?php checked($instance['site_wide']); ?> />
         <label for="<?php echo $this->get_field_id('site_wide'); ?>"><strong><?php _ae('Network (site-wide) content'); ?></strong></label>
         <br />
         <em style="margin-left:15px;">(<?php _ae('Get comments from all network blogs'); ?>)</em>

      </div>
      <?php endif; ?>

      <p>
       <label for="<?php echo $this->get_field_id('title'); ?>"><?php _ae('Title:'); ?></label>
       <input class="wide" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php if (isset($instance['title'])) echo esc_attr($instance['title']); ?>" />
      </p>

      <p>
       <label for="<?php echo $this->get_field_id('number'); ?>"><?php _ae('How many entries to display?'); ?></label>
       <input id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="text" value="<?php if (isset($instance['number'])) echo (int)$instance['number']; ?>" size="3" />
      </p>

      <p>
       <?php $input = '<input id="'.$this->get_field_id('word_count').'" name="'.$this->get_field_name('word_count').'" type="text" value="'.(isset($instance['word_count']) ? (int)$instance['word_count'] : '').'" size="3" />'; ?>
       <label for="<?php echo $this->get_field_id('word_count'); ?>"><?php printf(_a('Content has max %s word(s)'), $input); ?></label>
      </p>

      <p>
        <label for="<?php echo $this->get_field_id('avatar_size'); ?>"><?php _ae('Avatar Size:') ?></label>
        <input type="text" size="3" id="<?php echo $this->get_field_id('avatar_size'); ?>" name="<?php echo $this->get_field_name('avatar_size'); ?>" value="<?php if (isset($instance['avatar_size'])) echo (int)$instance['avatar_size']; ?>" /> <?php _ae("pixels"); ?>
      </p>

      <p>
       <input <?php if(!Atom::app()->options('jquery')) echo "disabled=\"disabled\""; ?> type="checkbox" id="<?php echo $this->get_field_id('more'); ?>" name="<?php echo $this->get_field_name('more'); ?>"<?php checked($instance['more']); ?> />
       <label for="<?php echo $this->get_field_id('more'); ?>" <?php if(!Atom::app()->options('jquery')) echo "class=\"disabled\""; ?>><?php printf(_a('Display %s Link'), '<code>'._a("Show More").'</code>'); ?></label>
      </p>

      <?php if(current_user_can('edit_themes')): ?>
      <br />
      <strong><?php _ae('Template:'); ?></strong>
      <div class="user-template">
        <textarea class="wide code" id="<?php echo $this->get_field_id('template'); ?>" name="<?php echo $this->get_field_name('template'); ?>" rows="8" cols="28" mode="atom/html"><?php echo (empty($instance['template'])) ? format_to_edit($this->getTemplate()) : format_to_edit($instance['template']); ?></textarea>
        <small>
          <?php printf(_a("Read the %s to see all available keywords."), '<a href="'.Atom::THEME_DOC_URI.'" target="_blank">'._a("documentation").'</a>'); ?>
        </small>
      </div>
      <?php endif; ?>
    </div>
  <?php
  }
}