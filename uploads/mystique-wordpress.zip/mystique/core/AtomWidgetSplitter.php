<?php

/**
 * Column splitter.
 * Widgets that are surrounded by two "column splitter" widgets will be displayed in two columns
 *
 * @since 1.3
 */
 
 
class AtomWidgetSplitter extends AtomWidget{

  private
    $start_tag   = "<!--start/split-->",
    $end_tag     = "<!--end/split-->",
    $start_html  = "<li class=\"splitter\">\n<div class=\"block-content\">\n<ul class=\"split clear-block\">\n",
    $end_html    = "</ul>\n</div>\n</li>";

  public function AtomWidgetSplitter(){

    $this->WP_Widget('atom-splitter', _a('Column Splitter'), array('classname' => 'splitter', 'description' => _a('Splits area into 2 columns')));

    Atom::add('area_check',  array(&$this, 'areaCheck'), 10, 2);
    Atom::add('widget_area', array(&$this, 'areaProcess'), 10, 2);
  }

  public function areaCheck($sidebar_content, $area_id){
    // no point in going further if no splitters are active
    if(!defined('SPLITTER_ACTIVE')) return $sidebar_content;

    // ignore splitters when checking for active widgets
    return str_replace(array($this->start_tag, $this->end_tag), '', $sidebar_content);
  }

  public function areaProcess($sidebar_content, $area_id){
    // no point in going further if no splitters are active
    if(!defined('SPLITTER_ACTIVE')) return $sidebar_content;

    // replace splitter string with html and show splitters if we have any other active widgets in the sidebar
    $sidebar_content = str_replace(array($this->start_tag, $this->end_tag), array($this->start_html, $this->end_html), $sidebar_content);
    if(strpos($area_id, 'sidebar') !== false){ // check splitters
      $all_widgets = wp_get_sidebars_widgets();
      $splitters = 0;
      foreach($all_widgets as $sidebar => $sidebar_widgets)
        if($sidebar == $area_id)
          foreach($sidebar_widgets as $widget)
            if(strpos($widget, 'atom-splitter') !== false) $splitters++;

      if($splitters % 2){
        $sidebar_content .= $this->end_html; // odd splitter count => missing a splitter.
        Atom::app()->addDebugMessage("Fixed a missing closing column splitter in &lt;{$area_id}&gt;.");
      }
    }
    return $sidebar_content;
  }

  public function widget($args, $instance){
    extract($args);
    defined("SPLITTER_ACTIVE") or define("SPLITTER_ACTIVE", true);
    if(!Atom::app()->getWidgetSplitter()){
      Atom::app()->setWidgetSplitter(true);
      echo $this->start_tag; // this will get replaced with html when the sidebar is generated
      //Atom::app()->addDebugMessage("Column splitter opened in {$args['widget_id']} ({$args['widget_name']}).");
    }else{
      Atom::app()->setWidgetSplitter(false);
      echo $this->end_tag;
      //Atom::app()->addDebugMessage("Column splitter closed in {$args['widget_id']} ({$args['widget_name']}).");
    }
  }

  public function form($instance){
    ?><p><?php _ae('Widgets surrounded by splitters will be grouped into columns (two per row).'); ?></p><?php
  }
}