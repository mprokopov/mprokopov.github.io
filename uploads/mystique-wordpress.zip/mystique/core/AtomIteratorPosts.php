<?php

// Post iterator

class AtomIteratorPosts extends AtomIterator{

  public function current(){
    return new AtomObjectPost($this->list[$this->position]);
  }

  public function valid(){
    $valid = parent::valid();

    // just so we don't need to manually reset post data...
    if(!$valid)
      Atom::app()->setCurrentPost(false);

    return $valid;
  }

}