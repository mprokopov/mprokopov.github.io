<?php

/**
 * Atom Text Widget
 *
 * @todo find a way to fix FF and Opera's so called tinymce "fixes" (which make visual mode useless...)
 *
 * @since 1.0
 */


 
class AtomWidgetText extends AtomWidget{

  public function AtomWidgetText() {

    $widget_ops = array('classname' => 'text', 'description' => (current_user_can('edit_themes') ? _a('Arbitrary text, HTML/PHP or shortcodes') : _a('Arbitrary text, HTML or shortcodes')));
    $this->WP_Widget('atom-text', _a('Text'), $widget_ops, array('width' => 500));

    // default settings
    $this->setDefaults(array(
      'title'   => '',
      'visual'  => 0,
      'text'    => '',
      'php'     => false, // important: must be false by default, otherwise blog owners from a MU setup will eval content
    ));

    add_action('admin_print_scripts-widgets.php', array(&$this, 'js'));
  }

  public function js(){
    wp_enqueue_script('tinymce', site_url()."/wp-includes/js/tinymce/tiny_mce.js", array('common', 'admin-widgets', 'jquery','wp-ajax-response', 'jquery-color'));
    wp_enqueue_script('atom-text-tinymce-admin-langs', site_url()."/wp-includes/js/tinymce/langs/wp-langs-en.js", array('tinymce'));
  }

  public function widget($args, $instance){
    extract($args);
    $instance = wp_parse_args($instance, $this->getDefaults());
    $title = apply_filters('widget_title', $instance['title'], $instance, $this->id_base);
    $text = apply_filters('widget_text', $instance['text'], $instance);
    echo $before_widget;
    if(!empty($title)) echo $before_title.$title.$after_title;

    // evaluate php code if the user can edit themes
    if($instance['php']):
      ob_start();
      eval("?>{$text}");
      $text = ob_get_clean();
    endif;
    ?>

    <div class="box textwidget <?php if(!empty($title)) echo sanitize_html_class(strtolower($title)); ?>"><?php echo $instance['filter'] ? wpautop($text) : $text; ?></div>
    <?php
    echo $after_widget;
  }

  public function update($new_instance, $old_instance){

    $instance['title']    = esc_attr($new_instance['title']);
    $instance['visual']   = (int)$new_instance['visual'];
    $instance['text']     = current_user_can('unfiltered_html') ? $new_instance['text'] : stripslashes(wp_filter_post_kses(addslashes($new_instance['text'])));
    $instance['filter']   = (bool)$new_instance['filter'];

    if(current_user_can('edit_themes')) $instance['php'] = (bool)$new_instance['php'];
    return $instance;
  }

  public function form($instance) {
    $instance = wp_parse_args($instance, $this->getDefaults());
    $title = esc_attr($instance['title']);
    $visual = (int)$instance['visual'];
    $text = format_to_edit($instance['text']);
    $seed = rand(1, 999);

    ?>
    <div <?php $this->formClass(); ?>>
      <p>
       <label for="<?php echo $this->get_field_id('title'); ?>"><?php _ae('Title:'); ?></label>
       <input class="wide" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" />

       <input type="hidden" class="visual-switch" id="<?php echo $this->get_field_id('visual'); ?>" name="<?php echo $this->get_field_name('visual'); ?>" value="<?php echo $visual; ?>" />
      </p>

      <div class="clear-block">

        <a class="alignright button-secondary disabled toggle-editor <?php if(is_numeric($this->number)) echo "toggle-editor-{$seed}"; ?>"><?php _ae("Toggle Visual &lt;&gt; HTML"); ?></a>
      </div>

      <div class="visual-editor">
        <textarea class="wide <?php if($visual): ?>hidden<?php endif; ?> text-widget-content" rows="16" cols="20" id="<?php echo $this->get_field_id('text'); ?>" name="<?php echo $this->get_field_name('text'); ?>"><?php echo $text; ?></textarea>
      </div>

      <p class="text-options <?php if($visual == 1): ?>hidden<?php endif; ?>" id="text-options-<?php echo $seed; ?>">

       <label for="<?php echo $this->get_field_id('filter'); ?>">
         <input id="<?php echo $this->get_field_id('filter'); ?>" name="<?php echo $this->get_field_name('filter'); ?>" type="checkbox" <?php checked(isset($instance['filter']) ? $instance['filter'] : 0); ?> />
         <?php _ae('Automatically add paragraphs'); ?>
       </label>

       <?php if(current_user_can('edit_themes')): ?>
       <br />
       <label for="<?php echo $this->get_field_id('php'); ?>">
         <input id="<?php echo $this->get_field_id('php'); ?>" name="<?php echo $this->get_field_name('php'); ?>" type="checkbox" <?php checked(isset($instance['php']) ? $instance['php'] : 0); ?> />
         <?php printf(_a("Execute code within %s tags"),"<code>&lt;?php ?&gt;</code>"); ?>
       </label>
       <?php endif; ?>

      </p>

      <?php

       if(is_numeric($this->number)): ?>

       <?php // tiny mce settings
		$mce_settings = apply_filters('atom_widget_text_tiny_mce_settings', array(
          'mode'                              => 'exact',
          'elements'                          => $this->get_field_id('text'),
          'cleanup_on_startup'                => true,
          'language'                          => 'en',
          'theme'                             => 'advanced',
          'skin'                              => "wp_theme",
          'content_css'                       => Atom::app()->get('theme_url').'/editor-style.css',
          'theme_advanced_buttons1'           => "bold,italic,strikethrough,|,bullist,numlist,blockquote,hr,|,justifyleft,justifycenter,justifyright,|,link,unlink,image",
          'theme_advanced_buttons2'           => "formatselect,underline,justifyfull,forecolor,backcolor,|,removeformat,|,charmap,|,outdent,indent,|,undo,redo",
          'theme_advanced_buttons3'           => '',
          'theme_advanced_toolbar_location'   => 'top',
          'theme_advanced_toolbar_align'      => 'left',
          'theme_advanced_path'               => true,
          'theme_advanced_statusbar_location' => 'bottom',

          'fix_list_elements'                 => true,
          'verify_css_classes'                => true,
          'convert_fonts_to_spans'            => true,
          'inline_styles'                     => true,
          'relative_urls'                     => false,
          'remove_script_host'                => false,
          'entity_encoding'                   => 'raw',
          'add_form_submit_trigger'           => false,

          'height'                            => '280px',
          'width'                             => '500px',
		), &$this);

		$mce_settings_js = '';
		foreach($mce_settings as $name => $value)
          $mce_settings_js .= $name.':"'.$value.'", ';

		$mce_settings_js = rtrim(trim($mce_settings_js), '\n\r,');

       ?>
       <script type="text/javascript">

        /*<![CDATA[*/
        jQuery(document).ready(function($){

           // initialise the editor
          tinyMCEPreInit_<?php echo $seed; ?> = {
            base: '<?php echo site_url(); ?>/wp-includes/js/tinymce',
            suffix: '',
            mceInit: {<?php echo $mce_settings_js; ?>},
            load_ext: function(url,lang){
              var sl = tinymce.ScriptLoader;
              sl.markDone(url + '/langs/' + lang + '.js');
              sl.markDone(url + '/langs/' + lang + '_dlg.js');
              sl.markDone(url + '/themes/advanced/langs/' + lang + '.js');
            }
          };

          $('.toggle-editor-<?php echo $seed; ?>').removeClass('disabled').click(function(){
            var id = '<?php echo $this->get_field_id('text'); ?>';
            if(!tinyMCE.get(id)){
              $('#' + id, '#text-options-<?php echo $seed; ?>').addClass('hidden');
              $('#<?php echo $this->get_field_id('visual'); ?>').val('1');
              <?php if($visual == 0): ?>
              tinyMCE.init(tinyMCEPreInit_<?php echo $seed; ?>.mceInit);
              <?php else: ?>
              tinyMCE.execCommand('mceAddControl', false, id);
              <?php endif; ?>
            }else{
              $("#<?php echo $this->get_field_id('text'); ?>, #text-options-<?php echo $seed; ?>").removeClass('hidden');
              $('#<?php echo $this->get_field_id('visual'); ?>').val('0');
              tinyMCE.execCommand('mceRemoveControl', false, id);
            }

          });

          tinyMCEPreInit_<?php echo $seed; ?>.load_ext(tinyMCEPreInit_<?php echo $seed; ?>.base, 'en');

          <?php if($visual == 1): ?>
          tinyMCE.init(tinyMCEPreInit_<?php echo $seed; ?>.mceInit);
          <?php endif; ?>

          var save = $('.widget-control-save', $('#<?php echo $this->get_field_id('title'); ?>').parents('.widget'));
          //save.unbind('click');

          save.click(function(event){
            event.preventDefault();
            tinyMCE.triggerSave();
            return true;
          });

        });

        /* ]]> */
       </script>
      <?php endif; ?>

   </div> <?php
  }
}