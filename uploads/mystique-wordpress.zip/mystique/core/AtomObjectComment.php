<?php


class AtomObjectComment extends AtomObject{

  private
    $comment_url,

    $author,
    $author_url,
    $author_avatar;      // array

  public
    $display_index = 0;  // current comment index



  public function __construct($user_comment = false){
    global $comment;

    if(is_numeric($user_comment)){
      $this->data = &get_comment($user_comment);
      if(!is_object($this->data))
        throw new Exception("Failed to get comment {$user_post_id}");

    }elseif(is_object($user_comment)){
      $this->data = $user_comment;
      $comment = $this->data;
    }else{
      $this->data = $comment;
    }

    // set up controls - edit link
    if(current_user_can('edit_comment', $this->data->comment_ID))
      $this->controls['edit'] = array(
        'target'   => get_edit_comment_link($this->data->comment_ID),
        'label'    => _a('Edit'),
      );

    // delete / spam / approve links
    if(current_user_can('moderate_comments')){
      $this->controls['delete'] = array(
        'target'   => admin_url("comment.php?action=cdc&c={$this->data->comment_ID}"),
        'label'    => _a('Delete'),
      );

      $this->controls['spam'] = array(
        'target'   => admin_url("comment.php?action=cdc&dt=spam&c={$this->data->comment_ID}"),
        'label'    => _a('Spam'),
      );

      $this->controls['approve'] = array(
        'target'   => admin_url("comment.php?action=mac&dt=approve&c={$this->data->comment_ID}"),
        'label'    => _a('Approve'),
      );

    }

    if(Atom::app()->options('jquery') && (comments_open())){
      if(get_option('thread_comments'))
        $this->controls['reply'] = array(
          'target' => esc_url(add_query_arg('replytocom', $this->data->comment_ID)).'#respond',
          'id'     => "reply-to-{$this->data->comment_ID}",
          'label'  => _a('Reply'),
        );

      $this->controls['quote'] = array(
        'target'   => '#commentform',
        'label'    => _a('Quote'),
      );

    }

  }

  public function getID(){
    // swc
    if(isset($this->data->comment_id))
      return $this->data->comment_id;

    return $this->data->comment_ID;
  }


  public function getURL(){
    if(!isset($this->comment_url))
      $this->comment_url = isset($this->data->permalink) ? $this->data->permalink : get_comment_link($this->data->comment_ID);

    return $this->comment_url;
  }



  public function getAvatar($size = 48){
    if(!isset($this->author_avatar[$size]) && get_option('show_avatars'))
      $this->author_avatar[$size] = '<div class="avatar">'.Atom::app()->getAvatar($this->data->comment_author_email, $size, false, $this->getAuthor()).'</div>';

    return $this->author_avatar[$size];
  }



  public function getParent(){
    return $this->data->comment_parent;
  }



  public function getNumber(){
    // @todo: get real comment number relative to all comments
    // echo (get_query_var('cpage') * get_query_var('comments_per_page')) - get_query_var('comments_per_page') + $this->display_index;

    return (int)$this->display_index;
  }



  public function isApproved(){
    return ((int)$this->data->comment_approved !== 0);
  }



  public function belongsToCurrentUser(){
    global $user_ID;
    return ((int)$this->data->user_id === $user_ID);
  }



  /**
   * Check if the current user can rate a comment.
   * Can only be used inside the comment loop
   *
   * @since 1.3
   * @global $user_ID
   *
   * @return bool
   */
  public function isRatingAllowed(){
    global $user_ID;
    if(!is_user_logged_in() || (is_user_logged_in() && $this->belongsToCurrentUser())) return false;
    //delete_user_meta($user_ID, "comment_ratings");
    return !in_array($this->data->comment_ID, explode(',', get_user_meta($user_ID, 'comment_ratings', true)));
  }



  /**
   * Checks if the current comment has a low karma
   *
   * @since 1.3
   *
   * @return bool
   */
  public function isBuried(){
    if(!Atom::app()->options('comment_karma') || defined('RETRIEVING_BURIED_COMMENT')) return false;

    $level = (int)$this->data->comment_parent;
    $current_comment = $this->data;
    if($current_comment->comment_karma <= Atom::app()->options('comment_bury_limit')) return true;

    while($level !== 0){ // if this comment is not buried, make sure it doesn't have buried parent comments

      $current_comment = get_comment($current_comment->comment_parent); // hopefully this comes from cache
      $level = (int)$current_comment->comment_parent;

      // if it does we'll bury this one too
      if($current_comment->comment_karma <= Atom::app()->options('comment_bury_limit')) return true;
    }

    return false;
  }



  /**
   * Displays the comment karma controls
   *
   * @since 1.3
   *
   * @param string $classes Optional, extra CSS classes to add to the container
   *
   * @return bool
   */
  public function karma($classes = ''){
    if(!Atom::app()->options('comment_karma') || !Atom::app()->options('jquery')) return;
    ?>
      <div class="comment-karma <?php echo $classes; ?>">
        <?php if($this->isBuried()): ?>
        <a class="show" data-comment="<?php comment_ID(); ?>"><?php _ae('Show'); ?></a>
        <?php endif; ?>
        <span class="karma <?php echo ($this->data->comment_karma > 0) ? 'positive' : 'negative'; ?>"><?php if($this->data->comment_karma != 0) echo str_replace('-', '&#8722;', $this->data->comment_karma); ?></span>
        <?php if($this->isRatingAllowed()): ?>
        <a class="vote up" data-vote="+/<?php comment_ID(); ?>">&#43;</a>
        <a class="vote down" data-vote="-/<?php comment_ID(); ?>">&#8722;</a>
        <?php endif; ?>
     </div>
    <?php
  }



  /**
   * Get the comment time/date in time since format
   *
   * @since 1.0
   *
   * @param string $mode
   */
  public function getDate($mode = 'relative'){
    return ($mode !== 'relative' ? get_comment_date() : Atom::app()->getTimeSince(abs(strtotime("{$this->data->comment_date} GMT"))));
  }



  /**
   * Get the comment author name as a link or <b> tag
   * Can only be used inside the comment template
   *
   * @since 1.3
   *
   * @param string $rel
   */
  public function getAuthor($rel = 'nofollow'){
    if(!isset($this->author))
      $this->author = get_comment_author();

    return $this->author;
  }



  /**
   * Get the comment author name as a link or <b> tag
   * Can only be used inside the comment template
   *
   * @since 1.3
   *
   * @param string $rel
   */
  public function getAuthorURL($rel = 'nofollow'){
    if(!isset($this->author_url))
      $this->author_url = get_comment_author_url();

    return $this->author_url;
  }



  /**
   * Get the comment author name as a link or <b> tag
   * Can only be used inside the comment template
   *
   * @since 1.3
   *
   * @param string $rel
   */
  public function getAuthorAsLink($rel = 'nofollow'){
    $url = get_comment_author_url();

    if($this->getAuthorURL())
      $link = '<a class="comment-author" id="comment-author-'.$this->data->comment_ID.'" href="'.$this->getAuthorURL().'" rel="'.$rel.'">'.$this->getAuthor().'</a>';
    else
      $link = '<b class="comment-author" id="comment-author-'.$this->data->comment_ID.'">'.$this->getAuthor().'</b>';

    return apply_filters('atom_comment_author', $link, $this->data);
  }
      

}