<?php

/**
 * Lifestream -- under development -- will replace the twitter widget
 *
 * @since 1.0
 */



class AtomWidgetLifestream extends AtomWidget{

  public function AtomWidgetLifestream(){
    $widget_ops = array('classname' => 'lifestream', 'description' => _a("Your activity around social networks"));
    $control_ops = array('width' => 500);
    $this->WP_Widget('atom-lifestream', _a('Lifestream'), $widget_ops, $control_ops);

    // default settings
    $this->setDefaults(array(
      'active-tab'    => 'general',
      'title'         => _a('My Lifestream'),
      'count'         => 10,
      'limit'         => 100,
      'more'          => true,
      'update'        => 90,
      'twitter-user'  => 'wordpress',
      'lastfm-get'    => 'recenttracks',
    ));

//    Atom::add('ajax_requests', array(&$this, 'ajax'));

//    Atom::add('jquery_init', array(&$this, 'js'));

    // include in jQuery(document).ready()
//    add_action('atom_jquery_init', array(&$this, 'js'));
  }

  public function ajax(){
    if(isset($_GET['atom_get_lastfm_data'])):
      Atom::app()->ajaxHeader('atom_get_twitter_data');
      $this->displayTweets(esc_attr(strip_tags($_GET['widget_id'])), esc_attr(strip_tags($_GET['twituser'])), (int)$_GET['twitcount'], false, (bool)$_GET['showinfo']);
      exit();
    endif;
  }

  public function js(){
    // we need to process all instances because this function gets to run only once
    $widget_settings = get_option($this->option_name);

    foreach((array)$widget_settings as $instance => $options):

      // identify instance
      $id = "{$this->id_base}-{$instance}";
      $block_id = "instance-{$id}";

      if(false === ($data = get_transient($block_id)) && is_active_widget(false, $id, $this->id_base)): ?>

        $.ajax({
          type: "GET",
          url: "<?php echo home_url(); ?>",
          data: { widget_id: '<?php echo $block_id; ?>',
                  twituser: '<?php echo $options['user']; ?>',
                  twitcount: <?php echo $options['count']; ?>,
                  showinfo: <?php echo $options['info']; ?>,
                  _ajax_nonce: "<?php echo wp_create_nonce('atom_get_twitter_data'); ?>",
                  atom_get_lastfm_data: 1
                },
          beforeSend: function() { },
          complete: function() { },
          success: function(response){
            $("#<?php echo $block_id; ?> .latest-tweets").hide().html(response).slideDown(333);
          }
        });

      <?php endif;
    endforeach;
  }

  private function displayTweets($id, $user, $count, $data = false, $showinfo = true, $cache = 90){


//last fm API Key f9dee249cfec5a997b392f56fd21a0df
//last fm secret 606d674ddc25c5455819df62e123d5a1


    $error = false;
    if(!$data):
      if(false === ($data = get_transient($id))):
        if($showinfo):
          $response = wp_remote_retrieve_body(wp_remote_request("http://twitter.com/users/show/".$user.".json"));
          if(!is_array($userdata = json_decode($response, true))) $error = true;
        endif;
        $response = wp_remote_retrieve_body(wp_remote_request("http://twitter.com/statuses/user_timeline/".$user.".json"));
        if(!is_array($tweets = json_decode($response, true))) $error = true;

        if(!$error):
          if(isset($tweets['error'])):
            $error = esc_attr($tweets['error']);
          else:
            $data = array();
            if($showinfo):
              $data['user']['profile_image_url'] = esc_url($userdata['profile_image_url']);
              $data['user']['name'] = esc_attr($userdata['name']);
              $data['user']['screen_name'] = esc_attr($userdata['screen_name']);
              $data['user']['followers_count'] = (int)$userdata['followers_count'];
              $data['user']['statuses_count'] = (int)$userdata['statuses_count'];
              $data['user']['description'] = esc_attr($userdata['description']);
            endif;

            $i = 0;
            foreach($tweets as $tweet):
              $data['tweets'][$i]['text'] = esc_attr($tweet['text']);
              $data['tweets'][$i]['created_at'] = esc_attr($tweet['created_at']);
              $data['tweets'][$i]['id'] = esc_attr($tweet['id']);
              $i++;
            endforeach;
            set_transient($id, $data, (int)$cache); // keep the data cached

          endif;
        endif;
      endif;
    endif;

    if(!$error && is_array($data['tweets'])): ?>
     <?php if($showinfo): ?>
     <div class="info box clear-block">
       <div class="avatar"><img width="48" height="48" src="<?php echo $data['user']['profile_image_url']; ?>" alt="<?php echo $data['user']['name']; ?>" /></div>
       <div class="details">
         <a href="http://www.twitter.com/<?php echo $user; ?>/" title="<?php echo $data['user']['description']; ?>"><?php echo $data['user']['name']; ?> </a>
         <span class="followers"> <?php printf(_a("%s followers"),$data['user']['followers_count']); ?></span>
         <span class="count"> <?php printf(_a("%s tweets"),$data['user']['statuses_count']); ?></span>
       </div>
     </div>
     <?php endif; ?>
     <ul class="tweets">
      <?php
        $i = 0;
        foreach($data['tweets'] as $tweet):
          $i++;
          $pattern = '/\@(\w+)/';
          $replace = '<a rel="nofollow" href="http://twitter.com/$1">@$1</a>';
          $tweet['text'] = preg_replace($pattern, $replace, $tweet['text']);
          $tweet['text'] = convert_smilies(make_clickable($tweet['text']));

          // remove +XXXX
          $tweettime = substr_replace($tweet['created_at'], '', strpos($tweet['created_at'],"+"), 5);

          $link = "http://twitter.com/".$user."/statuses/".$tweet['id'];
          echo '<li'.($i === 1 ? ' class="first"' : NULL).'><span class="entry">'.$tweet['text'].'<a class="date" href="'.$link.'" rel="nofollow">'.Atom::getTimeSince(abs(strtotime("{$tweettime} GMT"))).'</a></span></li>';
          if($i === $count) break;
        endforeach;
      ?>
     </ul>

    <?php else:
      if(current_user_can('edit_theme_options')):
        echo '<div class="box error">';
        if(is_string($error)) printf(_a("Twitter returned error: %s"), $error);
        else _ae("Could not retrieve tweets. Possible reasons:");
        echo '</div>';

        if(!is_string($error)):
         // error
        endif;
      else:
        echo '<div class="box"><em>'._a("Unavailable for the moment").'</em></div>';
      endif;
    endif;
  }



  public function widget($args, $instance){
    extract($args);
    $instance = wp_parse_args($instance, $this->getDefaults());

//    return false; // under dev.

    $title = apply_filters('widget_title', $instance['title'], $instance, $this->id_base);
    $user = esc_attr($instance['twitter-user']);
    $type = esc_attr($instance['lastfm-get']);
//    $count = (int)$instance['count'];



          echo '<pre>';
    $url = "http://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20xml%20where%20url%3D%22".urlencode("http://twitter.com/statuses/user_timeline/35092196.rss")."%22&format=json";
    $response = wp_remote_retrieve_body(wp_remote_request($url));
    if(!is_array($data_twitter = json_decode($response, true))) $error = true;
    print_r($data_twitter['query']['results']['rss']['channel']['item']);

    $url = "http://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20xml%20where%20url%3D%22".urlencode("http://ws.audioscrobbler.com/1.0/user/xs/recenttracks.rss")."%22&format=json";
    $response = wp_remote_retrieve_body(wp_remote_request($url));
    if(!is_array($data_lastfm = json_decode($response, true))) $error = true;
    print_r($data_lastfm['query']['results']['rss']['channel']['item']);

    echo '</pre>';

    return;




    if(!function_exists('simplexml_load_file')) echo 'need php 5!';

    $url = "http://ws.audioscrobbler.com/2.0/user/{$user}/{$type}.xml?limit={$count}";
    $feed = @simplexml_load_file($url);

//    if(array_key_exists('track', get_object_vars($feed)));

    $last = count($feed->track);
    for($i=0; $i<$last; $i++):
      echo '<li><a href="'.esc_url($feed->track[$i]->url).'">'.$feed->track[$i]->artist.' - '.$feed->track[$i]->name.'</a></li>';

    endfor;

    return;

    $id = "instance-{$this->id}";

    echo $before_widget;
    if($title) echo $before_title.$title.$after_title;

    echo '<div class="box latest-tweets">';

    if(Atom::app()->options('jquery')):

      if(false === ($data = get_transient($id))):
        echo '<div class="box loading">'._a("Loading tweets...").'</div>';
      else:
        $this->displayTweets($id, $user, $count, $data, (bool)$instance, (int)$instance['cache']);
      endif;
    else:
      echo '<div class="box error">'._a("jQuery is required by this widget").'</div>';
   endif;

    echo '</div>';
    echo $after_widget;
  }

  public function update($new_instance, $old_instance){
    $instance = $old_instance;

    $instance['active-tab']   = esc_attr($new_instance['active-tab']);
    $instance['title']        = esc_attr($new_instance['title']);
    $instance['number']       = min(max((int)$new_instance['number'], 1), 20);
    $instance['limit']        = min(max((int)$new_instance['limit'], 1), 100);
    $instance['more']         = (bool)$new_instance['more'];
    $instance['update']       = (int)$new_instance['update'];
    $instance['twitter-user'] = esc_attr($new_instance['twitter-user']);
    $instance['lastfm-get']   = esc_attr($new_instance['lastfm-get']);

    delete_transient("instance-{$this->id}");
    return $instance;
  }

  public function form($instance){
    $instance = wp_parse_args($instance, $this->getDefaults());
    ?>
    <div <?php $this->formClass(); ?>>
    <div class="atom-tabs">
      <input type="hidden" class="active-tab" id="<?php echo $this->get_field_id('active-tab'); ?>" name="<?php echo $this->get_field_name('active-tab'); ?>" value="<?php echo esc_attr($instance['active-tab']); ?>" />

      <ul class="nav clear-block">
        <li><a href="#general" <?php if($instance['active-tab'] === 'general') echo 'class="active"'; ?>><?php _ae("General settings"); ?></a></li>
        <li><a href="#lastfm" <?php if($instance['active-tab'] === 'lastfm') echo 'class="active"'; ?>>Last.fm</a></li>
        <li><a href="#twitter" <?php if($instance['active-tab'] === 'twitter') echo 'class="active"'; ?>>Twitter</a></li>
      </ul>

      <div class="tab-content">

        <div class="tab general <?php if($instance['active-tab'] !== 'general') echo 'hidden'; ?>">

          <p>
           <label for="<?php echo $this->get_field_id('title'); ?>"> <?php _ae('Title:'); ?></label>
           <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($instance['title']); ?>" />
          </p>

          <p>
           <label for="<?php echo $this->get_field_id('more'); ?>" <?php if(!Atom::app()->options('jquery')) echo "class=\"disabled\""; ?>>
           <input <?php if(!Atom::app()->options('jquery')) echo "disabled=\"disabled\""; ?> type="checkbox" id="<?php echo $this->get_field_id('more'); ?>" name="<?php echo $this->get_field_name('more'); ?>"<?php checked($instance['more']); ?> />
       	 <?php printf(_a('Display %s Link'), '<code>'._a("Show More").'</code>'); ?></label>
          </p>

          <p>
           <label for="<?php echo $this->get_field_id('count'); ?>"><?php _ae('How many entries to display?'); ?></label>
           <input size="3" id="<?php echo $this->get_field_id('count'); ?>" name="<?php echo $this->get_field_name('count'); ?>" type="text" value="<?php echo esc_attr($instance['count']); ?>" />
          </p>

          <p>
           <label for="<?php echo $this->get_field_id('limit'); ?>"><?php _ae('Max. records to keep in database'); ?></label>
           <input size="3" id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="text" value="<?php echo esc_attr($instance['limit']); ?>" />
          </p>

          <p>
            <label for="<?php echo $this->get_field_id('update'); ?>"><?php _ae('Check for new data every:') ?></label>
            <select id="<?php echo $this->get_field_id('update'); ?>" name="<?php echo $this->get_field_name('update'); ?>">
             <option value="60" <?php selected($instance['update'], "60"); ?>><?php _ae("60 seconds"); ?></option>
             <option value="90" <?php selected($instance['update'], "90"); ?>><?php _ae("90 seconds"); ?></option>
             <option value="120" <?php selected($instance['update'], "120"); ?>><?php _ae("2 minutes"); ?></option>
             <option value="300" <?php selected($instance['update'], "300"); ?>><?php _ae("5 minutes"); ?></option>
            </select>
          </p>

        </div>

        <div class="tab lastfm <?php if($instance['active-tab'] !== 'lastfm') echo 'hidden'; ?>">
          <p>
            <label for="<?php echo $this->get_field_id('lastfm-get'); ?>"><?php _ae('Get:') ?></label>
            <select class="widefat" id="<?php echo $this->get_field_id('lastfm-get'); ?>" name="<?php echo $this->get_field_name('lastfm-get'); ?>">
             <option value="recenttracks" <?php selected($instance['lastfm-get'], "recenttracks"); ?>><?php _ae("Recently played tracks"); ?></option>
             <option value="lovedtracks" <?php selected($instance['lastfm-get'], "lovedtracks"); ?>><?php _ae("Loved tracks"); ?></option>
             <option value="toptracks" <?php selected($instance['lastfm-get'], "toptracks"); ?>><?php _ae("Top tracks"); ?></option>
             <option value="topartists" <?php selected($instance['lastfm-get'], "topartists"); ?>><?php _ae("Top artists"); ?></option>
            </select>
          </p>

        </div>

        <div class="tab twitter <?php if($instance['active-tab'] !== 'twitter') echo 'hidden'; ?>">
          <p>
           <label for="<?php echo $this->get_field_id('twitter-user'); ?>"><?php printf(_a('%s user name:'), 'Twitter'); ?></label>
           <input class="widefat" id="<?php echo $this->get_field_id('twitter-user'); ?>" name="<?php echo $this->get_field_name('twitter-user'); ?>" type="text" value="<?php echo esc_attr($instance['twitter-user']); ?>" />
          </p>

        </div>

      </div>

    </div>
    </div>
    <?php
  }
}