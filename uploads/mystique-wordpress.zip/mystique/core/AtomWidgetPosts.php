<?php

/**
 * Atom Posts widget
 *
 * Displays a list of posts (recent, popular, related, random etc.)
 *
 * @since 1.0
 * @todo allow order_by meta
 * @todo maybe- allow hooks to add templates; make the mode field dynamic (do this to all widgets that use templates)...
 */


 
class AtomWidgetPosts extends AtomWidget{

  public function AtomWidgetPosts(){

    $this->WP_Widget('atom-posts', _a('Posts'), array('classname' => 'posts', 'description' => _a('List posts based on filters you choose')), array('width' => 500));

    // set up default templates
    $this->registerTemplates(array(
      'full'     =>  "<a class=\"clear-block\" href=\"{URL}\" title=\"{TITLE}\">\n"
                    ." {THUMBNAIL}\n"
                    ." <span class=\"base\">\n"
                    ."   <span class=\"tt\">{TITLE} ({COMMENT_COUNT})</span>\n"
                    ."   <span class=\"c1\">{CONTENT}</span>\n"
                    ."   <span class=\"c2\">{DATE}</span>\n"
                    ." </span>\n"
                    ."</a>",

      'images'   =>  "<a class=\"clear-block\" href=\"{URL}\" title=\"{TITLE}\">\n"
                    ." {THUMBNAIL}\n"
                    ."</a>",

      'brief'    =>  "<a class=\"clear-block\" href=\"{URL}\" title=\"{TITLE}\">\n"
                    ." <span class=\"base\">\n"
                    ."   <span class=\"tt\">{TITLE} ({COMMENT_COUNT})</span>\n"
                    ." </span>\n"
                    ."</a>",

      'detailed' =>  "<a class=\"clear-block\" href=\"{URL}\" title=\"{TITLE}\">\n"
                    ." <span class=\"base\">\n"
                    ."   <span class=\"tt\">{TITLE} ({COMMENT_COUNT})</span>\n"
                    ."   <span class=\"c1\">{CONTENT}</span>\n"
                    ."   <span class=\"c2\">{DATE}</span>\n"
                    ." </span>\n"
                    ."</a>",
    ));

    // default settings
    $this->setDefaults(array(
      'site_wide'           => false,
      'title'               => _a('Recent Posts'),
      'post_type'           => 'post',
      'mode'                => 'full',
      'order_by'            => 'date',
      'category'            => 0,
      'number'              => 5,
      'word_count'          => 20,
      'thumb_size'          => 48,
      'more'                => true,
      'related'             => false,
      'template'            => '',

      // internal settings (not worth adding forms for)
      // note that a 'atom_widget_post_defaults' filter can override these every time they are retrieved
      'allowed_tags'        => 'abbr,acronym,b,cite,code,del,dfn,em,i,ins,q,strong,sub,sup',
      'content_filter_more' => '[&hellip;]',
    ));

    // register thumbnail size
    add_action('wp_loaded',       array(&$this, 'setThumbSize'));

    // flush cache when posts are changed
    add_action('save_post',       array(&$this, 'flushCache'));
    add_action('deleted_post',    array(&$this, 'flushCache'));

    Atom::add('ajax_requests',    array(&$this, 'ajax'));

    // include in jQuery(document).ready()
    Atom::add('jquery_init',      array(&$this, 'js'));
  }

  public function setThumbSize($sizes){

    // we need to process all instances because this function gets to run only once
    $widget_options = get_option($this->option_name);
    foreach((array)$widget_options as $instance => $options){

      // identify instance
      $id = "{$this->id_base}-{$instance}";

      // register thumb size if the widget is active
      if(!is_active_widget(false, $id, $this->id_base)) continue;

      $options = wp_parse_args($options, AtomWidget::getObject($id)->getDefaults());
      add_image_size($id, $options['thumb_size'], $options['thumb_size'], true);

    }
    return $sizes;
  }

  public function js(){

    // we need to process all instances because this function gets to run only once
    $widget_options = get_option($this->option_name);

    foreach((array)$widget_options as $instance => $options){

      // identify instance
      $id = "{$this->id_base}-{$instance}";
      $block_id = "instance-{$id}";

      if(!is_active_widget(false, $id, $this->id_base)) continue;

      $options = wp_parse_args($options, AtomWidget::getObject($id)->getDefaults());
      if(isset($options['more']) && $options['more'])
        echo "\$('#{$block_id}').showMoreControl('{$instance}', 'get_posts', '".Atom::app()->getNonce('get_posts')."');\n";
    }
  }

  public function ajax(){
    // not our request
    if(!Atom::app()->request('get_posts')) return;

    Atom::ajaxHeader('get_posts', 'application/json');

    $settings = get_option($this->option_name);
    $instance = (int)$_GET['instance'];
    $settings = wp_parse_args($settings[$instance], $this->getDefaults());

    // ID needed to identify post thumbnail size
    $settings['id'] = "{$this->id_base}-{$instance}";

    $offset = (int)$_GET['offset'];

    $output = $this->getPosts($settings, $next, $offset);
    $offset = $offset + $settings['number'];

    echo json_encode(array('output' => $output, 'more' => $next, 'offset' => $offset));
    exit;
  }

  private function getPosts($args, &$more, $offset = 0){
    global $post;

    $app = &Atom::app();
    extract($args);

    // build query, we get the number of posts + 1 just to check if more posts are available
    $query = array(
      'orderby'             => $order_by,
      'post_type'           => $post_type,
      'ignore_sticky_posts' => true,
      'posts_per_page'      => $number + 1,
      'offset'              => $offset,
    );

    if($order_by === 'views'){
      $query['order']    = 'DESC';
      if($site_wide){
        $query['orderby']  = 'views';
      }else{
        $query['orderby']  = 'meta_value_num';
        $query['meta_key'] = apply_filters('post_views_meta_key', 'views');
      }
    }

    if($category != 0 && !$site_wide)
      $query['cat'] = $category;

    // exclude current post if we're on the single page
    if(is_single())
      $query['post__not_in'] = array($post->ID);

    if($related && is_single()){ // tag-related posts ?
      $tags = wp_get_post_tags($post->ID);
      if(!empty($tags)){
        $tag_ids = array();
        foreach($tags as $tag) $tag_ids[] = $tag->term_id;
        $query['tag__in'] = $tag_ids;
      }else{
        return false; // no tags = no related posts
      }
    }elseif($related){
      return false; // not a single page
    }

    $posts = $app->get('swc') ? new AtomSWPostQuery($query) : new WP_Query($query);

    $more = ($posts->post_count > $number) ? true : false;     // do we have more results?
    $template = ($mode === 'template') ? $args['template'] : $this->getTemplate($mode);

    $output = '';
    $count = 0;

    // output posts, minus the last one
    while($posts->have_posts() && ($posts->current_post < $number - 1)){ // @todo check $posts->current_post because it starts from -1 in some cases...

      $posts->the_post();
      $app->setCurrentPost(false);

      $count++;
      $output .= '<li'.($count === 1 && $offset === 0 ? ' class="first"' : '').'>';

      $fields = array(
        'TITLE'           => $app->post->getTitle(),
        'COMMENT_COUNT'   => $app->post->getCommentCount(),
        'THUMBNAIL'       => $app->post->getThumbnail(str_replace('instance-', '', $id)),
        'URL'             => $app->post->getURL(),
        'CONTENT'         => convert_smilies($app->post->getContent($word_count, array(
                               'allowed_tags' => explode(',', $allowed_tags),
                               'more'         => $content_filter_more,
                             ))),
        'EXCERPT'         => $app->post->getContent('e'),
        'DATE'            => $app->post->getDate('relative'),
        'AUTHOR'          => $app->post->author->getName(),
        'CATEGORIES'      => strip_tags($app->post->getTerms('category')),
        'TAGS'            => strip_tags($app->post->getTerms()),
        'VIEWS'           => number_format_i18n($app->post->getViews()),
        'INDEX'           => $posts->current_post + 1,
        'ID'              => $post->ID,
      );

      // extra fields for mu
      if($site_wide){
        $blog = get_blog_details($app->post->getBlogID());
        $fields = array_merge($fields, array(
          'BLOG_ID'         => $blog->blog_id,
          'BLOG_NAME'       => $blog->blogname,
          'BLOG_POST_COUNT' => $blog->post_count,
          'BLOG_URL'        => $blog->path,
        ));
      }

      $fields = apply_filters('atom_widget_posts_keywords', $fields, $app->post, $args);

      // output template
      $output .= $app->getBlockTemplate($template, $fields);

      $output .= '</li>';

    }

    $app->resetCurrentPost();

    return $output;
  }

  function widget($args, $instance){

    extract($args, EXTR_SKIP);

    // check for a cached instance and display it if we have it
    if($this->getAndDisplayCache($widget_id)) return;

    $instance = wp_parse_args($instance, $this->getDefaults());
    $instance['id'] = $this->id;

    $posts = $this->getPosts($instance, $next);
    if(!$posts) return Atom::app()->addDebugMessage("No ".($instance['related'] ? 'related posts' : 'relevant entries')." were found in {$args['widget_id']} ({$args['widget_name']}). Widget marked as inactive");

    $title = apply_filters('widget_title', $instance['title'], $instance, $this->id_base);

    $output = $before_widget;
    if ($title) $output .= $before_title.$title.$after_title;

    $id = "instance-{$this->id}";

    $output .= "<ul class=\"menu fadeThis clear-block {$instance['mode']}\">{$posts}</ul>";
    if($instance['more'] && $next && Atom::app()->options('jquery'))
      $output .= "<div class=\"fadeThis clear-block\"><a href=\"#\" class=\"more\" data-count=\"{$instance['number']}\">"._a("Show More")."</a></div>";

    $output .= $after_widget;
    echo $output;

    if($instance['order_by'] !== 'rand') // we can't cache random posts (they wouldn't be random :)
      $this->addCache($widget_id, $output);
  }

  function update($new_instance, $old_instance){

    $instance['title']      = esc_attr($new_instance['title']);
    $instance['post_type']  = post_type_exists($new_instance['post_type']) ? $new_instance['post_type'] : 'post';
    $instance['mode']       = esc_attr($new_instance['mode']);
    $instance['category']   = (int)$new_instance['category'];
    $instance['order_by']   = esc_attr($new_instance['order_by']);
    $instance['number']     = min(max((int)$new_instance['number'], 1), 20);
    $instance['word_count'] = (int)$new_instance['word_count'];
    $instance['thumb_size'] = (int)$new_instance['thumb_size'];
    $instance['more']       = (bool)$new_instance['more'];
    $instance['related']    = (bool)$new_instance['related'];

    // html template
    if(isset($new_instance['template']) && current_user_can('edit_themes'))
      $instance['template'] = $new_instance['template'];

    // mu option
    if(Atom::app()->get('swc'))
      $instance['site_wide'] = (bool)$new_instance['site_wide'];

    $this->flushCache();
    return $instance;
  }

  function form($instance){
    $instance = wp_parse_args($instance, $this->getDefaults());
    ?>
    <div <?php $this->formClass(); ?>>
     <?php if(Atom::app()->get('swc')): // only on mu + atom-swc ?>
      <div class="high-priority-block">

         <input type="checkbox" id="<?php echo $this->get_field_id('site_wide'); ?>" name="<?php echo $this->get_field_name('site_wide'); ?>" <?php checked($instance['site_wide']); ?> followRules />
         <label for="<?php echo $this->get_field_id('site_wide'); ?>"><strong><?php _ae('Network (site-wide) content'); ?></strong></label>
         <br />
         <em style="margin-left:15px;">(<?php _ae('Get posts from all network blogs'); ?>)</em>

      </div>
      <?php endif; ?>
      <div class="clear-block">
        <div class="section alignleft">
          <p>
           <label for="<?php echo $this->get_field_id('title'); ?>"><?php _ae('Title:'); ?></label>
           <input class="wide" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php if (isset($instance['title'])) echo esc_attr($instance['title']); ?>" />
          </p>

          <p>
           <label for="<?php echo $this->get_field_id('post_type'); ?>"><?php _ae('Post Type:'); ?></label>
           <select id="<?php echo $this->get_field_id('post_type'); ?>" name="<?php echo $this->get_field_name('post_type'); ?>" class="wide" followRules>
             <?php foreach($GLOBALS['wp_post_types'] as $post_type => $data): ?>
              <?php if($data->public): ?>
              <option value="<?php echo esc_attr($post_type); ?>" <?php selected($instance['post_type'], $post_type); ?>><?php echo $data->label; ?></option>
              <?php endif; ?>
             <?php endforeach; ?>
           </select>
          </p>

          <p>
            <label for="<?php echo $this->get_field_id('order_by'); ?>"><?php _ae('Order by:') ?></label>
            <select class="wide" id="<?php echo $this->get_field_id('order_by'); ?>" name="<?php echo $this->get_field_name('order_by'); ?>">
             <option value="date" <?php selected($instance['order_by'], "date"); ?>><?php _ae("Date (Recent posts)"); ?></option>
             <option value="modified" <?php selected($instance['order_by'], "modified"); ?>><?php _ae("Modified date (Recently modified)"); ?></option>
             <option value="comment_count" <?php selected($instance['order_by'], "comment_count"); ?>><?php _ae("Comment count"); ?></option>
             <option value="views" <?php selected($instance['order_by'], "views"); ?>><?php _ae("View count"); ?></option>
             <option value="title" <?php selected($instance['order_by'], "title"); ?>><?php _ae("Title, alphabetically"); ?></option>
             <option value="rand" <?php selected($instance['order_by'], "rand"); ?>><?php _ae("Nothing, get random posts"); ?></option>
            </select>
          </p>

          <?php
            $categories = Atom::app()->getDropdown('category', array(
              'name'              => $this->get_field_name('category'),
              'id'                => $this->get_field_id('category'),
              'selected'          => (int)$instance['category'],
              'show_option_all'   => _a('-- All categories --'),
              'hide_empty'        => 0,
              'orderby'           => 'name',
              'show_count'        => 1,
              'class'             => 'wide',
              'hierarchical'      => 1,
              'extra_attributes'  => 'followRules rules="DEPENDS ON '.$this->get_field_name('post_type').' BEING post AND CONFLICTS WITH '.$this->get_field_name('site_wide').'"',
            ));
          ?>
          <p>
            <label for="<?php echo $this->get_field_id('category'); ?>"><?php _ae('Show posts from:') ?></label>
            <?php echo $categories; ?>
          </p>

        </div>

        <div class="section alignright">
          <p>
           <label for="<?php echo $this->get_field_id('number'); ?>"><?php _ae('How many entries to display?'); ?></label><br />
           <input id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="text" value="<?php if (isset($instance['number'])) echo (int)$instance['number']; ?>" size="3" />
          </p>

          <p>
           <?php $input = '<br /><input id="'.$this->get_field_id('word_count').'" name="'.$this->get_field_name('word_count').'" type="text" value="'.(isset($instance['word_count']) ? (int)$instance['word_count'] : null).'" size="3" />'; ?>
           <label for="<?php echo $this->get_field_id('word_count'); ?>"><?php printf(_a('Content has max %s <em>words</em>'), $input); ?></label>
          </p>

          <p>
            <label for="<?php echo $this->get_field_id('thumb_size'); ?>"><?php _ae('Thumbnail Size:') ?></label><br />
            <input type="text" size="3" id="<?php echo $this->get_field_id('thumb_size'); ?>" name="<?php echo $this->get_field_name('thumb_size'); ?>" value="<?php if (isset($instance['thumb_size'])) echo (int)$instance['thumb_size']; ?>" /> <em><?php _ae("pixels"); ?></em>
          </p>

          <p>
           <input <?php if(!Atom::app()->options('jquery')) echo "disabled=\"disabled\""; ?> type="checkbox" id="<?php echo $this->get_field_id('more'); ?>" name="<?php echo $this->get_field_name('more'); ?>"<?php checked($instance['more']); ?> />
           <label for="<?php echo $this->get_field_id('more'); ?>" <?php if(!Atom::app()->options('jquery')) echo "class=\"disabled\""; ?>><?php printf(_a('Display %s Link'), '<code>'._a("Show More").'</code>'); ?></label>
          </p>

          <p>
           <input type="checkbox" id="<?php echo $this->get_field_id('related'); ?>" name="<?php echo $this->get_field_name('related'); ?>"<?php checked($instance['related']); ?> followRules rules="DEPENDS ON <?php echo $this->get_field_name('post_type'); ?> BEING post" />
           <label for="<?php echo $this->get_field_id('related'); ?>"><?php _ae('Get only context-related posts'); ?></label>
          </p>
        </div>
      </div>

      <div class="template-selector clear-block">
        <div class="title"><?php _ae('Display mode') ?></div>
        <a href="#" class="select t-full" rel="full" title="<?php _ae("Full"); ?>"><?php _ae("Full"); ?></a>
        <a href="#" class="select t-detailed" rel="detailed" title="<?php _ae("Details"); ?>"><?php _ae("Details"); ?></a>
        <a href="#" class="select t-brief" rel="brief" title="<?php _ae("Brief"); ?>"><?php _ae("Brief"); ?></a>
        <a href="#" class="select t-images" rel="images" title="<?php _ae("Post thumbnails"); ?>"><?php _ae("Post thumbnails"); ?></a>
        <a href="#" class="select t-custom" rel="template" title="<?php _ae("Custom Template"); ?>"><?php _ae("Custom Template"); ?></a>
        <input class="select" type="hidden" value="<?php echo $instance['mode']; ?>" id="<?php echo $this->get_field_id('mode'); ?>" name="<?php echo $this->get_field_name('mode'); ?>" />
      </div>

      <?php if(current_user_can('edit_themes')): ?>
      <div class="user-template <?php if($instance['mode'] !== 'template') echo 'hidden'; ?>">
        <textarea class="wide code" id="<?php echo $this->get_field_id('template'); ?>" name="<?php echo $this->get_field_name('template'); ?>" rows="8" cols="28" mode="atom/html"><?php echo (empty($instance['template'])) ? format_to_edit($this->getTemplate()) : format_to_edit($instance['template']); ?></textarea>
        <small>
          <?php printf(_a("Read the %s to see all available keywords."), '<a href="'.Atom::THEME_DOC_URI.'" target="_blank">'._a("documentation").'</a>'); ?>
        </small>
      </div>
      <?php endif; ?>

      <hr />
      <p>
        <em>
          <?php
            printf(_a('<strong>Important:</strong> %1$s sized thumbnails have to be created if you just added this widget, or if you\'re changing the thumbnail size. Read more about thumbnail sizes %2$s'),  (int)$instance['thumb_size'].'x'.(int)$instance['thumb_size'], '<a href="'.admin_url('themes.php?page='.ATOM.'#advanced').'">'._a("here").'</a>'); ?>
        </em>
      </p>
    </div>
  <?php
  }
}