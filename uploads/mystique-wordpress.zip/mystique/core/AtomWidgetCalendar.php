<?php

/**
 * Atom Calendar Widget
 *
 * A calendar widget with CSS friendly output, ajax month navigation and support for CPT
 *
 * @since 1.0
 */


 
class AtomWidgetCalendar extends AtomWidget{

  public function AtomWidgetCalendar(){

    $this->WP_Widget('atom-calendar', _a('Calendar'), array('classname' => 'calendar', 'description' => _a("A calendar of your site's posts")));

    // default settings
    $this->setDefaults(array(
      'initial'   => false,
      'ajax'      => true,
      'post_type' => 'post',
    ));

    Atom::add('ajax_requests',    array(&$this, 'ajax'));

    // include in jQuery(document).ready()
    Atom::add('jquery_init',      array(&$this, 'js'));

    // flush cache when posts are changed
    add_action('save_post',       array(&$this, 'flushCache'));
    add_action('deleted_post',    array(&$this, 'flushCache'));
  }

  public function flushCache(){
    wp_cache_delete('get_calendar', 'atom');
  }

  public function js(){

    // we need to process all instances because this function gets to run only once
    $widget_options = get_option($this->option_name);

    foreach((array)$widget_options as $instance => $options):

      // identify instance
      $id = "{$this->id_base}-{$instance}";
      $block_id = "instance-{$id}";

      if(!is_active_widget(false, $id, $this->id_base)) continue; // not active

      $options = wp_parse_args($options, AtomWidget::getObject($id)->getDefaults());
      if(isset($options['ajax']) && $options['ajax']): ?>

      $('#<?php echo $block_id; ?>').delegate('a.control', 'click', function(){
        var reqdate = $(this).attr('rel').split(/-/g);
        $.ajax({
          type: 'GET',
          url: $(this).attr('href'),
          context: this,
          data: { id: '<?php echo $block_id; ?>',
                  initial: <?php echo (int)$options['initial']; ?>,
                  reqmonth: reqdate[0],
                  reqyear: reqdate[1],
                  _ajax_nonce: '<?php Atom::app()->nonce('get_calendar'); ?>',
                  atom: 'get_calendar' },
          dataType: 'json',
          beforeSend: function() { $(this).addClass('loading'); },
          complete: function() { $(this).removeClass('loading'); },
          success: function(response){
            if(response.output != '') $('#<?php echo $block_id; ?> .calendar-block').html(response.output);
          }
        });
        return false;

      });

      <?php endif;
    endforeach;
  }

  public function ajax(){
    if(!Atom::app()->request('get_calendar')) return; // not our request

    Atom::app()->ajaxHeader('get_calendar', 'application/json');
    $output = $this->getCalendar(array(
      'initial' => (bool)$_GET['initial'],
      'req_m'   => (int)$_GET['reqmonth'],
      'req_y'   => (int)$_GET['reqyear'],
    ));
    echo json_encode(array('output' => $output));
    die();
  }

  // pretty much the same as the wp function, but with cpt support and mark-up changes
  private function getCalendar($args = array()){
    global $wpdb, $m, $monthnum, $year, $wp_locale, $posts;

    $args = wp_parse_args($args, array(
      'initial'   => true,
      'req_m'     => null,
      'req_y'     => null,
      'post_type' => 'post',
    ));

    extract($args, EXTR_SKIP);

    // ajax?
    if($req_m) $monthnum = $req_m;
    if($req_y) $year = $req_y;

    if(isset($_GET['w'])) $w = (int)$_GET['w'];
    if(isset($_GET['post_type']) && post_type_exists($_GET['post_type'])) $post_type = $_GET['post_type']; // validate

    $cache = array();
    $key = md5($m.$monthnum.$year.$post_type);
    if($cache = wp_cache_get('get_calendar', 'atom'))
      if(is_array($cache) && isset($cache[$key]))
        return apply_filters('get_calendar', $cache[$key]);

    if(!is_array($cache)) $cache = array();

    // Quick check. If we have no posts at all, abort!
    if(!$posts){
      $got_some = $wpdb->get_var("SELECT 1 as test FROM {$wpdb->posts} WHERE post_type = '{$post_type}' AND post_status = 'publish' LIMIT 1");
      if(!$got_some){
        $cache[$key] = '';
        wp_cache_set('get_calendar', $cache, 'atom'); // no point checking again
        return;
      }
    }

    // week_begins = 0 stands for Sunday
    $week_begins = (int)get_option('start_of_week');

    // Let's figure out when we are
    if(!empty($monthnum) && !empty($year)){
      $thismonth = zeroise((int)$monthnum, 2);
      $thisyear = (int)$year;
    }elseif(!empty($w)){
      // We need to get the month from MySQL
      $thisyear = (int)substr($m, 0, 4);
      $d = (($w - 1) * 7) + 6; // it seems MySQL's weeks disagree with PHP's
      $thismonth = $wpdb->get_var("SELECT DATE_FORMAT((DATE_ADD('{$thisyear}0101', INTERVAL {$d} DAY)), '%m')");
    }elseif(!empty($m)){
      $thisyear = ''.(int)substr($m, 0, 4);
      if(strlen($m) < 6) $thismonth = '01'; else $thismonth = ''.zeroise((int)substr($m, 4, 2), 2);
    }else{
      $thisyear = gmdate('Y', current_time('timestamp'));
      $thismonth = gmdate('m', current_time('timestamp'));
    }

    $unixmonth = mktime(0, 0 , 0, $thismonth, 1, $thisyear);

    // Get the next and previous month and year with at least one post
    $previous = $wpdb->get_row("SELECT DISTINCT MONTH(post_date) AS month, YEAR(post_date) AS year FROM {$wpdb->posts} WHERE post_date < '{$thisyear}-{$thismonth}-01' AND post_type = '{$post_type}' AND post_status = 'publish' ORDER BY post_date DESC LIMIT 1");

    $next = $wpdb->get_row("SELECT	DISTINCT MONTH(post_date) AS month, YEAR(post_date) AS year FROM {$wpdb->posts} WHERE post_date > '{$thisyear}-{$thismonth}-01' AND MONTH(post_date) != MONTH('{$thisyear}-{$thismonth}-01') AND post_type = '{$post_type}' AND post_status = 'publish' ORDER BY post_date ASC LIMIT 1");

    /* translators: Calendar caption: 1: month name, 2: 4-digit year */
    $calendar_caption = _x('%1$s %2$s', 'calendar caption');

    $caption = '<div class="top clear-block">';

    if($previous){
      $url = get_month_link($previous->year, $previous->month);
      if($post_type !== 'post') $url = add_query_arg('post_type', $post_type, $url);

      $caption .= "\n\t\t<a class=\"prev control\" rel=\"{$previous->month}-{$previous->year}\" href=\"{$url}\" title=\"".sprintf(_a('View posts for %1$s %2$s'), $wp_locale->get_month($previous->month), date('Y', mktime(0, 0 , 0, $previous->month, 1, $previous->year)))."\">&laquo; ".$wp_locale->get_month_abbrev($wp_locale->get_month($previous->month))."</a>";
    }

    $caption .= '<h4>'.sprintf($calendar_caption, $wp_locale->get_month($thismonth), date('Y', $unixmonth)).'</h4>';

    if($next){
      $url = get_month_link($next->year, $next->month);
      if($post_type !== 'post') $url = add_query_arg('post_type', $post_type, $url);

      $caption .= "\n\t\t<a class=\"next control\" rel=\"{$next->month}-{$next->year}\" href=\"{$url}\" title=\"".esc_attr(sprintf(_a('View posts for %1$s %2$s'), $wp_locale->get_month($next->month), date('Y', mktime(0, 0 , 0, $next->month, 1, $next->year))))."\">".$wp_locale->get_month_abbrev($wp_locale->get_month($next->month))." &raquo;</a>";
    }

    $caption .= '</div>';

    // some themes might need wrapper elements...
    $output = apply_filters('atom_calendar_caption', $caption);

    $output .= '<table class="calendar" summary="'._a('Calendar').'"><thead><tr>';

    $myweek = array();
    for($wdcount=0; $wdcount<=6; $wdcount++)
      $myweek[] = $wp_locale->get_weekday(($wdcount+$week_begins)%7);

    foreach($myweek as $wd){
      $day_name = (true == $initial) ? $wp_locale->get_weekday_initial($wd) : $wp_locale->get_weekday_abbrev($wd);
      $wd = esc_attr($wd);
      $output .= "\n\t\t<th scope=\"col\" title=\"{$wd}\">{$day_name}</th>";
    }

    $output .= '</tr></thead> <tbody><tr>';

    // Get days with posts
    $dayswithposts = $wpdb->get_results("SELECT DISTINCT DAYOFMONTH(post_date) FROM {$wpdb->posts} WHERE MONTH(post_date) = '{$thismonth}' AND YEAR(post_date) = '$thisyear' AND post_type = '{$post_type}' AND post_status = 'publish' AND post_date < '".current_time('mysql').'\'', ARRAY_N);

    if($dayswithposts)
      foreach((array) $dayswithposts as $daywith)
        $daywithpost[] = $daywith[0];
    else
      $daywithpost = array();

    if(strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') !== false || stripos($_SERVER['HTTP_USER_AGENT'], 'camino') !== false || stripos($_SERVER['HTTP_USER_AGENT'], 'safari') !== false)
      $ak_title_separator = "\n";
    else
      $ak_title_separator = ', ';

    $ak_titles_for_day = array();
    $ak_post_titles = $wpdb->get_results("SELECT ID, post_title, DAYOFMONTH(post_date) as dom FROM {$wpdb->posts} WHERE YEAR(post_date) = '{$thisyear}' AND MONTH(post_date) = '{$thismonth}' AND post_date < '".current_time('mysql')."' AND post_type = '{$post_type}' AND post_status = 'publish'");

    if($ak_post_titles)
      foreach((array)$ak_post_titles as $ak_post_title){
        $post_title = esc_attr(apply_filters('the_title', $ak_post_title->post_title, $ak_post_title->ID));
        if(empty($ak_titles_for_day["day_{$ak_post_title->dom}"]))
          $ak_titles_for_day["day_{$ak_post_title->dom}"] = '';

        if(empty($ak_titles_for_day[$ak_post_title->dom])) // first one
          $ak_titles_for_day[$ak_post_title->dom] = $post_title;
        else
          $ak_titles_for_day[$ak_post_title->dom] .= $ak_title_separator.$post_title;
      }

    // See how much we should pad in the beginning
    $pad = calendar_week_mod(date('w', $unixmonth) - $week_begins);
    if($pad != 0) $output .= '<td colspan="'.esc_attr($pad).'" class="pad">&nbsp;</td>';

    $daysinmonth = (int)date('t', $unixmonth);
    for($day = 1; $day <= $daysinmonth; ++$day){
      if(isset($newrow) && $newrow) $output .= "\n\t</tr>\n\t<tr>\n\t\t";
      $newrow = false;

      if($day == gmdate('j', current_time('timestamp')) && $thismonth == gmdate('m', current_time('timestamp')) && $thisyear == gmdate('Y', current_time('timestamp')))
        $output .= '<td class="today">';
      else
        $output .= '<td>';

      if(in_array($day, $daywithpost)){ // any posts today?
        $url = get_day_link($thisyear, $thismonth, $day);
        if($post_type !== 'post') $url = add_query_arg('post_type', $post_type, $url);
        $output .= '<a href="'.$url."\" title=\"".esc_attr($ak_titles_for_day[$day])."\">$day</a>";
      }else{
        $output .= "<span>{$day}</span>";
      }
      $output .= '</td>';
      if(calendar_week_mod(date('w', mktime(0, 0 , 0, $thismonth, $day, $thisyear)) - $week_begins) == 6) $newrow = true;
    }

    $pad = 7 - calendar_week_mod(date('w', mktime(0, 0 , 0, $thismonth, $day, $thisyear)) - $week_begins);
    if($pad != 0 && $pad != 7)
      $output .= "\n\t\t".'<td class="pad" colspan="'.esc_attr($pad).'">&nbsp;</td>';

    $output .= "\n\t</tr>\n\t</tbody>\n\t</table>";

    $cache[$key] = $output;
    wp_cache_set('get_calendar', $cache, 'atom');

    return apply_filters('atom_calendar', $output); // no point using get_calendar(), markup is different...
  }

  public function widget($args, $instance){
    extract($args);
    $instance = wp_parse_args($instance, $this->getDefaults());

    $initial = isset($instance['initial']) ? $instance['initial'] : false;
    $ajax = isset($instance['ajax']) ? $instance['ajax'] : false;

    $calendar = $this->getCalendar($instance);

    if(!$calendar)
      return Atom::app()->addDebugMessage("There are no posts for {$args['widget_id']} ({$args['widget_name']}). Widget marked as inactive");

    echo $before_widget; ?>
    <div class="calendar-block">
      <?php echo $calendar; ?>
    </div>
    <?php
    echo $after_widget;
  }

  public function update($new_instance, $old_instance){
    $instance = $old_instance;
    $instance['initial']   = (bool)$new_instance['initial'];
    $instance['ajax']      = (bool)$new_instance['ajax'];
    $instance['post_type'] = post_type_exists($new_instance['post_type']) ? $new_instance['post_type'] : 'post';
    return $instance;
  }

  function form($instance){
    $instance = wp_parse_args($instance, $this->getDefaults());
    ?>
    <div <?php $this->formClass(); ?>>

      <p>
       <label for="<?php echo $this->get_field_id('post_type'); ?>"><?php _ae('Post Type:'); ?></label>
       <select id="<?php echo $this->get_field_id('post_type'); ?>" name="<?php echo $this->get_field_name('post_type'); ?>" class="wide" followRules>
         <?php foreach($GLOBALS['wp_post_types'] as $post_type => $data): ?>
          <?php if($data->public): ?>
          <option value="<?php echo esc_attr($post_type); ?>" <?php selected($instance['post_type'], $post_type); ?>><?php echo $data->label; ?></option>
          <?php endif; ?>
         <?php endforeach; ?>
       </select>
      </p>


      <p>
       <label for="<?php echo $this->get_field_id('ajax'); ?>" <?php if(!Atom::app()->options('jquery')) echo "class=\"disabled\""; ?>>
       <input <?php if(!Atom::app()->options('jquery')) echo "disabled=\"disabled\""; ?> type="checkbox" <?php checked($instance['ajax'], true); ?> id="<?php echo $this->get_field_id('ajax'); ?>" name="<?php echo $this->get_field_name('ajax'); ?>" /> <?php _ae('Use AJAX for month navigation'); ?></label>
      </p>
      <p>
       <label for="<?php echo $this->get_field_id('initial'); ?>">
       <input type="checkbox" <?php checked($instance['initial'], true); ?> id="<?php echo $this->get_field_id('initial'); ?>" name="<?php echo $this->get_field_name('initial'); ?>" /> <?php _ae('One-letter day abbreviation'); ?></label>
      </p>
    </div>
    <?php
  }
}