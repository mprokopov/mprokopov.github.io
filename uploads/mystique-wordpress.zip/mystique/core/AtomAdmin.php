<?php
/**
 * Administration pages (ATOM framework)
 *
 * @link http://digitalnature.eu
 *
 * @package ATOM
 * @subpackage Template
 *
 * @todo:
 *   update entire theme settings code to build options from xml files
 *   add editor elements like tabs, buttons, boxes, toggle links etc.
 */



class AtomAdmin{

  private
    $page,
    $tabs,
    $error,
    $nonce;

  public function __construct(){
    add_action('admin_menu',                               array(&$this, 'addMenu'));
    add_action('admin_post_atom_update_settings',          array(&$this, 'saveOptions'));
    add_action('admin_print_styles',                       array(&$this, 'css'));
    add_action('admin_print_scripts',                      array(&$this, 'js'));
    add_action('admin_notices',                            array(&$this, 'editorWarning'));
    add_action('admin_footer',                             array(&$this, 'footer'));

    // featured columns
    add_filter('manage_edit-post_columns',                 array(&$this, 'featuredColumnTitle'));
    add_filter('manage_media_columns',                     array(&$this, 'featuredColumnTitle'));
    add_filter('manage_posts_custom_column',               array(&$this, 'postsColumnContent'), 10, 2);
    add_filter('manage_media_custom_column',               array(&$this, 'mediaColumnContent'), 10, 2);

    // widget related hooks
    add_action('in_widget_form',                           array(&$this, 'widgetVisibilityOptions'), 10, 3);
    add_filter('widget_update_callback',                   array(&$this, 'widgetVisibilityUpdate'), 10, 3);

    // do not allow more than 10 inactive widgets, too much load
    //add_filter('pre_update_option_sidebars_widgets',       array(&$this, 'cleanupInactiveWidgets'), 10, 2);

    // ajax hooks
    add_action('wp_ajax_get_tab',                          array(&$this, 'getTab'));
    add_action('wp_ajax_process_upload',                   array(&$this, 'processUpload'));
    add_action('wp_ajax_latest_news',                      array(&$this, 'latestNews'));
    add_action('wp_ajax_update_check',                     array(&$this, 'updateCheck'));
    add_action('wp_ajax_process_featured',                 array(&$this, 'processFeatured'));
    add_action('wp_ajax_widget_visibility_options_fields', array(&$this, 'widgetVisibilityOptionsFields'));

    // theme update check
    if(Atom::THEME_UPDATE_URI)
      add_filter('pre_set_site_transient_update_themes',   array(&$this, 'transientUpdateThemes'));

    add_action('delete_post',                              array(&$this, 'cleanFeaturedPostRecords'));

    $this->tabs = array(
      'welcome'         => _a('Welcome!'),
      'design'          => _a('Design'),
      'content_options' => _a('Content options'),
      'user_css'        => _a('CSS'),
      'advanced'        => _a('Advanced'),
      'modules'         => _a('Modules'),
    );

    if(!Atom::app()->isOptionEnabled('css')) unset($this->tabs['css']);

    $this->nonce = wp_create_nonce('theme-settings');
  }



  /**
   * The nonce field used by the settings. Modules might share it
   *
   * @since 1.7
   */
  public function setError($error){
    $this->error = $error;
  }



  /**
   * The nonce field used by the settings. Modules might share it
   *
   * @since 1.7
   */
  public function getNonce(){
    return $this->nonce;
  }



  /**
   * Restrict inactive widget records to 10, because they slow down the admin-widgets.php page load
   * The inactive widgets section is pretty much useless anyway...
   *
   * @since 1.7
   */
  public function cleanupInactiveWidgets($new, $old){
    if(!empty($new['wp_inactive_widgets']) && count($new['wp_inactive_widgets']) > 10){

      // find out which widget instances to remove
      $widgets_to_remove = array_slice($new['wp_inactive_widgets'], 0, -10);

      // remove instance options
      foreach($widgets_to_remove as $widget_id)
        if(isset($GLOBALS['wp_registered_widgets'][$widget_id])){

          $instance = AtomWidget::getObject($widget_id)->number;
          $option_name = AtomWidget::getObject($widget_id)->option_name;

          $options = get_option($option_name);   // get options of all instances
          unset($options[$instance]);            // remove this instance options
          update_option($option_name, $options);
        }

      // keep only the last 10 records from the inactive widgets area
      $new['wp_inactive_widgets'] = array_slice($new['wp_inactive_widgets'], -10, 10);

    }
    return $new;
  }



  public function addTab($newkey, $newlabel, $callback, $position = 30){
    $index = 0;
    $tabs = array();

    foreach($this->tabs as $key => $label){

      if(($index += 10) > $position)
        $tabs[$newkey] = $newlabel;

      $tabs[$key] = $label;
    }

    if(!isset($tabs[$newkey]))
      $tabs[$newkey] = $newlabel;

    $this->tabs = $tabs;

    Atom::add("settings_{$newkey}", $callback);
  }


  /**
   * Include js
   *
   * @since 1.0
   */
  public function js(){
    global $current_screen;

    // only load if we're one of the theme settings pages -- @todo: need to improve this
    if(in_array($current_screen->id, array('widgets', 'edit-post', 'upload', 'appearance_page_'.ATOM))){
      wp_enqueue_script('jquery');
      wp_enqueue_script('jquery-ui-core');
      wp_enqueue_script('interface', Atom::app()->jsURL('admin'));
      wp_enqueue_script('codemirror', Atom::app()->jsURL('codemirror'));
      wp_enqueue_script('post-message', Atom::app()->jsURL('pm'));

      Atom::action('admin_js');
    }
  }



  /**
   * Include admin/interface.css in the admin styles
   *
   * @since 1.0
   */
  public function css($dir){
    wp_enqueue_style(ATOM.'-settings', Atom::app()->get('theme_url').'/css/admin.css');
  }



  /**
   * Initialization js
   * @todo: clean up this mess..
   *
   * @since 1.0
   */
  public function footer(){
    global $current_screen;
    if(!in_array($current_screen->id, array('widgets', 'edit-post', 'upload', 'post', 'appearance_page_'.ATOM))) return;
    ?>
    <script type="text/javascript">
    /*<![CDATA[*/


    // Utility function that allows modes to be combined. The mode given
    // as the base argument takes care of most of the normal mode
    // functionality, but a second (typically simple) mode is used, which
    // can override the style of text. Both modes get to parse all of the
    // text, but when both assign a non-null style to a piece of code, the
    // overlay wins, unless the combine argument was true, in which case
    // the styles are combined.

    CodeMirror.overlayParser = function(base, overlay, combine) {
      return {
        startState: function() {
          return {
            base: CodeMirror.startState(base),
            overlay: CodeMirror.startState(overlay),
            basePos: 0, baseCur: null,
            overlayPos: 0, overlayCur: null
          };
        },
        copyState: function(state) {
          return {
            base: CodeMirror.copyState(base, state.base),
            overlay: CodeMirror.copyState(overlay, state.overlay),
            basePos: state.basePos, baseCur: null,
            overlayPos: state.overlayPos, overlayCur: null
          };
        },

        token: function(stream, state) {
          if (stream.start == state.basePos) {
            state.baseCur = base.token(stream, state.base);
            state.basePos = stream.pos;
          }
          if (stream.start == state.overlayPos) {
            stream.pos = stream.start;
            state.overlayCur = overlay.token(stream, state.overlay);
            state.overlayPos = stream.pos;
          }
          stream.pos = Math.min(state.basePos, state.overlayPos);
          if (stream.eol()) state.basePos = state.overlayPos = 0;

          if (state.overlayCur == null) return state.baseCur;
          if (state.baseCur != null && combine) return state.baseCur + " " + state.overlayCur;
          else return state.overlayCur;
        },

        indent: function(state, textAfter) {
          return base.indent(state.base, textAfter);
        },
        electricChars: base.electricChars
      };
    };
    CodeMirror.defineMode('atom/html', function(config, parserConfig) {
      var atomOverlay = {
        token: function(stream, state){
          if(stream.match("{")){
            while ((ch = stream.next()) != null && ch === ch.toUpperCase())
              if (ch == "}") break;
            return "atom-var";
          }
          while (stream.next() != null && !stream.match("{", false)) {}
          return null;
        }
      };
      return CodeMirror.overlayParser(CodeMirror.getMode(config, parserConfig.backdrop || "text/html"), atomOverlay);
    });




    function AtomEditorButton(tag){
      tb_show('<?php _ae('Insert Atom Element');  ?>', '<?php echo add_query_arg(array('action' => 'insert_editor_element', '_ajax_nonce' => $this->nonce), admin_url('admin-ajax.php')); ?>&element='+tag);
    }


    jQuery(document).ready(function($){

      var setupAtomSettings = function(){

          // codemirror
          $(".atom-block textarea.editor").each(function(i, el){
            CodeMirror.fromTextArea(document.getElementById($(this).attr('id')), {
             lineNumbers: true,
             matchBrackets: true,
             mode: $(this).attr('mode')
           });
          });

          $('textarea.resizable:not(.processed)').Resizer();

          // input dependancies (disable/enable them based on the rules attribute check)
          $(".atom-block [followRules]").setupDependencies();

          $('.toggle-select-all').toggle(function() {
            $(this).select();
          }, function() {
            $(this).unselect();
          });

          <?php Atom::action('admin_jquery_init'); ?>

      };


      // update check
      $("#theme-settings").delegate('#update-check', 'click', function(event){
        event.preventDefault();
        $.ajax({
          type: "get",
          url: "admin-ajax.php",
          data: { action: 'update_check', _ajax_nonce: '<?php echo $this->nonce; ?>' },
          context: this,
          beforeSend: function(){
            $(this).text("(<?php _ae('Checking...'); ?>)");
          },
          success: function(data){
            $(this).replaceWith(data);
          }
        });
      });

      // style splitter
      $("div[id*='atom-splitter-']").each(function(){
        $(this).addClass("atom-widget-splitter");
        $('.widget-control-actions .alignright', this).remove();
      })

      /*/ expand all widget areas by default
      $('#widgets-right').children('.widgets-holder-wrap').children('.sidebar-name').each(function(){
        var c = $(this).siblings('.widgets-sortables'), p = $(this).parent();
        p.removeClass('closed');
        c.sortable('enable').sortable('refresh');
      });
      //*/

      // simple ajax tabbed interface
      $('#theme-settings .atom-tabs .nav').delegate('a', 'click', function(){
        var tabs = $(this).parents('.atom-tabs'),
            target = $(this).attr('href').split('#')[1], // href is the ajax action
            content = $('.tab-content', tabs);

        $('.nav li', tabs).removeClass('active');
        $(this).parent('li').addClass('active');

        $.ajax({
          type: 'GET',
          url: 'admin-ajax.php',
          data: {
            action: 'get_tab',
            tab: target,
            _ajax_nonce: '<?php echo $this->nonce; ?>'
          },
          beforeSend: function() {
            content.addClass('loading');
          },
          success: function(data){
            content.removeClass('loading').html(data);
            setupAtomSettings();
            $.cookie('<?php echo ATOM; ?>-settings' , target, { path: '/' });
          }
        });

        return false;
      });

      // override if tab is present in hash
      $("#theme-settings .atom-tabs .nav a").each(function(){
        if(window.location.hash == $(this).attr('href')) $(this).trigger('click');
      });

      // visibility options button (fix wp save bug)
      $("#widgets-right .visibility-options.needfix").livequery(function(){
        var widget = $(this).closest('div.widget'),
            saveWidget = function(){
              wpWidgets.save(widget, 0, 1, 0);
            };

        // wait 1 second because we might get a empty instance again :(
        // -- @todo: find a better way to fix this bug
        setTimeout(saveWidget, 1000);
        return false;
      });

      <?php if(current_user_can('edit_posts')): ?>
      $('a.feature').click(function(event){
        event.preventDefault();
        var pos = $(this).attr('id').lastIndexOf('-');

        $.ajax({
          url: '<?php echo admin_url("admin-ajax.php"); ?>',
          type: 'GET',
          context: this,
          data: ({
            action: 'process_featured',
            id: $(this).attr('id').substr(++pos),
            isOn: ($(this).hasClass('on') ? 1 : 0),
            what: $(this).attr('rel'),
            _ajax_nonce: '<?php echo $this->nonce; ?>'
          }),
          beforeSend: function() {
            $(this).removeClass('on off').addClass('loading');
          },

          error: function(request){
            alert('<?php echo esc_js(_a("Error while featuring posts")); ?>');
            $(this).removeClass('loading').addClass('error');
          },

          success: function(data){
            $(this).removeClass('loading').addClass(data);
          }

        });
      });
      <?php endif; ?>

      // latest news rss
      $("#latest-news").each(function(){
        $.ajax({
          type: 'POST',
          url: "admin-ajax.php",
          data: { action: 'latest_news', _ajax_nonce: '<?php echo $this->nonce; ?>' },
          context: this,
          success: function(data){
            $(this).html(data);
            $('ul', this).animate({ opacity: 'show', height: 'show' }, 200).show();
          }
        });
      });

      // @todo: organize this in a single function...
      pm.bind("themepreview-load", function(data){

        $('#themepreview').Resizer({
          onEndDrag: function(iframe){
            $.cookie(iframe.attr('id')+'-height' , iframe.height(), { path: '/' });
          }
        });

        <?php if(Atom::app()->isOptionEnabled('layout')): ?>

        // dimensions, common variables
        // @todo: replace slider with a column splitter plugin
        var scale_grid_12 = ['|', '20', '|', '60', '|', '|', '|', '140', '|', '|', '|', '220', '|', '|', '|', '300', '|', '|', '|', '380', '|', '|', '|', '460', '|', '|', '|', '540', '|', '|', '|', '620', '|', '|', '|', '700', '|', '|', '|', '780', '|', '|', '|', '860', '|', '|', '|', '940', '|'],
            scale_fluid = ['0', '|', '10', '|', '20', '|', '30', '|', '40', '|','50', '|', '60', '|', '70', '|', '80', '|', '90', '|', '100'],
            page_width = '<?php echo(Atom::app()->options('page_width') == 'fluid' ? 'fluid' : 'fixed'); ?>',
            layout = '<?php echo Atom::app()->options('layout'); ?>',
            unit = '<?php echo(Atom::app()->options('page_width') == 'fluid' ? '%' : 'px'); ?>',
            gs = <?php echo(Atom::app()->options('page_width') == 'fluid' ? '100' : '960'); ?>,
            jstep = <?php echo(Atom::app()->options('page_width') == 'fluid' ? '1' : '10'); ?>,
            jscale = <?php echo(Atom::app()->options('page_width') == 'fluid' ? 'scale_fluid' : 'scale_grid_12'); ?>,
            set_slider = function(){
              $("#dimensions .current").html('');
              layout = $("input[name='layout']").val();
              if(layout != 'c1'){
                var current_dimensions = $('input#<?php echo ATOM; ?>_dimensions_'+page_width+'_'+layout).val();
                $("#dimensions .current").html('<input class="slider" type="hidden" value="'+current_dimensions+'" />');
                $("input.slider").slider({
                  from: 0,
                  to: gs,
                  step: jstep,
                  dimension: unit,
                  scale: jscale,
                  limits: false,
                  onstatechange: function(value){
                    pm({ // live preview
                      target: window.frames["themepreview"],
                      type: 'dimensions',
                      data: {layout: layout, sizes: value, unit: unit, gs: gs}
                    });
                    $('input#<?php echo ATOM; ?>_dimensions_'+page_width+'_'+layout).val(value);
                    return value;
                  }
                });
              }else{
                $("#dimensions .current").html('<label><small><?php _ae("Nothing to configure in single column mode"); ?></small></label>');
                  pm({ // live preview
                    target: window.frames["themepreview"],
                    type: 'dimensions',
                    data: {layout: layout, sizes: '0', unit: unit, gs: gs}
                  });
              }
            };

        // dimensions (column sizes)
        set_slider();

        // page width options
        $(".atom-block input[name='page_width']").change(function(){
          page_width = $(this).val();
          unit = (page_width == 'fluid') ? '%' : 'px';
          gs = (page_width == 'fluid') ? 100 : 960;
          jstep = (page_width == 'fluid') ? 1 : 10;
          jscale = (page_width == 'fluid') ? scale_fluid : scale_grid_12;
          pm({ // live preview
            target: window.frames["themepreview"],
            type: 'page_width',
            data: page_width
          });
          set_slider();
        });

        // max page width field
        $(".atom-block input[name='page_width_max']").bind('keyup mouseup change',function(e){
          page_width_max = $(this).val();
          pm({ // live preview
            target: window.frames["themepreview"],
            type: 'page_width_max',
            data: page_width_max
          });
          set_slider();
        });

        <?php endif; ?>

        // allow select type operations on links (nicer selects)
        $('#theme-settings a.select').click(function(){
          var button = $(this),
              option = $(this).parents("div[class*='-selector']").attr('id'),
              selected = $(this).attr('rel');

          button.parent().find('input.select').val(selected);
          button.parent().find('a').removeClass('active');
          button.addClass('active');
          if(option == 'layout') set_slider();
          pm({ // live preview
            target: window.frames["themepreview"],
            type: option,
            data: selected
          });
          return false;
        });

        // hidden input field (used for creating the nicer select inputs above)
        // not to be confused with input[type=select]
        $('#theme-settings input.select').change(function(){
          var data = $(this).val();
          $("#theme-settings a.select[rel='" + data + "']").addClass('active');
        }).change();


        // color picker
        $('.atom-block .color-selector').ColorPicker({
          onShow: function (colpkr){
            $(colpkr).css({ opacity: 0, marginTop: -10 }).show().animate({ opacity: 1, marginTop: 0 }, 160);
            $(this).ColorPickerSetColor($(this).find('input').val());
            return false;
          },
          onHide: function (colpkr) {
            $(colpkr).fadeOut(160);
            return false;
          },
          onChange: function (hsb, hex, rgb, el) {
            $(el).find(".preview").css('background-color', '#'+hex);
            $("input", el).val(hex);
            pm({ // live preview
              target: window.frames["themepreview"],
              type: "background-color",
              data: '#'+hex
            });
          }
        });

        // image upload buttons -- old stuff @todo: use wp swf uploader
        $('.atom-block a.upload').each(function(){
          var button = $(this);
          var option_name = $(this).attr('rel');
          var button_id = $(this).attr('id');
          new AjaxUpload(button_id, {
            action: '<?php echo admin_url("admin-ajax.php"); ?>',
            name: option_name, // file upload name
            data: { // Additional data to send
              action: 'process_upload',
              type: 'upload',
              _ajax_nonce: '<?php echo $this->nonce; ?>',
              data: option_name
            },
            autoSubmit: true, // Submit file after selection
            responseType: 'json',
            onChange: function(file, extension){},
            onSubmit: function(file, extension){
              button.text('<?php _ae("Uploading"); ?>'); // change button text, when user selects file
              this.disable(); // If you want to allow uploading only 1 file at time, you can disable upload button
              interval = window.setInterval(function(){
                var text = button.text();
                if (text.length < 13){ button.text(text + '.'); }
                else { button.text('<?php _ae("Uploading"); ?>'); }
              }, 200);
            },
            onComplete: function(file, response){
              window.clearInterval(interval);
              this.enable(); // enable upload button
              if(response.error != ''){ // we have a error
                $("div.error.upload").remove(); // remove the old error messages, if they exists
                $("#theme-settings-form").prepend('<div class="error upload"><p>'+response.error+'</p></div>');
                button.text('<?php _ae("Try Another Image?"); ?>');
                $("html").animate({scrollTop:0}, 333);
              } else {
                $("div.error.upload").remove();
                $("img", button.parent()).animate({ opacity: 0, top: -100 }, 200);
                $("img", button.parent()).attr('src', response.url).animate({ opacity: 1, top: 0 }, 200);

                $("a.reset_upload", button.parent()).fadeIn(150);
                button.text('<?php _ae("Change Image"); ?>');
                $("input[name='"+option_name+"']").val(response.url);
                pm({ // live preview
                  target: window.frames["themepreview"],
                  type: option_name,
                  data: response.url
                });
              }
            }
          });
        });

        // remove uploaded image button
        $('.atom-block a.reset_upload').click(function(){
          var button = $(this);
          var option_name = $(this).attr('rel');
          var button_id = $(this).attr('id');
          var data = {
            action: 'process_upload',
            type: 'reset_upload',
            _ajax_nonce: '<?php echo $this->nonce; ?>',
            data: option_name
          };
          $.post('<?php echo admin_url("admin-ajax.php"); ?>', data, function(response){
            $('#image-' + option_name).animate({ opacity: 0, top: -100 }, 200, function(){
               $(this).attr('src', '<?php echo Atom::app()->get('theme_url'); ?>/images/admin/x.gif');
            });
            button.fadeOut(150);
            $("a.upload", button.parent()).text('<?php _ae("Upload Image"); ?>');
            $("input[name='"+option_name+"']").val('');
            $("input[name='"+option_name+"']").val('');
            $("div.error.upload").remove();
            pm({ // live preview
              target: window.frames["themepreview"],
              type: option_name,
              data: 'remove'
            });
          });
          return false;
        });

        $('#atom-design-panel').animate({
          opacity: 'show',
          height: 'show',
          marginTop: 'show',
          marginBottom: 'show',
          paddingTop: 'show',
          paddingBottom: 'show'
        }, 333);

        $('#atom-design-panel-message').remove(); // remove js warning, might be that the iframe took more time to load then 5 seconds...

        set_slider(); // bug @todo: re-code slider for Atom

      });

      setupAtomSettings();

    });


    /*]]>*/
    </script>
    <?php
  //  endif;
  }


  private function getLanguageData($type = 'core'){

    if(!is_child_theme() && $type !== 'core') return array();

    $path = ($type !== 'user') ? TEMPLATEPATH : STYLESHEETPATH;

    $langs = get_available_languages($path.'/lang/');
    if(empty($langs)) return array();

    $mo = new MO();
    $data = array();
    foreach($langs as $lang){
      $mo->import_from_file($path.'/lang/'.$lang.'.mo');
      if(empty($mo->headers)) continue;
      $data[$lang][$type] = array(
       'translator' => preg_replace('/(?<!href=")http:\/\//','', make_clickable(strip_tags($mo->headers['Last-Translator']))),
       'language'   => strip_tags($mo->headers['X-Poedit-Language']),
       'version'    => strip_tags($mo->headers['Project-Id-Version']),
      );

      // more accurate
      if(function_exists('format_code_lang'))
        $data[$lang][$type]['language'] = format_code_lang($lang);


    }

    return $data;
  }



  public function addMenu(){

    // appearance menu
    $this->page = add_theme_page(
      Atom::app()->get('theme_name'),
      Atom::app()->get('theme_name'),
      'edit_theme_options',     // show the theme settings to all users who can edit_theme_options
      ATOM,
      array(&$this, 'settings') // function below
    );

    add_thickbox();

    Atom::action("add_menu", &$this);
  }


  public function getTab(){
    $app = &Atom::app();

    if(defined('DOING_AJAX')){
      check_ajax_referer('theme-settings');
      $tab = esc_attr(strip_tags($_GET['tab']));
    }else{
      $tab = isset($_COOKIE[ATOM.'-settings']) ? esc_attr(strip_tags($_COOKIE[ATOM.'-settings'])) : 'welcome';
    }

    switch($tab):
      case 'welcome':
        ?>
        <!-- tab: welcome -->
        <div class="clear-block">

          <div class="alignleft" style="width: 69%">
            <h3 class="title"><?php _ae("General Info"); ?></h3>
            <ul class="ul-disc">
              <li>
                <?php printf(_a("Core (ATOM) version: %s"), '<strong>'.ATOM_VERSION.'</strong>'); ?>
              </li>
              <li>
                <?php printf(_a("Theme Version: %s"), '<strong>'.$app->get('theme_version').'</strong>'); ?> <?php if(is_child_theme()) printf(_a("(Child theme of %s)"), $app->get('theme_name')); ?>
                 <?php if(isset($update_link)): echo $update_link; else: ?><a id="update-check" href="#">(<?php _ae("Check for update"); ?>)</a><?php endif; ?>
              </li>
            </ul>

            <ul class="ul-disc">
              <li><a href="<?php echo Atom::THEME_DOC_URI; ?>" target="_blank"><strong><?php _ae("Theme documentation"); ?></strong></a></li>
              <li><a href="<?php echo $app->get('theme_uri'); ?>" target="_blank"><?php _ae("Project Homepage"); ?></a></li>
            </ul>

            <?php


              $langs = array_merge_recursive($this->getLanguageData('user'), $this->getLanguageData('core'));

              $current_lang = '';
              $locale = get_locale();
              if(!empty($langs[$locale]['core']))
                $current_lang = $langs[$locale]['core'];

              if(!empty($langs[$locale]['user']))
                $current_lang = $langs[$locale]['user'];

            ?>
            <?php if(!empty($langs)): ?>

            <h3 class="title"><?php _ae('Available Languages'); ?></h3>

            <ul class="ul-disc">
             <?php
               foreach($langs as $locale => $versions)
                 foreach($versions as $type => $lang){
                   $active = ($lang !== $current_lang) ? '' : 'style="color:#339900;font-weight:bold;"';
                   $nfo = sprintf(_a('%1$s - Translator: %2$s (%3$s)'), $lang['language'], "<strong>{$lang['translator']}</strong>", "{$lang['version']}");
                   echo '<li '.$active.'>'.$nfo.'</li>';
                 }
             ?>
            </ul>
           <?php endif; ?>

            <?php if(current_user_can('edit_themes')): ?>
            <h3 class="title"><?php _ae("Import / export / reset or backup Theme Options"); ?></h3>
            <label><small><?php _ae("If you wish to import or export theme settings from another website that's using this theme, you may do so here. Below you can copy the current settings stored as a encoded string, or paste new settings..."); ?></small></label>

            <?php
              // we could use base 64 encoding for this, but then we get complaints for all those retarded "theme-checking" plugins out there.
              $encoded_settings = chunk_split(bin2hex(serialize($app->options())), 90, "\n");
            ?>
            <textarea spellcheck="false" cols="6" rows="18" class="code toggle-select-all" id="gtg" name="import_data"><?php echo $encoded_settings; ?></textarea>

            <div class="clear-block">
              <p class="alignright">
                <input type="submit" class="button-primary" name="reset" value="<?php _ae("Reset options to defaults"); ?>" onclick="if(confirm('<?php _ae("Reset all theme settings to the default values? Are you sure?"); ?>')) return true; else return false;" />
                <input type="submit" name="import" class="button-primary" value="<?php _ae("Import options"); ?>" onclick="if(confirm('<?php _ae("Import these settings? Are you sure?"); ?>')) return true; else return false;"  />
              </p>
            </div>
            <?php endif; ?>
            <?php Atom::action("settings_main"); ?>

          </div>
          <div class="alignright" style="width: 30%;" id="latest-news"> <!-- dn.eu news go here --> </div>

        </div>
        <!-- /tab: welcome -->
        <?php


      break;

      case 'design':
        ?>

        <!-- tab: design -->
        <div class="clear-block">

          <?php if($app->options('jquery')): ?>
          <div id="themepreview-wrap" class="resizable-wrapper">

            <?php $height = isset($_COOKIE['themepreview-height']) ? 'style="height:'.(int)$_COOKIE['themepreview-height'].'px;"' : ''; ?>
            <iframe id="themepreview" name="themepreview" src="<?php echo home_url(); ?>/?themepreview=1" class="resizable" <?php echo $height; ?>></iframe>

          </div>
          <?php endif; ?>
          <div id="atom-design-panel-message"><p><?php _ae('Loading...'); ?></p></div>
          <script type="text/javascript">
            // cool javascript error handler -- need to add this somehow as a debug message for the front-end too ;)
            jQuery(document).ready(function($){
              setTimeout(function(){
                if($('#atom-design-panel').is(':visible')){
                  $('#atom-design-panel-message').remove();
                }else{
                  $('#atom-design-panel-message').addClass('error').html('<p><?php echo esc_js(_a('It appears that your home page has javascript errors on it. Deactivate all plugins, then activate them back one by one to find out which one is causing errors.')); ?></p>');
                }
              }, 5 * 1000); // check after 5 seconds (maybe we should extend this?)
            });
          </script>
          <div class="metabox-holder flow clear-block hidden" id="atom-design-panel">

            <?php if($app->isOptionEnabled('layout')): ?>

            <div class="postbox wide">
               <h3><span><?php _ae("Layout Style (Global)"); ?></span></h3>
               <div class="inside clear-block">
                 <div class="layout-selector" id="layout">
                   <div class="clear-block">
                     <a href="#" rel="c1" class="select c1" title="<?php _ae("One column (No sidebars)"); ?>"></a>
                     <a href="#" rel="c2left" class="select c2left" title="<?php _ae("Two columns, left sidebar"); ?>"></a>
                     <a href="#" rel="c2right" class="select c2right" title="<?php _ae("Two columns, right sidebar"); ?>"></a>
                     <a href="#" rel="c3" class="select c3" title="<?php _ae("Three columns"); ?>"></a>
                     <a href="#" rel="c3left" class="select c3left" title="<?php _ae("Three columns, sidebars to the left"); ?>"></a>
                     <a href="#" rel="c3right" class="select c3right" title="<?php _ae("Three columns, sidebars to the right"); ?>"></a>
                     <input type="hidden" class="select" name="layout" value="<?php echo $app->options('layout'); ?>" />
                   </div>
                   <div class="clear-block">
                     <p>
                       <label><small><?php printf(_a("Note that widget visibility options can be used to override this setting for individual pages or posts (you can also select the appropriate template when editing pages, or use the %s custom field)"), '<code>layout</code>'); ?></small></label>
                     </p>
                   </div>
                 </div>

               </div>
            </div>

            <div class="postbox wide">
               <h3><span><?php _ae("Column Sizes"); ?></span></h3>
               <div class="inside clear-block" id="dimensions">
                  <input type="hidden" id="<?php echo ATOM; ?>_dimensions_fixed_c2left" name="dimensions_fixed_c2left" value="<?php echo $app->options('dimensions_fixed_c2left'); ?>" />
                  <input type="hidden" id="<?php echo ATOM; ?>_dimensions_fixed_c2right" name="dimensions_fixed_c2right" value="<?php echo $app->options('dimensions_fixed_c2right'); ?>" />
                  <input type="hidden" id="<?php echo ATOM; ?>_dimensions_fixed_c3" name="dimensions_fixed_c3" value="<?php echo $app->options('dimensions_fixed_c3'); ?>" />
                  <input type="hidden" id="<?php echo ATOM; ?>_dimensions_fixed_c3left" name="dimensions_fixed_c3left" value="<?php echo $app->options('dimensions_fixed_c3left'); ?>" />
                  <input type="hidden" id="<?php echo ATOM; ?>_dimensions_fixed_c3right" name="dimensions_fixed_c3right" value="<?php echo $app->options('dimensions_fixed_c3right'); ?>" />

                  <input type="hidden" id="<?php echo ATOM; ?>_dimensions_fluid_c2left" name="dimensions_fluid_c2left" value="<?php echo $app->options('dimensions_fluid_c2left'); ?>" />
                  <input type="hidden" id="<?php echo ATOM; ?>_dimensions_fluid_c2right" name="dimensions_fluid_c2right" value="<?php echo $app->options('dimensions_fluid_c2right'); ?>" />
                  <input type="hidden" id="<?php echo ATOM; ?>_dimensions_fluid_c3" name="dimensions_fluid_c3" value="<?php echo $app->options('dimensions_fluid_c3'); ?>" />
                  <input type="hidden" id="<?php echo ATOM; ?>_dimensions_fluid_c3left" name="dimensions_fluid_c3left" value="<?php echo $app->options('dimensions_fluid_c3left'); ?>" />
                  <input type="hidden" id="<?php echo ATOM; ?>_dimensions_fluid_c3right" name="dimensions_fluid_c3right" value="<?php echo $app->options('dimensions_fluid_c3right'); ?>" />

                  <div class="current"><?php // the slider input is added with jquery ?></div>
               </div>
            </div>

            <?php endif; ?>

            <div class="block alignleft">

              <?php if($app->isOptionEnabled('layout')): ?>

              <div class="postbox">
                 <h3><span><?php _ae("Page Width"); ?></span></h3>
                 <div class="inside clear-block">

                   <div class="entry">
                     <label for="<?php echo ATOM; ?>_page_width_fixed">
                       <input name="page_width" id="<?php echo ATOM; ?>_page_width_fixed" type="radio" followRules class="radio" value="fixed" <?php checked('fixed', $app->options('page_width')); ?> />
                       <?php printf(_a("Fixed (%s)"), '<a href="http://960.gs">960gs</a>'); ?>
                     </label>
                   </div>

                   <div class="entry">
                     <label for="<?php echo ATOM; ?>_page_width_fluid">
                       <input name="page_width" id="<?php echo ATOM; ?>_page_width_fluid" type="radio" followRules class="radio" value="fluid" <?php checked('fluid', $app->options('page_width')); ?> />
                       <?php printf(_a("Fluid, but not more than %s pixels"), '<label><input size="4" followRules rules="DEPENDS ON page_width BEING fluid" name="page_width_max" id="'.ATOM.'_page_width_max" type="text" value="'.$app->options('page_width_max').'" /></label>'); ?>
                     </label>
                   </div>

                   <div class="entry">
                     <label class="disabled" title="Not yet implemented">
                       <input disabled="disabled" type="radio" class="radio disabled" />
                       <?php _ae("Semi-Fluid (Fixed Sidebars)"); ?>
                     </label>
                   </div>

                 </div>
              </div>

              <?php endif; ?>

              <?php if($app->isOptionEnabled('logo')): ?>
              <div class="postbox upload-block">
                 <h3><span><?php _ae("Site Title (Logo)"); ?></span></h3>
                 <div class="inside clear-block">

                  <img id="image-logo" class="image-upload" src="<?php echo ($logo = $app->options('logo')) ? $logo : $app->get('theme_url').'/images/admin/x.gif'; ?>" title="<?php _ae('Current logo image'); ?>" />
                  <a class="button reset_upload alignright <?php if(!$logo): ?>hidden<?php endif; ?>" id="<?php echo ATOM; ?>_reset_logo" rel="logo"><?php _ae("Remove"); ?></a>
                  <a class="button upload alignright" id="<?php echo ATOM; ?>_logo" rel="logo"><?php _ae($logo ? ('Change Image') : ('Upload Image')); ?></a>
                  <input type="hidden" name="logo" value="<?php echo $logo; ?>" />
                 </div>
              </div>
              <?php endif; ?>
            </div>

            <div class="block alignright">

              <?php if($app->isOptionEnabled('color_scheme')): ?>
              <div class="postbox">
                 <h3><span><?php _ae("Styles &amp; colors"); ?></span></h3>
                 <div class="inside clear-block">

                   <div class="clear-block colorscheme-selector" id="color-scheme">
                     <?php
                      foreach($app->getStyles() as $scheme):
                       echo '<a href="#" rel="'.$scheme['id'].'" class="select" style="background-color:'.$scheme['color'].'" title="'.sprintf(_a('%1$s by %2$s'), $scheme['name'], $scheme['author']).'">'.$scheme['name'].'</a>';

                      endforeach;
                     ?>
                     <a href="#" rel="" class="select no-style" title="<?php _ae("Disabled"); ?> (<?php _ae("use custom styles"); ?>)"><?php _ae("Blank"); ?></a>
                     <input type="hidden" class="select" name="color_scheme" value="<?php echo $app->options("color_scheme"); ?>" />
                   </div>
                 </div>
              </div>
              <?php endif; ?>

              <?php if($app->isOptionEnabled('background_image') || $app->isOptionEnabled('background_color')): ?>
              <div class="postbox upload-block">
                 <h3><span><?php _ae("Page Background"); ?></span></h3>
                 <div class="inside clear-block">

                 <?php if($app->isOptionEnabled('background_image')): ?>
                  <img id="image-background_image" class="image-upload" src="<?php echo ($background = $app->options('background_image')) ? $background : $app->get('theme_url').'/images/admin/x.gif'; ?>" title="<?php _ae("Current background image"); ?>" />

                   <a class="button reset_upload alignright <?php if(!$background): ?>hidden<?php endif; ?>" id="<?php echo ATOM; ?>_reset_background" rel="background_image"><?php _ae("Remove"); ?></a>
                   <a class="button upload alignright" id="<?php echo ATOM; ?>_background" rel="background_image"><?php _ae($background ? ("Change Image") : ("Upload Image")); ?></a>
                   <input type="hidden" name="background_image" value="<?php echo $background; ?>" />
                 <?php endif; ?>

                 <?php if($app->isOptionEnabled('background_color')): ?>
                   <div class="color-selector alignleft" id="<?php echo ATOM; ?>_background_color">
                     <div class="preview" style="background-color: #<?php echo esc_html($app->options('background_color')); ?>">
                       <input name="background_color" type="hidden" value="<?php echo esc_html($app->options('background_color')); ?>" />
                     </div>
                   </div>
                 <?php endif; ?>

                 </div>
              </div>
              <?php endif; ?>

              <?php if($app->isOptionEnabled('favicon')): ?>
              <div class="postbox upload-block">
                 <h3><span><?php _ae("Favicon"); ?></span></h3>
                 <div class="inside clear-block">

                  <img id="image-favicon" class="alignleft image-upload" src="<?php echo ($favicon = $app->options('favicon')) ? $favicon : $app->get('theme_url').'/images/admin/x.gif'; ?>" title="<?php _ae("Current favicon"); ?>" width="16" height="16" />

                  <a class="button reset_upload alignright <?php if(!$favicon): ?>hidden<?php endif; ?>" id="<?php echo ATOM; ?>_reset_favicon" rel="favicon"><?php _ae("Remove"); ?></a>
                  <a class="button upload alignright" id="<?php echo ATOM; ?>_favicon" rel="favicon"><?php _ae($favicon ? ("Change Image") : ("Upload Image")); ?></a>
                  <input type="hidden" name="favicon" value="<?php echo $favicon; ?>" />
                 </div>
              </div>
              <?php endif; ?>

            </div>

          </div>

          <?php Atom::action("settings_design"); ?>

        </div>
        <!-- /tab: design -->
        <?php
      break;

      case 'content_options':
        ?>

        <!-- tab: content options -->
        <div class="clear-block">


           <?php if($app->isOptionEnabled('footer_content')): ?>
           <div class="block wide">
             <h3 class="title"><?php _ae('Footer content'); ?></h3>
             <p>
             <textarea mode="text/html" rows="10" cols="60" name="footer_content" id="<?php echo ATOM; ?>_footer_content" class="code editor widefat"><?php echo esc_html($app->options('footer_content')); ?></textarea>
             </p>
             <label>
               <small>
                <?php  if(current_user_can('unfiltered_html')) _ae('You can add HTML code.'); else _ae('HTML is allowed, but some tags may be filtered out for security reasons.'); ?>

                <?php printf(_a('Use %s for convenient adjustments'), '<a href="'.Atom::THEME_DOC_URI.'/shortcodes/" target="_blank">'._a('[shortcodes]').'</a>'); ?>
               </small>
             </label>
          </div>

           <?php endif; ?>

           <div class="block alignleft">

             <?php if($app->isOptionEnabled('post')): ?>

               <h3 class="title"><?php _ae('Post Previews'); ?></h3>

                 <?php if ($app->isOptionEnabled('post_title')): ?>
                 <div class="entry">
                   <label for="<?php echo ATOM; ?>_post_title">
                     <input type="hidden" name="post_title" value="0">
                     <input id="<?php echo ATOM; ?>_post_title" name="post_title" type="checkbox" value="1" <?php checked('1', $app->options('post_title')) ?> />
                     <?php _ae("Title"); ?>
                   </label>
                 </div>
                 <?php endif; ?>

                 <?php if($app->isOptionEnabled('post_content')): ?>
                 <div class="entry">
                   <label for="<?php echo ATOM; ?>_post_content">
                     <input type="hidden" name="post_content" value="0">
                     <input id="<?php echo ATOM; ?>_post_content" name="post_content" followRules type="checkbox" value="1" <?php checked('1', $app->options('post_content')) ?> />
                     <?php _ae("Content"); ?>
                   </label>
                   <select name="post_content_mode" id="<?php echo ATOM; ?>_post_content_mode" class="followRules" followRules rules="DEPENDS ON post_content">
                      <option value="f" <?php selected('f', $app->options('post_content_mode')) ?>><?php _ae("Full post"); ?></option>
                      <option value="ff" <?php selected('ff', $app->options('post_content_mode')) ?>><?php _ae("Full post, filtered"); ?></option>
                      <option value="e" <?php selected('e', $app->options('post_content_mode')) ?>><?php _ae("Excerpt"); ?></option>
                      <option value="50" <?php selected('50', $app->options('post_content_mode')) ?>><?php printf(_a("First %s words, filtered"), 50); ?></option>
                      <option value="100" <?php selected('100', $app->options('post_content_mode')) ?>><?php printf(_a("First %s words, filtered"), 100); ?></option>
                      <option value="150" <?php selected('150', $app->options('post_content_mode')) ?>><?php printf(_a("First %s words, filtered"), 150); ?></option>
                   </select>
                 </div>
                 <?php endif; ?>

                 <?php if($app->isOptionEnabled('post_category')): ?>
                 <div class="entry">
                   <label for="<?php echo ATOM; ?>_post_category">
                     <input type="hidden" name="post_category" value="0">
                     <input id="<?php echo ATOM; ?>_post_category" name="post_category" type="checkbox" value="1" <?php checked('1', $app->options('post_category')) ?> />
                     <?php _ae("Category"); ?>
                   </label>
                 </div>
                 <?php endif; ?>

                 <?php if($app->isOptionEnabled('post_date')): ?>
                 <div class="entry">
                   <label for="<?php echo ATOM; ?>_post_date">
                     <input type="hidden" name="post_date" value="0">
                     <input id="<?php echo ATOM; ?>_post_date" name="post_date" followRules type="checkbox" value="1" <?php checked('1', $app->options('post_date')) ?> />
                     <?php _ae("Date/Time"); ?>
                   </label>
                   <select name="post_date_mode" id="<?php echo ATOM; ?>_post_date_mode" followRules rules="DEPENDS ON post_date">
                      <option value="relative" <?php selected('relative', $app->options('post_date_mode')) ?>><?php _ae("Relative (Time Since)"); ?></option>
                      <option value="absolute" <?php selected('absolute', $app->options('post_date_mode')) ?>><?php _ae("Absolute (Use Time/Date settings)"); ?></option>
                   </select>
                 </div>
                 <?php endif; ?>

                 <?php if($app->isOptionEnabled('post_author')): ?>
                 <div class="entry">
                   <label for="<?php echo ATOM; ?>_post_author">
                     <input type="hidden" name="post_author" value="0">
                     <input id="<?php echo ATOM; ?>_post_author" name="post_author" type="checkbox" value="1" <?php checked('1', $app->options('post_author')) ?> />
                     <?php _ae("Author"); ?>
                   </label>
                 </div>
                 <?php endif; ?>

                 <?php if($app->isOptionEnabled('post_comments')): ?>
                 <div class="entry">
                   <label for="<?php echo ATOM; ?>_post_comments">
                     <input type="hidden" name="post_comments" value="0">
                     <input id="<?php echo ATOM; ?>_post_comments" name="post_comments" type="checkbox" value="1" <?php checked('1', $app->options('post_comments')) ?> />
                     <?php _ae("Comments Link"); ?>
                   </label>
                 </div>
                 <?php endif; ?>

                 <?php if($app->isOptionEnabled('post_tags')): ?>
                 <div class="entry">
                   <label for="<?php echo ATOM; ?>_post_tags">
                     <input type="hidden" name="post_tags" value="0">
                     <input id="<?php echo ATOM; ?>_post_tags" name="post_tags" type="checkbox" value="1" <?php checked('1', $app->options('post_tags')) ?> />
                     <?php _ae("Tags"); ?>
                   </label>
                 </div>
                 <?php endif; ?>

                 <?php if($app->isOptionEnabled('post_thumbs')): ?>
                 <div class="entry">
                   <label for="<?php echo ATOM; ?>_post_thumbs">
                     <input type="hidden" name="post_thumbs" value="0">
                     <input id="<?php echo ATOM; ?>_post_thumbs" name="post_thumbs" followRules type="checkbox" value="1" <?php checked('1', $app->options('post_thumbs')) ?> />
                     <?php _ae("Thumbnails"); ?>
                   </label>
                   <?php if ($app->isOptionEnabled('post_thumbs_mode')): ?>
                   <select name="post_thumbs_mode" id="<?php echo ATOM; ?>_post_thumbs_mode" followRules rules="DEPENDS ON post_thumbs">
                     <option value="left" <?php selected('left', $app->options('post_thumbs_mode')) ?>><?php _ae("Left Aligned"); ?></option>
                     <option value="right" <?php selected('right', $app->options('post_thumbs_mode')) ?>><?php _ae("Right Aligned"); ?></option>
                   </select>
                   <?php endif; ?>
                 </div>

                 <hr />

                 <?php if($app->isOptionEnabled('post_thumb_size')):

                   $sizes = array(
                     '90x90'    => sprintf(_a('Small, %s'), '90 x 90'),
                     '120x120'  => sprintf(_a('Medium, %s'), '120 x 120'),
                     '140x140'  => sprintf(_a('Large, %s'), '140 x 140'),
                     '60x60'    => sprintf(_a('Very Small, %s'), '60 x 60'),
                     '180x180'  => sprintf(_a('Larger, %s'), '180 x 180'),
                     '200x200'  => sprintf(_a('Very Large, %s'), '200 x 200'),
                   );

                   $default_settings = $app->getDefaultOptions();
                   $sizes[$default_settings['post_thumb_size']] =  sprintf(_a('Theme Default, %s'), str_replace('x', ' x ', $default_settings['post_thumb_size']));

                   $sizes = apply_filters('atom_user_thumbnail_sizes', $sizes, $default_settings);
                   ksort($sizes, SORT_NUMERIC);
                 ?>
                 <div class="entry">
                   <label for="<?php echo ATOM; ?>_post_thumb_size">
                     <?php _ae("Thumbnail Size"); ?>
                     <select name="post_thumb_size" id="<?php echo ATOM; ?>_post_thumb_size" followRules rules="DEPENDS ON post_thumbs">
                        <?php foreach($sizes as $size => $label): ?>
                        <option value="<?php echo $size; ?>" <?php selected($size, $app->options('post_thumb_size')) ?>>
                          <?php echo $label; ?>
                        </option>
                        <?php endforeach; ?>
                        <option disabled="disabled">
                          -------------------------------
                        </option>
                        <option value="media" <?php selected('media', $app->options('post_thumb_size')); ?>>
                          <?php printf(_a("Media setting, %s"), get_option('thumbnail_size_w').' x '.get_option('thumbnail_size_h')); ?>
                        </option>

                     </select>
                     <small><?php _ae("Note that for the new sized thumbnails to take effect, all existing images must be resized. See the Advanced page."); ?>
                     </small>

                   </label>
                 </div>
                 <?php endif; ?>

                 <?php if ($app->isOptionEnabled('post_thumb_auto')): ?>
                 <div class="entry">
                   <label for="<?php echo ATOM; ?>_post_thumb_auto">
                     <input type="hidden" name="post_thumb_auto" value="0">
                     <input id="<?php echo ATOM; ?>_post_thumb_auto" name="post_thumb_auto" class="followRules" followRules rules="DEPENDS ON post_thumbs" type="checkbox" value="1" <?php checked('1', $app->options('post_thumb_auto')) ?> />
                     <?php _ae("Use first attachment as thumbnail, if none is set"); ?>
                   </label>
                 </div>
                 <?php endif; ?>
                 <?php endif; ?>


                 <hr />
                 <?php if($app->isOptionEnabled('post_navi')): ?>
                 <div class="entry">
                   <label for="<?php echo ATOM; ?>_post_navi"><?php _ae('Navigation'); ?></label>
                   <select name="post_navi" id="<?php echo ATOM; ?>_post_navi">
                      <option value="single" <?php selected('single', $app->options('post_navi')) ?>><?php printf(_a('Single link (%s)'), 'AJAX'); ?></option>
                      <option value="prevnext" <?php selected('prevnext', $app->options('post_navi')) ?>><?php _ae('Previous / Next links'); ?></option>
                      <option value="numbers" <?php selected('numbers', $app->options('post_navi')) ?>><?php _ae('Page numbers'); ?></option>
                   </select>
                 </div>
                 <?php endif; ?>


             <?php endif; ?>

            <?php if($app->isOptionEnabled('comment')): ?>

               <h3 class="title"><?php _ae("Comments"); ?></h3>

                 <?php if($app->isOptionEnabled('comment_filter')): ?>
                 <div class="entry">
                   <label for="<?php echo ATOM; ?>_comment_filter">
                     <input type="hidden" name="comment_filter" value="0">
                     <input id="<?php echo ATOM; ?>_comment_filter" name="comment_filter" type="checkbox" value="1" <?php checked('1', $app->options('comment_filter')) ?> />
                     <?php _ae("Display Comment Search Form"); ?>
                   </label>
                 </div>
                 <?php endif; ?>

                 <?php if($app->isOptionEnabled('comment_karma')): ?>
                 <div class="entry">
                   <label for="<?php echo ATOM; ?>_comment_karma">
                     <input type="hidden" name="comment_karma" value="0">
                     <input id="<?php echo ATOM; ?>_comment_karma" name="comment_karma" followRules type="checkbox" value="1" <?php checked('1', $app->options('comment_karma')) ?> />
                     <?php _ae("Allow Comment Ratings (Karma)"); ?>
                   </label>
                 </div>

                 <?php if($app->isOptionEnabled('comment_bury_limit')): ?>
                 <div class="entry">
                   <label for="<?php echo ATOM; ?>_comment_bury_limit">
                     <?php printf(_a("Hide comments with %s karma and below"), '<label><input size="4" followRules rules="DEPENDS ON comment_karma" name="comment_bury_limit" id="'.ATOM.'_comment_bury_limit" type="text" value="'.$app->options('comment_bury_limit').'" /></label>'); ?>
                   </label>
                 </div>
                 <?php endif; ?>
                 <?php endif; ?>

                 <?php Atom::action("settings_content_comment"); ?>

             <?php endif; ?>

           </div>

           <div class="block alignright">

             <?php if($app->isOptionEnabled('single')): ?>

               <h3 class="title"><?php _ae("Single Post Page"); ?></h3>

                 <?php if($app->isOptionEnabled('single_links')): ?>
                 <div class="entry">
                   <label for="<?php echo ATOM; ?>_single_links">
                     <input type="hidden" name="single_links" value="0">
                     <input id="<?php echo ATOM; ?>_single_links" name="single_links" type="checkbox" value="1" <?php checked('1', $app->options('single_links')) ?> />
                     <?php _ae("Previous/Next Links"); ?>
                   </label>
                 </div>
                 <?php endif; ?>

                 <hr />

                 <?php if($app->isOptionEnabled('single_share')): ?>
                 <div class="entry">
                   <label for="<?php echo ATOM; ?>_single_share">
                     <input type="hidden" name="single_share" value="0">
                     <input id="<?php echo ATOM; ?>_single_share" name="single_share" type="checkbox" value="1" <?php checked('1', $app->options('single_share')) ?> />
                     <?php _ae("Share Links"); ?>
                   </label>
                 </div>
                 <?php endif; ?>

                 <?php if($app->isOptionEnabled('single_meta')): ?>
                 <div class="entry">
                   <label for="<?php echo ATOM; ?>_single_meta">
                     <input type="hidden" name="single_meta" value="0">
                     <input id="<?php echo ATOM; ?>_single_meta" name="single_meta" type="checkbox" value="1" <?php checked('1', $app->options('single_meta')) ?> />
                     <?php _ae("Meta Information"); ?>
                   </label>
                 </div>
                 <?php endif; ?>

                 <hr />

                 <?php if($app->isOptionEnabled('single_author')): ?>
                 <div class="entry">
                   <label for="<?php echo ATOM; ?>_single_author">
                     <input type="hidden" name="single_author" value="0">
                     <input id="<?php echo ATOM; ?>_single_author" name="single_author" type="checkbox" value="1" <?php checked('1', $app->options('single_author')) ?> />
                     <?php _ae("About the Author"); ?>
                   </label>
                 </div>
                 <?php endif; ?>

                 <?php if($app->isOptionEnabled('single_related')): ?>
                 <div class="entry">
                   <label for="<?php echo ATOM; ?>_single_related">
                     <input type="hidden" name="single_related" value="0">
                     <input id="<?php echo ATOM; ?>_single_related" name="single_related" type="checkbox" value="1" <?php checked('1', $app->options('single_related')) ?> />
                     <?php _ae("Related Posts"); ?>
                   </label>
                 </div>
                 <?php endif; ?>

             <?php endif; ?>

             <?php if($app->isOptionEnabled('media')): ?>
               <h3 class="title"><?php _ae("Social Media Links (Leave blank to disable)"); ?></h3>


      <div class="notice e">
        This feature is deprecated and will be removed in future versions. Please activate and use the <strong>Social-Media Icons</strong> module instead.
      </div>

                 <?php if($app->isOptionEnabled('media_rss')): ?>
                 <div class="entry">
                  <p><label for="<?php echo ATOM; ?>_media_rss"><?php _ae("RSS Feed"); ?></label></p>
                  <input id="<?php echo ATOM; ?>_media_rss" size="40" name="media_rss" type="text" value="<?php echo $app->options('media_rss'); ?>" />
                 </div>
                 <?php endif; ?>

                 <?php if($app->isOptionEnabled('media_twitter')): ?>
                 <div class="entry">
                  <p><label for="<?php echo ATOM; ?>_media_twitter">Twitter</label></p>
                  <input id="<?php echo ATOM; ?>_media_twitter" size="40" name="media_twitter" type="text" value="<?php echo $app->options('media_twitter'); ?>" />
                 </div>
                 <?php endif; ?>

                 <?php if($app->isOptionEnabled('media_facebook')): ?>
                 <div class="entry">
                  <p><label for="<?php echo ATOM; ?>_media_facebook">Facebook</label></p>
                  <input id="<?php echo ATOM; ?>_media_facebook" size="40" name="media_facebook" type="text" value="<?php echo $app->options('media_facebook'); ?>" />
                 </div>
                 <?php endif; ?>

                 <?php if($app->isOptionEnabled('media_flickr')): ?>
                 <div class="entry">
                  <p><label for="<?php echo ATOM; ?>_media_flickr">Flickr</label></p>
                  <input id="<?php echo ATOM; ?>_media_flickr" size="40" name="media_flickr" type="text" value="<?php echo $app->options('media_flickr'); ?>" />
                 </div>
                 <?php endif; ?>

                 <?php if($app->isOptionEnabled('media_myspace')): ?>
                 <div class="entry">
                  <p><label for="<?php echo ATOM; ?>_media_myspace">MySpace</label></p>
                  <input id="<?php echo ATOM; ?>_media_myspace" size="40" name="media_myspace" type="text" value="<?php echo $app->options('media_myspace'); ?>" />
                 </div>
                 <?php endif; ?>

                <?php Atom::action("settings_content_media"); // allow extra options here ?>

             <?php endif; ?>

           </div>

          <?php Atom::action("settings_content"); ?>

        </div>
        <!-- /tab: content options -->

        <?php
      break;

      case 'user_css':
        ?>
        <!-- tab: user css -->
        <div class="clear-block">

          <div class="notice">
            <label for="<?php echo ATOM; ?>_css">
             <?php printf(_a("Check %s to see existing theme classes and properties, which you can redefine here."), '<a target="_blank" href="'.$app->get('theme_url').'/css/core.css">css/core.css</a>'); ?>
             <br />
             <?php printf(_a('All URLs must have absolute paths. You can use the %1$s keyword to point to the %2$s.'), '<code>{THEME_URL}</code>', '<abbr title="'.$app->get('theme_url').'">'._a('parent theme URL').'</abbr>'); ?>
             <?php if(is_child_theme()): ?>
             <br />
             <?php printf(_a('To get the child theme URL use %s.'), '<code>{CHILD_THEME_URL}</code>'); ?>
             <?php endif; ?>
             <?php printf(_a("Read the %s to see all available keywords."), '<a href="'.Atom::THEME_DOC_URI.'" target="_blank">'._a("documentation").'</a>'); ?>
            </label>
          </div>


          <p>
           <textarea mode="text/css" rows="38" cols="60" name="css" id="<?php echo ATOM; ?>_css" class="code editor widefat"><?php echo esc_html($app->options('css')); ?></textarea>
          </p>

          <?php Atom::action("settings_css"); ?>

        </div>
        <!-- /tab: user css -->
        <?php
      break;

      case 'advanced':
        ?>
       <!-- tab: advanced -->
        <div class="clear-block">

          <div class="row clear-block">
           <label for="<?php echo ATOM; ?>_jquery">
            <input type="hidden" name="jquery" value="0">
            <input id="<?php echo ATOM; ?>_jquery" name="jquery" class="checkbox" followRules type="checkbox" value="1" <?php checked('1', $app->options('jquery')) ?> />
            <?php _ae("Use jQuery"); ?>
            <small class="indent">
              <?php _ae("Only uncheck if you know what you're doing. Your site will load faster without jQuery, but features that depend on it will be disabled."); ?>
            </small>
           </label>
          </div>

          <div class="row clear-block">
           <label for="<?php echo ATOM; ?>_effects">
            <input type="hidden" name="effects" value="0">
            <input id="<?php echo ATOM; ?>_effects" name="effects" class="checkbox" followRules rules="DEPENDS ON jquery" type="checkbox" value="1" <?php checked('1', $app->options('effects')) ?> />
            <?php _ae("Animate content"); ?>
            <small class="indent">
              <?php _ae("Enable jQuery effects such as fading or sliding. Effects can render the site slightly slower on less powerful PCs"); ?>
            </small>
           </label>
          </div>
          <div class="row clear-block">
           <?php if(current_user_can('edit_themes')): // just in case the site is running on wp + multiuser + cheap shared host, like  ?>
           <label for="<?php echo ATOM; ?>_optimize">
            <input type="hidden" name="optimize" value="0">
            <input id="<?php echo ATOM; ?>_optimize" name="optimize" class="checkbox" type="checkbox" value="1" <?php checked('1', $app->options('optimize')) ?> />
           <?php else: ?>
           <input id="<?php echo ATOM; ?>_optimize" disabled="disabled" class="checkbox disabled" type="checkbox" <?php checked('1', $app->options('optimize')) ?> />
           <label class="disabled" for="<?php echo ATOM; ?>_optimize" title="<?php _ae("Only Super Admins can change this option"); ?>">
           <?php endif; ?>
            <?php _ae("Optimize website for faster loading"); ?>
            <small class="indent">
              <?php printf(_a("Compresses and concatenates stylesheets and javascript files (using %s). Leave this unchecked if you're experiencing conflicts with other plugins, or if you're using a cache plugin that handles such functions"), '<a href="http://closure-compiler.appspot.com/">Google\'s Closure Compiler</a>'); ?>
            </small>
           </label>
          </div>

          <div class="row clear-block">
           <?php if(current_user_can('edit_themes')): // just in case the site is running on wp + multiuser + cheap shared host, like wp.digitalnature.eu :) ?>
           <label for="<?php echo ATOM; ?>_generate_thumbs">
           <input type="hidden" name="generate_thumbs" value="0">
           <input id="<?php echo ATOM; ?>_generate_thumbs" name="generate_thumbs" followRules rules="DEPENDS ON jquery" class="checkbox" type="checkbox" value="1" <?php checked('1', $app->options('generate_thumbs')) ?> />
           <?php else: ?>
           <input id="<?php echo ATOM; ?>_generate_thumbs" disabled="disabled" class="checkbox disabled" type="checkbox" <?php checked('1', $app->options('generate_thumbs')) ?> />
           <label class="disabled" for="<?php echo ATOM; ?>_generate_thumbs" title="<?php _ae("Only Super Admins can change this option"); ?>">
           <?php endif; ?>
            <?php _ae("Automatically create missing thumbnail sizes"); ?>
            <small class="indent">
              <?php printf(_a("Asynchronously update thumbnails if needed. You can also use the %s plugin to process all missing thumbnail sizes manually, in a single pass"), '<a href="http://wordpress.org/extend/plugins/regenerate-thumbnails/" target="_blank">Regenerate Thumbnails</a>'); ?>

            </small>
           </label>
          </div>
          <div class="row clear-block">
           <label for="<?php echo ATOM; ?>_lightbox">
            <input type="hidden" name="lightbox" value="0">
            <input id="<?php echo ATOM; ?>_lightbox" name="lightbox" followRules rules="DEPENDS ON jquery" class="checkbox" type="checkbox" value="1" <?php checked('1', $app->options('lightbox')) ?> />
            <?php printf(_a("Use theme built-in lightbox (%s) on all image links"), '<a href="http://fancybox.net/" target="_blank">Fancybox</a>'); ?>
            <small class="indent">
              <?php _ae("Uncheck if you prefer a lightbox plugin"); ?>
            </small>
           </label>
          </div>
          <div class="row clear-block">
           <label for="<?php echo ATOM; ?>_meta_description">
            <input type="hidden" name="meta_description" value="0">
            <input id="<?php echo ATOM; ?>_meta_description" name="meta_description" class="checkbox" type="checkbox" value="1" <?php checked('1', $app->options('meta_description')) ?> />
            <?php _ae("Automatically generate meta descriptions"); ?>
            <small class="indent">
              <?php printf(_a("Uncheck if you're using a SEO plugin, otherwise you'll get duplicate fields! Note that you don't need such plugins, %s is heavily optimized for search engines"), $app->get('theme_name')); ?>
            </small>
           </label>
          </div>

          <div class="row clear-block">
           <label for="<?php echo ATOM; ?>_debug">
            <input type="hidden" name="debug" value="0">
            <input id="<?php echo ATOM; ?>_debug" name="debug" class="checkbox" type="checkbox" value="1" <?php checked('1', $app->options('debug')) ?> />
            <?php _ae("Display debug messages (english only)"); ?>
            <small class="indent">
              <?php _ae("Status notifications about the theme setup (only visible to administrators)."); ?>
              <strong><?php _ae("Only enable this if you need to, because it can significantly slow down page load for admins"); ?></strong>
            </small>
           </label>
          </div>

          <div class="row clear-block">
           <label for="<?php echo ATOM; ?>_remove_settings">
            <input type="hidden" name="remove_settings" value="0">
            <input id="<?php echo ATOM; ?>_remove_settings" name="remove_settings" class="checkbox" type="checkbox" value="1" <?php checked('1', $app->options('remove_settings')) ?> />
            <?php _ae('Theme auto-uninstall'); ?>
            <small class="indent">
              <?php printf(_a("Check to remove all %s settings from the database after you switch the theme (Featured post records are preserved)."), $app->get('theme_name')); ?>
            </small>
           </label>
          </div>

        <?php if(current_user_can('edit_themes') && ATOM_EXTEND): // only show this if the user can use the theme editor (same type of operation) ?>
        <hr />
        <div class="clear-block">
         <h2 class="title"><?php _ae('User-defined code'); ?></h2>

         <?php
          if(WP_Filesystem() && is_child_theme()):
            global $wp_filesystem;

            if($wp_filesystem->is_readable($app->get('user_functions'))){
              $functions = $wp_filesystem->get_contents($app->get('user_functions'));
            }else{
              $default_text = _a("Only edit this if you know what you're doing!");
              $functions = "<?php \n// {$default_text}\n\n\n";
            }

         ?>

         <label for="<?php echo ATOM; ?>_functions">
          <small>
            <?php printf(_a('The code you add here is included in the front-end on initialization. This is almost the same thing as editing the %1$s file from the theme directory, the difference is that the changes you make here are preserved after theme updates. Read the %2$s for more information.'), '<code>functions.php</code>', '<a href="'.Atom::THEME_DOC_URI.'" target="_blank">'._a("documentation").'</a>'); ?>
          </small>
         </label>

         <p>
          <textarea mode="application/x-httpd-php" rows="26" cols="60" name="functions" id="<?php echo ATOM; ?>_functions" class="code editor widefat"><?php echo esc_textarea($functions); ?></textarea>
         </p>

         <p>(<?php printf(_a('data is saved to %s'), sprintf('<code>%s</code>', $app->get('user_functions'))); ?>)</p>

         <?php else: ?>
         <div class="notice"><?php printf(_a('To use this function you must have an active child theme of %s, and give WordPress write permissions to the child theme folder.'), $app->get('theme_name')); ?></div>

         <?php endif; ?>

        </div>
         <?php endif; ?>

        <?php Atom::action("settings_advanced"); ?>
        </div>
        <!-- /tab: advanced -->
        <?php
      break;


      case 'modules':
        ?>
        <!-- tab: modules -->
        <div class="clear-block">


          <div class="metabox-holder clear-block">
            <div class="notice"><?php printf(_a("Modules act like plugins that can further extend %s."), $app->get('theme_name')); ?></div>
            <br />
            <?php
              $modules = $app->getModules();
              $active_modules = (array)get_option(ATOM.'-atom-mods');
            ?>
            <input type="hidden" name="mods" value="0" />

            <?php if(!empty($modules)): ?>
            <table class="widefat">
              <thead>
                <tr>
                <th class="check-column"><input type="checkbox" /></th>
                <th class="title"><?php _ae('Title'); ?></th>
                <th class="title"><?php _ae('Type'); ?></th>
                <th class="author"><?php _ae('Author'); ?></th>
                <th class="desc"><?php _ae('Description'); ?></th>
                </tr>
              </thead>

              <tbody class="plugins">

                <?php foreach($modules as $key => $module): ?>

                <tr valign="top" class="<?php echo in_array($key, $active_modules) ? 'active' : 'inactive'; ?>">

                  <th class="manage-column column-cb check-column">
                    <input type="checkbox" name="mods[]" id="<?php echo sanitize_html_class($module['name']); ?>" value="<?php echo $key; ?>" <?php checked(in_array($key, $active_modules)); ?> />
                  </th>

                  <td class="title">
                    <label for="<?php echo sanitize_html_class($module['name']); ?>"><strong><?php echo $module['name']; ?></strong></label>
                  </td>

                  <td class="title">
                    <label for="<?php echo sanitize_title($module['type']); ?>"><?php echo $module['type']; ?></label>
                  </td>

                  <th class="author">
                    <?php echo '<a href="'.$module['url'].'">'.$module['author'].'</a>'; ?>
                  </th>

                  <td class="desc" width="55%">
                    <p><?php echo $module['description']; ?></p>
                  </td>

                </tr>

                <?php endforeach; ?>

              </tbody>


            </table>
            <?php else: ?>
            <p><?php _ae("Currently there are no modules installed."); ?></p>
            <?php endif; ?>
          </div>


          <?php Atom::action("settings_modules"); ?>
        </div>
        <!-- /tab: modules -->
        <?php
      break;

      default:
        Atom::action("settings_{$tab}");
      break;

    endswitch;

    if($tab !== 'welcome'): ?>
    <div class="save">
      <input type="submit" class="button-primary" name="submit" value="<?php _ae("Save Changes"); ?>" />
    </div>
    <?php endif;

    // check if this is an ajax request and exit the script
    if(defined('DOING_AJAX')) exit;
  }



  /**
   * Get the new version update details
   *
   * @since 1.2
   */
  private function updateAvailable(&$update_details){
    static $themes_update;

    // make sure we get the parent theme name
    $theme = get_theme_data(TEMPLATEPATH.'/style.css');
    $theme = get_theme($theme['Name']); // need to test this

    if(!isset($themes_update)) $themes_update = get_site_transient('update_themes');

    if (is_object($theme) && isset($theme->stylesheet)) $stylesheet = $theme->stylesheet;
    elseif (is_array($theme) && isset($theme['Stylesheet'])) $stylesheet = $theme['Stylesheet'];
    else return false;

    if(isset($themes_update->response[$stylesheet])){
      $update = $themes_update->response[$stylesheet];

      $update_details['theme_name'] = is_object($theme) ? $theme->name : (is_array($theme) ? $theme['Name'] : '');
      if(current_user_can('update_themes') || !empty($update->package))
        $update_details['update_url'] = wp_nonce_url('update.php?action=upgrade-theme&amp;theme='.urlencode($stylesheet), 'upgrade-theme_'.$stylesheet);
      $update_details['new_version'] = $update['new_version'];
      $update_details['details_url'] = add_query_arg(array('TB_iframe' => 'true', 'width' => 1024, 'height' => 800), $update['url']);

      return true;
    }

    return false;
  }




  /**
   * The theme settings pages
   *
   * Note:
   *  Because non-checked input field values are not sent trough $_POST, all options that have checkboxes need to have
   *    <input type="hidden" name="option_name" value="0" />
   *  before the checkbox option. This trick supposes the inputs are always processed sequentially,
   *  so the hidden input value is sent (0) if the checkbox is not checked.
   *
   * @since 1.0
   */
  public function settings() {
    global $is_IE, $wp_filesystem;


    // only allow users who can at least edit_theme_options themes to view these pages
    if(!current_user_can('edit_theme_options')) wp_die(_a('You are not authorised to perform this operation.'));

    $errors = Atom::app()->getContextArgs('settings_update_errors', array(
      '1' => _a('Import failed. Invalid settings. '),
      '2' => _a('Settings saved, but failed to update user functions. Is your uploads directory writeable?'),
    ));

    $parent_theme = get_theme_data(TEMPLATEPATH.'/style.css');
    $update_details = array();
    if($this->updateAvailable($update_details) && isset($update_details['update_url']))
      $update_link = "(<a href=\"{$update_details['update_url']}\">"._a("Update")."</a>)";

    ?>
    <div id="theme-settings" class="atom-block wrap clear-block">
      <?php screen_icon('themes'); ?><h2><?php echo get_admin_page_title(); ?></h2>
      <form id="theme-settings-form" action="<?php echo admin_url('admin-post.php?action=atom_update_settings'); ?>" method="post" enctype="multipart/form-data">

        <?php if (isset($_GET['updated'])): // just updated? ?>
        <div class="updated fade below-h2">
          <p><?php _ae('Settings saved.'); ?> <a href="<?php echo user_trailingslashit(home_url()); ?>"><?php _ae('View site'); ?></a></p>
        </div>
        <?php endif; ?>

        <?php if (isset($_GET['error'])): // error? ?>
        <div class="error fade below-h2">
          <p><?php echo $errors[(int)$_GET['error']]; ?></p>
        </div>
        <?php endif; ?>

        <?php if (isset($update_details['new_version'])): // new theme version? ?>
        <div class="updated fade below-h2">
          <p>
           <?php
            if(!isset($update_details['update_url']))
              printf(_a('<strong>There is a new version of %1$s available</strong>. <a href="%2$s" class="thickbox" title="%1$s">View %1$s %3$s details</a> or notify the site administrator.'), $update_details['theme_name'], $update_details['details_url'], $update_details['new_version']);
            else
              printf(_a('<strong>There is a new version of %1$s available</strong>. <a href="%2$s" class="thickbox" title="%1$s">View %1$s %3$s details</a> or <a href="%4$s" >upgrade automatically</a>.'), $update_details['theme_name'], $update_details['details_url'], $update_details['new_version'], $update_details['update_url']);
           ?>
          </p>
        </div>
        <?php endif; ?>

        <div class="hide-if-js">
          <?php _ae("Sorry, this page requires JavaScript to be enabled in your browser :("); ?>
        </div>

        <!-- theme settings - tabbed interface -->
        <div class="atom-tabs hide-if-no-js">

          <?php $active_tab = isset($_COOKIE[ATOM.'-settings']) && array_key_exists($_COOKIE[ATOM.'-settings'], $this->tabs) ? $_COOKIE[ATOM.'-settings'] : 'welcome'; ?>
          <!-- navi -->
          <ul class="nav clear-block">
            <?php foreach($this->tabs as $key => $label): ?>
              <li class="<?php echo $key; if($active_tab == $key) echo ' active'; ?>"><a href="#<?php echo $key; ?>"><?php echo $label; ?></a></li>
            <?php endforeach; ?>
          </ul>
          <!-- /navi -->

          <div class="tab-content">
             <?php $this->getTab(); ?>
          </div>

        </div>
        <!-- /theme settings - tabbed interface -->

        <?php wp_nonce_field('theme-settings'); ?>

      </form>

      <?php if($active_tab === 'welcome'): ?>
      <div class="support">
        <form action="https://www.paypal.com/cgi-bin/webscr" method="post">
          <input name="cmd" type="hidden" value="_s-xclick" /> <input name="hosted_button_id" type="hidden" value="4605915" />
          <input alt="Donate" name="submit" src="<?php echo Atom::app()->get('theme_url'); ?>/images/admin/pp.gif" type="image" />
        </form>
        <a href="http://digitalnature.eu/themes/mystique/"><strong>Mystique</strong></a> is a free theme developed by <a href="http://digitalnature.eu/">digitalnature</a>. You can support the development of more free resources by donating.
      </div>
      <?php endif; ?>


    </div>
    <?php
  }

  /**
   * Theme settings update function
   *
   * @since 1.0
   */
  public function saveOptions(){
    global $wp_filesystem;

    check_admin_referer('theme-settings');

    $this->error = '';

    // check permissions
    if(!current_user_can('edit_theme_options')) wp_die(_a('You are not authorised to perform this operation.'));

    $options = Atom::app()->options();

    // change options
    foreach(Atom::app()->getDefaultOptions() as $key => $value)
     if(isset($_POST[$key]) && Atom::app()->isOptionEnabled($key)){

       // don't allow non-super admins to change these options -- @todo make the black-list editable trough API
       if(!current_user_can('edit_themes') && in_array($key, array('optimize', 'generate_thumbs'))) continue;

       $options[$key] = $this->sanitizeOption($_POST[$key]);
     }

    Atom::app()->setOptions($options);

    // more sensitive actions; only super admins should have the 'edit_themes' capability...
    if(current_user_can('edit_themes')){
      if(is_child_theme() && isset($_POST['functions'])){
        $functions = stripslashes($_POST['functions']);
        $this->error = (WP_Filesystem() && $wp_filesystem->put_contents(Atom::app()->get('user_functions'), $functions, FS_CHMOD_FILE)) ? false : 2;
        unset($_POST['functions']);
      }

      // reset settings?
      if(isset($_POST['reset']) && current_user_can('edit_themes')) Atom::app()->reset();

      // import existing settings?
      if(isset($_POST['import']))
        if(is_array($options = unserialize(pack('H*', str_replace(array("\r", "\r\n", "\n"), '', trim($_POST['import_data'])))))) Atom::app()->setOptions($options); else $this->error = 1;

      // set active modules; this user should see this page, so we're assuming all modules have been deactivated if there's no 'mods' field in $_POST
      if(isset($_POST['mods'])){
        $modules = is_array($_POST['mods']) ? $_POST['mods'] : array();
        update_option(ATOM.'-atom-mods', $modules);
      }

    }

    // modules might want to do some extra checking
    Atom::action('save_options', $options);

    $url = 'themes.php?page='.ATOM.'&'.($this->error ?  "error={$this->error}" : "updated=true");

    wp_redirect(admin_url($url));
    exit;
  }



  /**
   * Displays a warning message telling the user he shouldn't edit the theme files :)
   *
   * @since 1.0
   */
  public function editorWarning(){
    global $current_screen;
    if($current_screen->id !== 'theme-editor' || is_child_theme()) return; // only on editor pages, if parent theme is active

    $message = sprintf(_a('To make small CSS customizations you can use the %1$s option from the theme settings. For extensive customizations activate and edit the %2$s theme if available, or create your own child theme. Read the %3$s for more information.'),
      '<a href="'.admin_url('themes.php?page='.ATOM.'#user_css').'">'._a("User CSS").'</a>',
      '"'.Atom::app()->get('theme_name').' - Extend"',
      '<a href="'.Atom::THEME_DOC_URI.'">'._a("documentation").'</a>');
    ?>
    <div class="error fade">
      <p><strong><?php _ae('Do not edit core theme files because you will use any changes you make here when you update!'); ?></strong></p>
      <p><em><?php echo $message; ?></em></p>
    </div>
    <?php
  }


  /**
   * Recursively sanitizes theme options (input)
   *
   * @since 1.3
   *
   * @param mixed $option
   *
   * @return mixed
   */
  private function sanitizeOption($option){
    if(is_array($option)){  // could be replaced with array_walk_recursive() in PHP > 5
      foreach($option as $key => $value)
        $option[$key] = $this->sanitizeOption($value);
      return $option;
    }

    // only sanitize html if needed
    return current_user_can('unfiltered_html') ? stripslashes((string)$option) : stripslashes(wp_filter_post_kses((string)$option));
  }



  /**
   * Check for a new theme versions
   *
   * @since 1.2
   */
  function transientUpdateThemes($checked_data) {
    global $wp_version;

    // make sure we get the parent theme name
    $theme = get_theme_data(TEMPLATEPATH.'/style.css');

    if(empty($checked_data->checked)) return $checked_data;

    //$theme_base = basename(dirname(dirname(__FILE__)));
    $theme_base = get_template();

    // Start checking for an update
    $send_for_check = array(
      'body' => array(
        'action' => 'theme_update',
        'request' => serialize(array(
          'slug' => $theme_base,
          'version' => $checked_data->checked[$theme_base],
        )),

        // @todo: add username/password check for commercial themes
      ),
      'user-agent' => 'WordPress '.$wp_version.' / PHP '.PHP_VERSION.' / '.$theme['Name'].' '.$theme['Version'].'; '.get_bloginfo('name')
    );

    /* @todo: maybe...
    if(Atom::app()->options('anon_stats')){

      $active_widgets = array();
      foreach(wp_get_sidebars_widgets() as $area)
        if($area !== 'wp_inactive_widgets')
          foreach($area as $widget) $active_widgets[] = $widget;

      $send_for_check['body']['stats'] = serialize(array(
        'php_ver'   => PHP_VERSION,
        'wp_ver'    => $wp_version,
        'widgets'   => $active_widgets,

        'options'   => array(
           'optimize'         => (int)Atom::app()->options('optimize'),
           'jquery'           => (int)Atom::app()->options('jquery'),
           'effects'          => (int)Atom::app()->options('effects'),
           'lightbox'         => (int)Atom::app()->options('lightbox'),
           'comment_karma'    => (int)Atom::app()->options('comment_karma'),
           'post_navi'        => Atom::app()->options('post_navi'),
           'color_scheme'     => Atom::app()->options('color_scheme'),
           'layout'           => Atom::app()->options('layout'),
        ),

        'actions' => array(
           'css_cache'        => (get_transient('atom_css_cache') != false),
           'child_theme'      => is_child_theme(),
        ),

      ));
    }
    */


    $raw_response = wp_remote_post(Atom::THEME_UPDATE_URI, $send_for_check);
    if(!is_wp_error($raw_response) && ($raw_response['response']['code'] == 200)) $response = unserialize($raw_response['body']);

    // feed the update data into WP updater
    if(!empty($response)) $checked_data->response[$theme_base] = $response;

    return $checked_data;
  }



  /**
   * Update check (ajax)
   *
   * @since 1.4
   */
  function updateCheck() {
    check_ajax_referer('theme-settings');
    set_site_transient('update_themes', null);
    wp_update_themes();
    $update_details = array();

    if($this->updateAvailable($update_details) && isset($update_details['update_url'])): ?>
      <a style="color:red;" href="<?php echo $update_details['update_url']; ?>">(<?php printf(_a('%s is available'), $update_details['new_version']); ?>)</a>
    <?php else: ?>
      <span style="color:green;">(<?php _ae("You have the latest version"); ?>)</span>
    <?php endif;

    die();
  }



  /**
   * Image upload processing (AJAX)
   * needed for logo, background etc. settings
   *
   * @since 1.0
   *
   * @todo: add ability to the edit the image (wp crop/resize)
   */
  function processUpload() {
    check_ajax_referer("theme-settings");
    if(!current_user_can('upload_files')) $error = _a('You are not authorised to perform this operation.');
    $error = '';
    $url = '';
    $option_name = esc_attr($_POST['data']);
    if($_POST['type'] == 'upload'){
       $filename = $_FILES[$option_name];
       $uploaded_file = wp_handle_upload($filename, array("test_form" => false, "action" => 'wp_handle_upload', "mimes" => array('jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif', 'ico' => 'image/x-icon')));
       if(!empty($uploaded_file['error'])){
        $error = sprintf(_a('Upload Error: %s'), $uploaded_file['error']);
       }else{

         $imageinfo = getimagesize($uploaded_file['file']);
         list($width, $height) = $imageinfo;

         $url = $uploaded_file['url'];
       }
    }elseif($_POST['type'] == 'reset_upload'){
       $options[$option_name] = '';
    }

    echo json_encode(array('error' => $error, 'url' => $url));
    exit;
  }


  /**
   * Latest News RSS Feed from digitalnature.eu (AJAX)
   *
   * @since 1.0
   */
  public function latestNews() {
    check_ajax_referer("theme-settings");
    echo '<h3 class="title">'.sprintf(_a('Latest News from %s'), '<a href="http://digitalnature.eu/">digitalnature.eu</a>').'</h3>';
    wp_widget_rss_output('http://digitalnature.eu/feed', array('show_author' => 0, 'show_date' => 1, 'show_summary' => 1, 'items' => 5));
    exit;
  }



  /**
   * Remove feature post entry if a post is deleted
   *
   * @since 1.4
   */
  public function cleanFeaturedPostRecords($post_id){
    if(!$post_id) return;
    $featured = get_option('featured_posts') ? wp_parse_id_list(get_option('featured_posts')) : array();
    unset($featured[array_search($post_id, $featured)]);
    update_option('featured_posts', $featured);
    return $post_id;
  }




  /**
   * Process the featured content actions (AJAX)
   *
   * @since 1.0
   * @todo Add User Role for managing Featured Posts
   */
  public function processFeatured(){

    // check for access rights...
    check_ajax_referer('theme-settings');
    if(!current_user_can('edit_posts')) return false;

    // read submitted info
    $id = (int)$_GET['id'];
    $is_on = (bool)$_GET['isOn'];
    $what = ($_GET['what'] !== 'post') ? 'featured_media' : 'featured_posts';

    // get current featured array
    $featured = get_option($what) ? wp_parse_id_list(get_option($what)) : array();

    // add / or remove requested item from array, depending on current selection
    // "is_on" means that the item was selected and is now being unchecked, so we're removing it from the list...
    if(!$is_on && !in_array($id, $featured)) array_push($featured, $id); elseif($is_on && in_array($id, $featured)) unset($featured[array_search($id, $featured)]);

    // newer items (higher IDs) first
    rsort($featured);

    update_option($what, $featured);

    Atom::action($what !== 'post' ? 'feature_galleries' : 'feature_posts');

    // reverse classes
    exit($is_on ? 'off' : 'on');
  }




  /**
   * Add extra fields in the widget settings form
   * based on "Display Widgets" plugin by Stephanie Wells - http://blog.strategy11.com/display-widgets
   *
   * @since 1.0
   *
   * @param object $widget Widget object
   * @param string $return widget form (html output)
   * @param array $instance Instance options
   */
  public function widgetVisibilityOptions($widget, $return, $instance){
    if(get_class($widget) == 'AtomWidgetSplitter') return; // no options on splitters

    if(!isset($instance['visibility'])) $instance['visibility'] = 0;
    $nonce = wp_create_nonce('visibility-options');
    ?>
    <div class="<?php if(is_numeric($widget->number)) echo "atom-block {$widget->id}"; else echo "hidden"; ?>">
    <?php if(is_numeric($widget->number)): ?>
    <input type="button" class="button-visibility" id="button-visibility-<?php echo $widget->id; ?>" value="<?php if ($instance['visibility']) _ae("Hide Page Visibility Options"); else _ae("Show Page Visibility Options"); ?>" />
    <?php endif; ?>

    <input class="visibility" type="hidden" id="<?php echo $widget->get_field_id('visibility'); ?>" name="<?php echo $widget->get_field_name('visibility'); ?>" value="<?php echo $instance['visibility']; ?>" />

    <div id="visibility-options-<?php echo $widget->id; ?>" class="visibility-options <?php if(!is_numeric($widget->number)) echo 'needfix'; // try to fix the wp save bug (widget-save is triggered with livequery) ?>">

      <?php if($instance['visibility']) $this->widgetVisibilityOptionsFields($widget->id, $instance); ?>

      <?php if(is_numeric($widget->number)): ?>
      <script type="text/javascript">

      /*<![CDATA[*/
      jQuery(document).ready(function($){

        $('.atom-block.<?php echo $widget->id; ?>').each(function(){
          var block = $(this),
              editors = new Array();


          // form dependencies
          $('[followRules]', block).setupDependencies();

          // allow select type operations on links (nicer selects)
          $('.template-selector a.select', block).click(function(){
            var button = $(this),
                selector = $(this).parents('.template-selector'),
                selected = $(this).attr('rel');

            $('input.select', selector).val(selected).change();
            $('a', selector).removeClass('active');
            button.addClass('active');
            return false;
          });

          // hidden input field (used for creating the nicer select inputs above)
          // not to be confused with input[type=select]
          $('.template-selector input.select', block).change(function(){
            var data = $(this).val(),
                selector = $(this).parents('.template-selector');

            $("a.select[rel='" + data + "']", selector).addClass('active');

            if(data != 'template'){
              $('.user-template', block).animate({
                opacity: 'hide',
                height: 'hide',
                marginTop: 'hide',
                marginBottom: 'hide',
                paddingTop: 'hide',
                paddingBottom: 'hide'
              }, 150);
            }else{
              $('.user-template', block).animate({
                opacity: 'show',
                height: 'show',
                marginTop: 'show',
                marginBottom: 'show',
                paddingTop: 'show',
                paddingBottom: 'show'
              }, 150);

              // refresh codemirror editors if any
              for(var i = 0; i < editors.length; i++) editors[i].refresh();

            }

          }).change();

          // codemirror
          $('textarea.code', block).each(function(i, el){
            editors.push(CodeMirror.fromTextArea(document.getElementById($(this).attr('id')), {
             lineNumbers: true,
             matchBrackets: true,
             mode: $(this).attr('mode'),
             onChange: function(inst){
               inst.save();
             }
           }));
          });

          // refresh codemirror editors when widget options are toggled
          $('a.widget-action').live('click', function(){
            for(var i = 0; i < editors.length; i++) editors[i].refresh();
          });

        });


        // visibility button
        $('.atom-block').delegate('#button-visibility-<?php echo $widget->id; ?>', 'click', function(e){
          e.preventDefault();

          var visibility_status = $('#<?php echo $widget->get_field_id('visibility'); ?>');
          var options = $('#visibility-options-<?php echo $widget->id; ?>');

          if(visibility_status.val() == 0){
            $(visibility_status).val('1');
            $.ajax({
              type: 'post',
              url: 'admin-ajax.php',
              data: {
                 action: 'widget_visibility_options_fields',
                 widget_id: '<?php echo $widget->id; ?>',
                 _ajax_nonce: '<?php echo $nonce; ?>' },
              context: this,
              beforeSend: function(){
                 $(this).val('<?php _ae("Loading..."); ?>');
                 $(this).attr('disabled','disabled');
              },
              complete: function(){},
              success: function(data){
                options.append(data);
                $(this).val('<?php _ae("Hide Page Visibility Options"); ?>');
                $(this).removeAttr('disabled');
              }
            });
          }
          else {
            $(visibility_status).val('0');
            options.html('');
            $(this).val('<?php _ae("Show Page Visibility Options"); ?>');
          }
          return false;
        });


      });
      </script>
      <?php endif; ?>

    </div>
    </div>
  <?php
  }



  /**
   * The widget visibility fields added in the widget options
   * By default, this function is fired trough ajax to save bandwidth; It will be called normally within the function above only when the user manually unhides these options
   *
   * @since 1.0
   *
   * @global $wp_registered_widgets Stored registered widgets.
   *
   * @param string $widget_id Widget ID
   * @param array $instance Widget Instance
   */
  public function widgetVisibilityOptionsFields($widget_id = false, $instance = false){
    global $wp_registered_widgets;

    if(!$widget_id):
      $ajax = true;
      check_ajax_referer('visibility-options');
      $widget_id = esc_attr($_POST['widget_id']);
    else:
      $ajax = false;
    endif;

    $wp_page_types = array(
      'home'     => _a('Blog Homepage'),
      'search'   => _a('Search Results'),
      'author'   => _a('Author Archives'),
      'date'     => _a('Date-based Archives'),
      'tag'      => _a('Tag Archives'),
      'category' => _a('Category Archives'),
    );

    $widget =  AtomWidget::getObject($widget_id);
    $widget_settings = get_option($widget->option_name);
    $instance = ($instance ? $instance : $widget_settings[$widget->number]);

    if(isset($widget->control_options['width'])) $widget_width = $widget->control_options['width']; else $widget_width = 0;

    // get the active widgets from all sidebars
    $sidebars_widgets = wp_get_sidebars_widgets();

    // prepare matches
    $matches = array();
    foreach($wp_registered_widgets as $i => $w)
      if($w['name'] === $widget->name) $matches[] = $w['id'];

    /*/ exclude widgets from the "inactive widgets" area? -- @todo, maybe
    $is_inactive = false;
    if(!empty($sidebars_widgets['wp_inactive_widgets']))
      foreach($sidebars_widgets['wp_inactive_widgets'] as $i => $value)
        if($value == $widget->id) $is_inactive = true;

    // stop, if it is (we don't add these options in inactive widgets to save bandwidth)
    if($is_inactive) return;
    //*/

    // find out if the widget is in the arbitrary area, and it's position (number)
    $number = 0;
    $is_arbitrary = false;
    if(!empty($sidebars_widgets['arbitrary']))
      foreach($sidebars_widgets['arbitrary'] as $i => $value):
        if(in_array($value, $matches) && !$is_arbitrary) $number++;
        if($value === $widget->id) $is_arbitrary = true;
      endforeach;
    ?>

    <?php if(!$is_arbitrary): ?>
    <p><strong><em><?php _ae("Show this widget on:"); ?></em></strong></p>
    <p>
      <?php foreach($wp_page_types as $key => $label): ?>

      <?php if(!isset($instance["page-{$key}"])) $instance["page-{$key}"] = 1; ?>
      <input type="hidden" name="<?php echo $widget->get_field_name("page-{$key}"); ?>" value="0" />
      <input type="checkbox" value="1" <?php checked($instance["page-{$key}"]); ?> id="<?php echo $widget->get_field_id("page-{$key}"); ?>" name="<?php echo $widget->get_field_name("page-{$key}"); ?>" />
      <label for="<?php echo $widget->get_field_id("page-{$key}"); ?>"><?php echo $label; ?></label>
      <br />
      <?php endforeach; ?>

      <?php foreach(get_post_types(array('public' => true)) as $post_type):
        $object = get_post_type_object($post_type);
        if(empty($object->labels->name) || $post_type == 'page') continue; // we handle pages separately
        if(!isset($instance["page-singular-{$post_type}"])) $instance["page-singular-{$post_type}"] = 1; ?>
        <input type="hidden" name="<?php echo $widget->get_field_name("page-singular-{$post_type}"); ?>" value="0" />
        <input type="checkbox" value="1" <?php checked($instance["page-singular-{$post_type}"]); ?> id="<?php echo $widget->get_field_id("page-singular-{$post_type}"); ?>" name="<?php echo $widget->get_field_name("page-singular-{$post_type}"); ?>" />
        <label for="<?php echo $widget->get_field_id("page-singular-{$post_type}"); ?>"><?php printf(_a('Single: %s'), $object->labels->name); ?></label>
        <br />
      <?php endforeach; ?>

      <?php foreach(get_taxonomies(array('public' => true, '_builtin' => false)) as $taxonomy):
        $object = get_taxonomy($taxonomy);
        if(empty($object->labels->name)) continue;
        if(!isset($instance["page-tax-{$taxonomy}"])) $instance["page-tax-{$taxonomy}"] = 1; ?>
        <input type="hidden" name="<?php echo $widget->get_field_name("page-tax-{$taxonomy}"); ?>" value="0" />
        <input type="checkbox" value="1" <?php checked($instance["page-tax-{$taxonomy}"]); ?> id="<?php echo $widget->get_field_id("page-tax-{$taxonomy}"); ?>" name="<?php echo $widget->get_field_name("page-tax-{$taxonomy}"); ?>" />
        <label for="<?php echo $widget->get_field_id("page-tax-{$taxonomy}"); ?>"><?php printf(_a('Tax Archive: %s'), $object->labels->name); ?></label>
        <br />
      <?php endforeach; ?>

    </p>
    <?php
      $pages = get_pages();
      if($pages):
        echo "<p>";
        foreach ($pages as $page):
          // determine if widget is visible on selected page; we consider it visible if the visibility option is not set
          $instance["page-{$page->ID}"] = isset($instance["page-{$page->ID}"]) ? ($instance["page-{$page->ID}"] ? true : false) : true;
          if(!isset($instance["page-{$page->ID}"])) $instance["page-{$page->ID}"] = 1; ?>
          <input type="hidden" name="<?php echo $widget->get_field_name("page-{$page->ID}"); ?>" value="0">
          <input type="checkbox" <?php checked($instance["page-{$page->ID}"]) ?> id="<?php echo $widget->get_field_id("page-{$page->ID}"); ?>" name="<?php echo $widget->get_field_name("page-{$page->ID}"); ?>" value="1" />
          <label for="<?php echo $widget->get_field_id("page-{$page->ID}"); ?>">
          <?php printf(_a("Page: %s"), '<a href="'.get_permalink($page).'" target="_blank"><strong title="'.$page->post_title.'">'.((strlen($page->post_title) > 16 && $widget_width < 500) ? substr($page->post_title, 0, 16)."..." : $page->post_title).'</strong></a>'); ?>
          </label>
          <br />
        <?php endforeach;
        echo "</p>";
      endif;
    ?>

    <?php endif; ?>
    <p><strong><em><?php _ae('To:'); ?></em></strong></p>
    <p>
      <?php if(!isset($instance["user-visitor"])) $instance["user-visitor"] = 1; ?>
      <input type="hidden" name="<?php echo $widget->get_field_name("user-visitor"); ?>" value="0" />
      <input type="checkbox" value="1" <?php checked('1', $instance['user-visitor']); ?> id="<?php echo $widget->get_field_id('user-visitor'); ?>" name="<?php echo $widget->get_field_name('user-visitor'); ?>" />
      <label for="<?php echo $widget->get_field_id('user-visitor'); ?>"><?php _ae("Unregistered user (Visitor)"); ?></label>

      <?php
       $wp_roles = new WP_Roles();
       $names = $wp_roles->get_names();
       foreach($names as $role => $label):
         if(!isset($instance["role-{$role}"])) $instance["role-{$role}"] = 1;
         ?>
         <br />
         <input type="hidden" name="<?php echo $widget->get_field_name("role-{$role}"); ?>" value="0" />
         <input type="checkbox" value="1" <?php checked($instance["role-{$role}"]); ?> id="<?php echo $widget->get_field_id("role-{$role}"); ?>" name="<?php echo $widget->get_field_name("role-{$role}"); ?>" />
         <label for="<?php echo $widget->get_field_id("role-{$role}"); ?>"><?php echo translate_user_role($label); ?></label>
       <?php endforeach; ?>
    </p>

    <?php if($is_arbitrary):
     // output the [widget] shortcode info if we're on the arbitrary widget area
     // ID = generated by hashing the instance ID (we shorten it to 8 chars)
     // Name = the widget name
     // Number = the widget position in the sidebar (counting widgets from the same class)
    ?>
    <div class="info-block">
       <?php printf(_a('To include this widget into your posts or pages use one of the following shortcodes: %s'), '<span><code>[widget '.substr(md5($widget->id), 0, 8).']</code></span><span><code>[widget "'.$widget->name.'"'.(($number > 1) ? ' number='.$number : '').']</code></span>'); ?>
    </div>
    <?php endif; ?>

    <?php
    if($ajax) exit();
  }



  /**
   * Update the extra widget options above
   *
   * @since 1.0
   *
   * @param array $instance Instance options
   * @param array $new_instance New instance
   * @param array $old_instance Old instance
   * @return array new instance options
   */
  public function widgetVisibilityUpdate($instance, $new_instance, $old_instance){
    $instance['visibility'] = (int)$new_instance['visibility'];

    // generic pages
    foreach(array('home', 'single', 'category', 'tag', 'author', 'date', 'search') as $page)
      $instance["page-{$page}"] = (!isset($new_instance["page-{$page}"]) ? 1 : (int)$new_instance["page-{$page}"]);

    // pages as in post type
    $pages = get_pages();
    foreach ($pages as $page)
      $instance["page-{$page->ID}"] = (!isset($new_instance["page-{$page->ID}"]) ? 1 : (int)$new_instance["page-{$page->ID}"]);

    // singural-type pages
    foreach(get_post_types(array('public' => true)) as $post_type)
      $instance["page-singular-{$post_type}"] = (!isset($new_instance["page-singular-{$post_type}"]) ? 1 : (int)$new_instance["page-singular-{$post_type}"]);

    // tax / archives
    foreach(get_taxonomies(array('public' => true)) as $taxonomy)
      $instance["page-tax-{$taxonomy}"] = (!isset($new_instance["page-tax-{$taxonomy}"]) ? 1 : (int)$new_instance["page-tax-{$taxonomy}"]);

    // user access
    $wp_roles = new WP_Roles();
    foreach($wp_roles->role_names as $role => $label)
      $instance["role-{$role}"] = (!isset($new_instance["role-{$role}"]) ? 1 : (int)$new_instance["role-{$role}"]);

    $instance['user-visitor'] = (!isset($new_instance['user-visitor']) ? 1 : (int)$new_instance['user-visitor']);

    return $instance;
  }




  /**
   * Add "Featured" column title to the appropriate page (this function is hooked to posts/media column title)
   *
   * @since 1.3
   *
   * @param array $defaults default columns
   */
  public function featuredColumnTitle($defaults){
    $defaults['featured'] = _a('Featured'); // featured posts
    return $defaults;
  }



  /**
   * Setup featured column content for Posts (edit.php) page
   *
   * @since 1.0
   *
   * @param string $column_name Current Column
   * @param string $id Post ID
   */
  public function postsColumnContent($column_name, $id){
    // not our column
    if($column_name !== 'featured') return;
    $posts = wp_parse_id_list(get_option('featured_posts'));
    ?>
    <a href="#" rel="post" id="featured-<?php echo $id; ?>" class="feature <?php echo in_array($id, $posts) ? 'on' : 'off'; ?>"></a>
    <?php
  }


  /**
   * Setup featured column content for Media Library (upload.php) page
   *
   * @since 1.3
   *
   * @param string $column_name Current Column
   * @param string $id Post ID
   */
  public function mediaColumnContent($column_name, $id){
    // not our column / current item not an image
    if($column_name !== 'featured' || strpos(get_post_mime_type($id), 'image/') === false) return;
    $posts = wp_parse_id_list(get_option('featured_media'));
    ?>
    <a href="#" rel="attachment" id="featured-<?php echo $id; ?>" class="feature <?php echo in_array($id, $posts) ? 'on' : 'off'; ?>"></a>
    <?php
  }

}
