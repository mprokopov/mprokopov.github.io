<?php
/**
 * Atom Tabbed Widgets.
 *
 * Group widgets from the Arbitrary area into tabs
 *
 * @link http://digitalnature.eu
 *
 * @package ATOM
 * @subpackage Template
 *
 * @since 1.0
 *
 * @todo add the possibility to drag & drop widgets inside this widget
 */



class AtomWidgetTabs extends AtomWidget{

  public function AtomWidgetTabs(){

    $this->WP_Widget('atom-tabs', _a('Tabbed Widgets'), array('classname' => 'tabs', 'description' => _a('Group arbitrary widgets into tabs')), array('width' => 500));

    // default settings
    $this->setDefaults(array(
      'widgets'  => array(),
      'icons'    => array(),
      'effect'   => 'fade',
      'event'    => 'click',
    ));

    Atom::add('css', array(&$this, 'css'));
  }

  public function css(){
    if(!is_active_widget(false, false, $this->id_base)) return;
    wp_enqueue_style(ATOM.'-tabs', Atom::app()->get('theme_url').'/css/side-tabs.css', array(ATOM.'-core', ATOM.'-style'), Atom::app()->get('theme_version'));
  }


  private function getArbitraryWidgets(){
    global $wp_registered_widgets;

    $sidebars_widgets = wp_get_sidebars_widgets();

    $matches = array();
    $count = 0;
    if(!empty($sidebars_widgets['arbitrary'])){
      foreach($sidebars_widgets['arbitrary'] as $index => $widget_id){

        // check if widget is registered (eg. missing widget - plugin is removed)
        $callback = AtomWidget::getObject($widget_id);
        if(!$callback) continue;

        // get the widget instance settings
        $options = get_option($callback->option_name);
        $options = $options[$wp_registered_widgets[$widget_id]['params'][0]['number']];

        // parse defaults for atom widgets
        if(method_exists($callback, 'getDefaults'))
          $options = wp_parse_args($options, $callback->getDefaults());

        // generate css classes, that can be used for styling the tabs with things like icons
        $id = $callback->id_base;

        if($id == 'atom-splitter') continue; // no splitters here

        $classes = array();

        // add extra relevant classes based on widget options from certain Atom widgets
        // this is to allow different styling for widgets of the same type inside the tabs (for eg. recent/popular/random posts)
        switch($id){

          // order + post type, if different than "post" + related if checked + category if different than 0 (all)
          case 'atom-posts':
            $classes[] = $options['order_by'];

            if($options['post_type'] !== 'post')
              $classes[] = $options['post_type'];

            if($options['related'])
              $classes[] = 'related';

            if($options['category'])
              $classes[] = "cat-{$options['category']}";
          break;

          // custom menus, menu id
          case 'atom-menu':
            $classes[] = $options['nav_menu'];
          break;

          // term taxonomy, if different than 'post_tag'
          case 'atom-tag-cloud':
            if($options['taxonomy'] !== 'post_tag')
              $classes[] = $options['taxonomy'];
          break;

          // term taxonomy, if different than 'category'
          case 'atom-terms':
            if($options['taxonomy'] !== 'category')
              $classes[] = $options['taxonomy'];
          break;

          // link category ID
          case 'atom-links':
            if($options['category'])
              $classes[] = $options['category'];
          break;

          // archives, type & post type
          case 'atom-archives':
            $classes[] = $options['type'];
            if($options['post_type'] !== 'post') $classes[] = $options['post_type'];
          break;

          // calendar, post type
          case 'atom-calendar':
            if($options['post_type'] !== 'post') $classes[] = $options['post_type'];
          break;

          // blogs, sort order
          case 'atom-blogs':
            $classes[] = $options['order_by'];
          break;

          // users, role (if set)
          case 'atom-users':
            if($options['role'])
              $classes[] = $options['role'];
          break;

        }

        $base = str_replace('atom-', '', strtolower(preg_replace('/[^a-z0-9\-]+/i', '-', $id)));

        foreach($classes as &$class)
          $class = 'nav-'.$base.'-'.strtolower(preg_replace('/[^a-z0-9\-]+/i', '-', $class));

        array_unshift($classes, 'nav-'.$base); // first class (the widget id_base without "atom-")

        $matches[$count] = array(
          'id'       => $widget_id,
          'number'   => $count,
          'name'     => $wp_registered_widgets[$widget_id]['name'],
          'title'    => isset($options['title']) ? $options['title'] : $wp_registered_widgets[$widget_id]['name'],
          'classes'  => apply_filters('atom_widget_tabs_classes', $classes, $options, $count),
        );

        $count++;
      }
    }
    asort($matches);
    return $matches;
  }

  public function widget($args, $instance){

    $app = &Atom::app();

    if(!$app->options('jquery'))
      return $app->addDebugMessage("jQuery required by {$args['widget_id']} ({$args['widget_name']}). Widget marked as inactive");

    extract($args);
    $instance = wp_parse_args($instance, $this->getDefaults());

    // initialize some variables
    $active_tabs = $valid_tabs = $valid_widgets = $output = array();

    // active widgets from the options
    if(is_array($instance['widgets']))
      $active_tabs = $instance['widgets'];

    // get the widget list from the arbitrary area
    $widgets = $this->getArbitraryWidgets();

    // check if the active widgets are valid
    foreach($widgets as $key => $widget){
      if(!in_array($widget['id'], $active_tabs, true)){
        unset($widgets[$key]);
      }else{
        if($widget['output'] = $app->getWidget($widget['id'])){
          $valid_tabs[] = "tab-{$widget['id']}";
          $valid_widgets[] = $widget;
        }
      }
    }

    // sort them as intended
    $sorted_widgets = array();
    foreach($active_tabs as $tab)
      foreach($valid_widgets as $index => $widget)
        if($widget['id'] === $tab)
          $sorted_widgets[] = $widget;

    $valid_widgets = $sorted_widgets;


    // stores the active tab state from the front-end
    $cookie = isset($_COOKIE["tabs-{$this->id}"]) && in_array($_COOKIE["tabs-{$this->id}"], $valid_tabs, true) ? $_COOKIE["tabs-{$this->id}"] : false;

    $fx = $instance['effect'] ? 'data-fx="'.$instance['effect'].'"' : '';
    $event = $instance['event'] ? 'data-event="'.$instance['event'].'"' : '';

    // generate the output
    foreach($valid_widgets as $index => $widget){
      if($index === 0) $widget['classes'][] = 'first'; elseif($index === count($valid_widgets) - 1) $widget['classes'][] = 'last';
      if(($cookie === "tab-{$widget['id']}") || (!$cookie && $index === 0)) $widget['classes'][] = 'active';

      $classes = implode(' ', $widget['classes']);
      $title = apply_filters('atom_widget_tabs_title', ($widget['title'] ? $widget['title'] : '&nbsp;'), $widget, $instance);
      $hidden = ($cookie === "tab-{$widget['id']}") || (!$cookie && $index === 0) ? '' : 'hidden';

      $output[$index]['nav'] = "<li class=\"{$classes}\" id=\"nav-{$widget['id']}\"><a href=\"#tab-{$widget['id']}\">{$title}</a></li>\n";
      $output[$index]['content'] = "<div class=\"section {$hidden}\" id=\"tab-{$widget['id']}\">\n{$widget['output']}\n</div>\n";
    }

    if(empty($valid_widgets))
      return $app->addDebugMessage("Tabbed widgets are not configured in {$widget_id} ({$widget_name}). Widget marked as inactive");

    if(empty($output))
      return $app->addDebugMessage("No active widget (tabs) in {$widget_id} ({$widget_name}). Widget marked as inactive");

    echo $before_widget; // <div style="position:absolute; top: 30px;border-bottom:1px solid #3d3;width:100%;height:1px;"></div>
    ?>
    <div class="tabs widgets" id="tabs-<?php echo $this->id; ?>" <?php echo $fx; ?> <?php echo $event; ?>>
      <ul class="navi clear-block">
        <?php foreach($output as $tab) echo $tab['nav']; ?>
      </ul>
      <div class="sections">
        <?php foreach($output as $section) echo $section['content']; ?>
      </div>
    </div>
    <?php
    echo $after_widget;

  }

  public function update($new_instance, $old_instance){
    $instance['widgets'] = $new_instance['widgets'];
    $instance['effect']  = esc_attr($new_instance['effect']);
    $instance['event']   = esc_attr($new_instance['event']);
    return $instance;
  }

  public function form($instance){

    if(!Atom::app()->options('jquery')): ?>
      <div class="atom-block">
        <p class="widget-error"><?php _ae("This widget requires jQuery to be enabled"); ?></p>
      </div>
      <?php return;
    endif;

    $instance = wp_parse_args($instance, $this->getDefaults());
    $active_tabs = is_array($instance['widgets']) ? $instance['widgets'] : array();
    $icons = is_array($instance['icons']) ? $instance['icons'] : array();
    ?>

    <div <?php $this->formClass(); ?>>
    <?php

    if(is_int($this->number)):
      $all_widgets = $this->getArbitraryWidgets();

      if(empty($all_widgets)){
        echo '<p class="widget-error">'._a('To add tabs, you must have at least one active arbitrary widget. Click save to refresh...').'</p>';
      }else{

        // sort
        $ordered_widgets = $ordered_icons = array();
        foreach($active_tabs as $w)
          foreach($all_widgets as $i => $a)
            if($w == $a['id']){
              $ordered_widgets[] = $a;
              unset($all_widgets[$i]);
            }
        $ordered_widgets = array_merge($ordered_widgets, $all_widgets);

        foreach($ordered_widgets as $w)
          $ordered_icons[$w['id']] = isset($icons[$w['id']]) ? $icons[$w['id']] : '';

        $sidebars_widgets = wp_get_sidebars_widgets();
        $output = array();

        $output[] = '<p>'._a('Create Tabs for:').'</p>';
        $output[] = '<ul id="tabs_'.$this->id.'" class="arbitrary-widget-list">';

        list($icon_width, $icon_height) = explode('x', Atom::app()->options('widget_icon_size'));

        $icon = '';

        foreach($ordered_widgets as $w){
          // is the current widget checked?
          $checked = (in_array($w['id'], $active_tabs));

          // checkbox and label
          $output[] = '<li class="entry '.($checked ? 'checked' : '').'">';
          $output[] = '<label>';
          $output[] = '<input name="'.$this->get_field_name('widgets').'[]" type="checkbox" value="'.$w['id'].'" '.($checked ? 'checked="checked"' : '').'" />';
          $output[] = '<strong>'.$w['name'].'</strong>'.($w['title'] ? ": {$w['title']}" : '');
          $output[] = '</label>';
//          $output[] = '<a class="current-icon" style="width:'.$icon_width.'px;height:'.$icon_height.'px;">'.$ordered_icons[$w['id']].'</a>';
//          $output[] = '<input type="hidden" name="'.$this->get_field_name('icons').'[]" value="'.$ordered_icons[$w['id']].'" />';
          $output[] = '</li>';
        }

        $output [] = '</ul><br />';

/*
        $output [] = '<div class="widget-icon-list">';

        $output [] = '<div class="clear-block">';

        $output [] = '<h3>'._a('Theme-default:').'</h3>';
        $output [] = '<ul>';

        for($y = 0; $y <= ($icon_height * 10); $y = $y + $icon_height)
          $output[] = '<li class="icon default" data-number="'.round($y / $icon_height).'"><span style="width:'.$icon_width.'px;height:'.$icon_height.'px;background-position:0 -'.$y.'px"></span></li>';

        $output [] = '</ul>';
        $output [] = '</div>';

        $user_icons = $this->getIcons();
        if(empty($user_icons)){

          $output[] = '<p><em>';

          if(is_child_theme())
            $output[] = sprintf(_a('You can also include your own icons within this list, by copying them inside this folder: %s'),
              sprintf('<strong>%s</strong>', '/'.basename(WP_CONTENT_DIR).'/themes/'.basename(STYLESHEETPATH).'/'.AtomWidget::USER_ICON_DIR.'/'));

          else
            $output[] = _a('Activate a child theme to add your own icons in this list.');

          $output[] = '</em></p>';

        }else{
          $icons_url = trailingslashit(Atom::app()->get('child_theme_url').'/'.AtomWidget::USER_ICON_DIR);

          $output [] = '<h3>'._a('Your icons:').'</h3>';
          $output [] = '<ul>';

          // user icon images
          foreach($user_icons as $icon)
            $output[] = '<li class="icon user"><img src="'.$icons_url.$icon.'.png" alt="'.$icon.'" title="'.$icon.'" width="'.$icon_width.'" height="'.$icon_height.'" /></li>';

          $output [] = '</ul>';
        }

        $output [] = '</div>';
*/
        echo implode("\n", $output);

      } ?>
      <script type="text/javascript">
        //<![CDATA[

        jQuery(document).ready(function($){

          $("#tabs_<?php echo $this->id; ?>").each(function(){
            var tabs = $(this),
                icons = tabs.parent().find('.widget-icon-list');

            tabs.sortable().disableSelection();

            $('.current-icon', tabs).click(function(event){
              icons.show();

            });

          });

          $('.widget-icon-list').each(function(){
            var list = $(this);

            $('.icon').click(function(event){
              var icon = $(this).hasClass('default') ? $(this).data('number') : $('img', this).attr('src');

              list.hide();
              alert(icon);

            });


          });



        });

        //]]>
      </script>
      <?php
    endif;
    ?>

    <p>
      <label for="<?php echo $this->get_field_id('effect'); ?>"><?php _ae('Transition effect:') ?></label><br />
      <select class="wide" id="<?php echo $this->get_field_id('effect'); ?>" name="<?php echo $this->get_field_name('effect'); ?>">
        <option value="" <?php selected(empty($instance['effect'])); ?>><?php _ae('-- None --'); ?></option>
        <option value="fade" <?php selected($instance['effect'], 'fade'); ?>><?php _ae('Fade'); ?></option>
        <option value="height" <?php selected($instance['effect'], 'height'); ?>><?php _ae('Toggle Height'); ?></option>
      </select>
    </p>

    <p>
      <label for="<?php echo $this->get_field_id('event'); ?>"><?php _ae('Switch-Tab event:'); ?></label><br />
      <select class="wide" id="<?php echo $this->get_field_id('event'); ?>" name="<?php echo $this->get_field_name('event'); ?>">
        <option value="" <?php selected(empty($instance['event'])); ?>><?php _ae('Click'); ?></option>
        <option value="dblclick" <?php selected($instance['event'], 'dblclick'); ?>><?php _ae('Double-Click'); ?></option>
        <option value="mouseover" <?php selected($instance['event'], 'mouseover'); ?>><?php _ae('Mouse Over'); ?></option>
      </select>
    </p>
    </div>
    <?php
  }

}