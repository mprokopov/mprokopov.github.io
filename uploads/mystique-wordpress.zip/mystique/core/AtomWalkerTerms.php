<?php

/**
 * Replaces WP's default category walker (which doesn't allow much control over the output and the css classes provided are useless)
 * All content inside the list item can be formatted trough the "link-callback" function
 *
 * @since 1.2
 */
class AtomWalkerTerms extends Walker{
  var $tree_type = 'category';
  var $db_fields = array('parent' => 'parent', 'id' => 'term_id');

  function start_lvl(&$output, $depth, $args){
    $indent = str_repeat("\t", $depth);
    $output .= "{$indent}<ul class=\"children\">\n";
  }

  function end_lvl(&$output, $depth, $args){
    $indent = str_repeat("\t", $depth);
    $output .= "{$indent}</ul>\n";
  }

  function start_el(&$output, $term, $depth, $args){
    extract($args);

    // @todo: handle "current" context for custom taxonomies
    if(isset($current_category) && $current_category) $_current_category = get_category($current_category);

    $output .= "\t<li";
    $class = "term-{$term->term_id}";
    if (isset($current_category) && $current_category && ($term->term_id == $current_category)) $class .= ' active';
    elseif (isset($_current_category) && $_current_category && ($term->term_id == $_current_category->parent)) $class .= ' active-parent';

    $output .= " class=\"{$class}\">";

    if(!empty($args['link-callback'])) $output .= call_user_func($args['link-callback'], $term, $args, $depth);
    else $output .= '<a href="'.get_term_link($term, $term->taxonomy).'" title="'
                 .esc_attr(strip_tags(apply_filters('category_description', $term->description, $term))).'">'
                 .apply_filters('list_cats', esc_attr($term->name), $term).'</a>';
  }

  function end_el(&$output, $page, $depth, $args){
    $output .= "</li>\n";
  }
}
