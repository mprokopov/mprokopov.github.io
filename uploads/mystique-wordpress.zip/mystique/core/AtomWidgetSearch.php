<?php

/**
 * Atom Search Widget
 *
 * Displays the search form
 * Unlike the default widget this one doesn't allow titles (search in Atom-based themes should be too pretty to require titles ;)
 *
 * @since 1.0
 */


class AtomWidgetSearch extends AtomWidget{

  public function AtomWidgetSearch(){
    $this->WP_Widget('atom-search', _a('Search'), array('classname' => 'search', 'description' => _a('A search form for your site')));
  }

  public function widget($args, $instance){
    extract($args);
    echo $before_widget;
    get_search_form();
    echo $after_widget;
  }
  
  public function form(){}

}