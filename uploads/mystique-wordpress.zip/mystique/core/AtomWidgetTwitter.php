<?php

/**
 * Twitter updates
 *
 * @since 1.0
 * @todo maybe add 'show more' functionality; might be useless because of the 20 tweet limit
 */
 


class AtomWidgetTwitter extends AtomWidget{

  public function AtomWidgetTwitter(){
    $this->WP_Widget('atom-twitter', _a('Twitter'), array('classname' => 'twitter', 'description' => _a("Your latest Twitter updates")));

    $default_twitter_user = 'stewiegriffin';

    // attempt to get the twitter user name from the twitter media setting
    if(Atom::app()->options('media_twitter'))
      $default_twitter_user = basename(Atom::app()->options('media_twitter'));

    // default settings
    $this->setDefaults(array(
      'title'    => _a('Tweets'),
      'user'     => $default_twitter_user,
      'count'    => 4,
      'info'     => true,
      'cache'    => 90,
    ));

    Atom::add('ajax_requests', array(&$this, 'ajax'));

    // include in jQuery(document).ready()
    Atom::add('jquery_init', array(&$this, 'js'));
  }

  public function ajax(){
    if(!Atom::app()->request('get_twitter_data')) return;

    Atom::app()->ajaxHeader('get_twitter_data');
    $this->displayTweets(esc_attr(strip_tags($_GET['widget_id'])), esc_attr(strip_tags($_GET['twituser'])), (int)$_GET['twitcount'], false, (bool)$_GET['showinfo']);
    exit;
  }

  public function js(){

    // we need to process all instances because this function gets to run only once
    $widget_settings = get_option($this->option_name);

    foreach((array)$widget_settings as $instance => $options):

      // identify instance
      $id = "{$this->id_base}-{$instance}";
      $block_id = "instance-{$id}";

      if(!is_active_widget(false, $id, $this->id_base)) continue;

      $options = wp_parse_args($options, AtomWidget::getObject($id)->getDefaults());
      if(false === ($data = get_transient($block_id))): ?>

        $.ajax({
          type: "GET",
          url: "<?php echo home_url(); ?>",
          data: { widget_id: '<?php echo $block_id; ?>',
                  twituser: '<?php echo $options['user']; ?>',
                  twitcount: <?php echo (int)$options['count']; ?>,
                  showinfo: <?php echo (int)$options['info']; ?>,
                  _ajax_nonce: "<?php echo wp_create_nonce('atom_get_twitter_data'); ?>",
                  atom: 'get_twitter_data'
                },
          beforeSend: function() { },
          complete: function() { },
          success: function(response){
            var block = $('#<?php echo $block_id; ?>');
            $('.latest-tweets', block).html(response);

            <?php if(Atom::app()->options('effects')): // animate list ?>
            $('.latest-tweets li', block).hide().each(function(i){
               $(this).delay(333*i).animate(
                  {
                    "opacity": "show",
                    "height": "show",
                    "marginTop": "show",
                    "marginBottom": "show",
                    "paddingTop": "show",
                    "paddingBottom": "show"
                  },
                  { duration: 333,
                    step: function(now, fx){
                    $('.latest-tweets', block).parents('li.block .sections').height((block.height()) + 5);
                  }
               });
            });
            <?php endif; ?>

          }
        });

      <?php endif;
    endforeach;
  }

  private function displayTweets($id, $user, $count, $data = false, $showinfo = true, $cache = 90){
    $error = false;

    if(!$data && (($data = get_transient($id)) === false)){
      if($showinfo){
        $response = wp_remote_retrieve_body(wp_remote_request("http://twitter.com/users/show/{$user}.json"));
        if(!is_array($userdata = json_decode($response, true))) $error = true;
      }
      $response = wp_remote_retrieve_body(wp_remote_request("http://twitter.com/statuses/user_timeline/{$user}.json"));
      if(!is_array($tweets = json_decode($response, true))) $error = true;

      if(!$error){
        if(isset($tweets['error'])){
          $error = esc_attr($tweets['error']);

        }else{
          $data = array();
          if($showinfo){
            $data['user']['profile_image_url'] = esc_url($userdata['profile_image_url']);
            $data['user']['name'] = esc_attr(strip_tags($userdata['name']));
            $data['user']['screen_name'] = esc_attr(strip_tags($userdata['screen_name']));
            $data['user']['followers_count'] = (int)$userdata['followers_count'];
            $data['user']['statuses_count'] = (int)$userdata['statuses_count'];
            $data['user']['description'] = esc_attr(strip_tags($userdata['description']));
          }

          $i = 0;
          foreach($tweets as $tweet){
            $data['tweets'][$i]['text'] = esc_attr(strip_tags($tweet['text']));

            $tweet_time = esc_attr(strip_tags($tweet['created_at']));
            $data['tweets'][$i]['created_at'] = abs(strtotime("{$tweet_time} UTC"));

            // unfortunately JSON_BIGINT_AS_STRING option doesn't seem to work with json_decode :(
            // we can just hope that the float conversion is right here...
            // $data['tweets'][$i]['id'] = esc_attr(strip_tags($tweet['id']));
            $data['tweets'][$i]['id'] = number_format($tweet['id'], 0, '.', '');
            $i++;
          }

          set_transient($id, $data, (int)$cache); // keep the data cached
        }
      }
    }


    if(!$error && is_array($data['tweets'])): ?>
     <?php if($showinfo): ?>
     <div class="info box clear-block">
       <div class="avatar">
         <img width="48" height="48" src="<?php echo $data['user']['profile_image_url']; ?>" alt="<?php echo $data['user']['name']; ?>" />
       </div>
       <div class="details">
         <a href="http://www.twitter.com/<?php echo $user; ?>/" title="<?php echo $data['user']['description']; ?>"><?php echo $data['user']['name']; ?> </a>
         <span class="followers"> <?php printf(_a("%s followers"),$data['user']['followers_count']); ?></span>
         <span class="count"> <?php printf(_a("%s tweets"),$data['user']['statuses_count']); ?></span>
       </div>
     </div>
     <?php endif; ?>
     <ul class="tweets box">
      <?php
        $i = 0;
        foreach($data['tweets'] as $tweet){
          $i++;
          $pattern = '/\@(\w+)/';
          $replace = '<a rel="nofollow" href="http://twitter.com/$1">@$1</a>';
          $tweet['text'] = preg_replace($pattern, $replace, $tweet['text']);
          $tweet['text'] = convert_smilies(make_clickable($tweet['text']));

          $link = "http://twitter.com/{$user}/statuses/{$tweet['id']}";
          echo '<li class="entry '.($i == 1 ? 'first' : null).'">'.$tweet['text'].'<a class="date" href="'.$link.'" rel="nofollow">'.Atom::app()->getTimeSince($tweet['created_at'], time()).'</a></li>';
          if ($i == $count) break;
        }
      ?>
     </ul>

    <?php else:
      if(current_user_can('edit_theme_options')){
        echo '<div class="box error">';
        if(is_string($error)) printf(_a("Twitter returned error: %s"), $error);
        else _ae("Could not retrieve tweets.");
        echo '</div>';

        if(!is_string($error)){
          echo '<p>'._a("Possible reasons:").'</p>';
          echo '<ul>';
          echo '<li>'._a("Your host doesn't allow outgoing connections").'</li>';
          echo '<li>'._a("Your server has made too many requests and is being limited (try increasing the cache value)").'</li>';
          echo '<li>'._a("The user has protected his/her tweets").'</li>';
          echo '<li>'._a("Twitter may be down").'</li>';
          echo '</ul';
        }
      }else{
        echo '<div class="box"><em>'._a("Unavailable for the moment").'</em></div>';
      }
    endif;
  }

  public function widget($args, $instance){
    extract($args);
    $instance = wp_parse_args($instance, $this->getDefaults());

    $title = apply_filters('widget_title', $instance['title'], $instance, $this->id_base);
    $user = esc_attr(strip_tags($instance['user']));
    $count = (int)$instance['count'];

    $id = "instance-{$this->id}";

    echo $before_widget;
    if ($title) echo $before_title.$title.$after_title;

    echo '<div class="latest-tweets">';

    if(($data = get_transient($id)) === false && Atom::app()->options('jquery'))
      echo '<div class="box loading"></div>';

    else
      $this->displayTweets($id, $user, $count, $data, (bool)$instance['info'], (int)$instance['cache']);

    echo '</div>';
    echo $after_widget;
  }

  public function update($new_instance, $old_instance){
    $instance = $old_instance;

    $instance['title']  = esc_attr(strip_tags($new_instance['title']));
    $instance['user']   = esc_attr(strip_tags($new_instance['user']));
    $instance['count']  = min(max((int)$new_instance['count'], 1), 20);
    $instance['info']   = (bool)$new_instance['info'];
    $instance['cache']  = (int)$new_instance['cache'] * 60; // turn into seconds (compatibility with Atom < 1.7)

    delete_transient("instance-{$this->id}");
    return $instance;
  }

  public function form($instance){
    $instance = wp_parse_args($instance, $this->getDefaults());
    ?>
    <div <?php $this->formClass(); ?>>
    <p>
     <label for="<?php echo $this->get_field_id('title'); ?>"> <?php _ae('Title:'); ?></label>
     <input class="wide" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($instance['title']); ?>" />
    </p>

    <p>
     <label for="<?php echo $this->get_field_id('user'); ?>"><?php  printf(_a('%s user name:'), 'Twitter'); ?></label>
     <input class="wide" id="<?php echo $this->get_field_id('user'); ?>" name="<?php echo $this->get_field_name('user'); ?>" type="text" value="<?php echo esc_attr($instance['user']); ?>" />
    </p>

    <p>
     <label for="<?php echo $this->get_field_id('count'); ?>"><?php _ae('How many entries to display?'); ?></label>
     <input size="3" id="<?php echo $this->get_field_id('count'); ?>" name="<?php echo $this->get_field_name('count'); ?>" type="text" value="<?php echo esc_attr($instance['count']); ?>" />
    </p>

    <p>
     <label for="<?php echo $this->get_field_id('info'); ?>">
     <input type="checkbox" id="<?php echo $this->get_field_id('info'); ?>" name="<?php echo $this->get_field_name('info'); ?>"<?php checked($instance['info']); ?> />
 	   <?php _ae('Show profile info'); ?></label>
    </p>

    <p>
     <?php
      $cache_input = '<input size="4" id="'.$this->get_field_id('cache').'" name="'.$this->get_field_name('cache').'" type="text" value="'.(round((int)$instance['cache'] / 60)).'" />';
     ?>
     <label for="<?php echo $this->get_field_id('cache'); ?>"><?php printf(_a('Keep data cached for %s minute(s)'), $cache_input) ?></label>

    </p>

    </div>
    <?php
  }
}