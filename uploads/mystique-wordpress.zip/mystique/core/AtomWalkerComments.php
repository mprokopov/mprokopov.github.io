<?php



/**
* Replaces WP's default comment walker
*   thread comments pagination helper functions - http://wordpress.stackexchange.com/questions/20506
*   print index count - http://wordpress.stackexchange.com/questions/20527
*
* @since 1.6
* @uses Walker
*/
class AtomWalkerComments extends Walker{

  public
    $tree_type = 'comment',
    $db_fields = array('parent' => 'comment_parent', 'id' => 'comment_ID'),
    $current_comment_print_index = 0;

  // uncomment to enable thread-aware pagination and comment display index count

  function paged_walk($elements, $max_depth, $page_num, $per_page){
    $this->current_comment_print_index = 0;

    if(empty($elements) || $max_depth < -1) return '';

    $args = array_slice(func_get_args(), 4);
    $output = '';

    $id_field = $this->db_fields['id'];
    $parent_field = $this->db_fields['parent'];

    $count = -1;
    if($max_depth == -1) $total_top = count($elements);
    if($page_num < 1 || $per_page < 0){
      // No paging
      $paging = false;
      $start = 0;
      if($max_depth == -1) $end = $total_top;
      $this->max_pages = 1;
    }else{
      $paging = true;
      $start = ((int)$page_num - 1) * (int)$per_page;
      $end = $start + $per_page;
      if($max_depth ==  -1) $this->max_pages = ceil($total_top / $per_page);
    }

    // flat display
    if($max_depth ==  -1){
      if(!empty($args[0]['reverse_top_level'])){
        $elements = array_reverse($elements);
        $oldstart = $start;
        $start = $total_top - $end;
        $end = $total_top - $oldstart;
      }

      if($paging){
        // HK: if paging enabled and its a flat display.
        // HK: mark the current print index from page number * comments per page
        $this->current_comment_print_index = ((int)$page_num - 1) * $per_page;
      }

      $empty_array = array();
      foreach($elements as $e){
        $count++;
        if($count < $start) continue;
        if($count >= $end) break;
        $this->display_element($e, $empty_array, 1, 0, $args, $output);
      }
      return $output;
    }

    // separate elements into two buckets: top level and children elements
    // children_elements is two dimensional array, eg.
    // children_elements[10][] contains all sub-elements whose parent is 10.
    list($top_level_elements, $children_elements) = $this->get_top_and_child_elements($elements);

    $total_top = count($top_level_elements);

    // do we need paging?
    if($paging && count($elements) > $per_page){

      $page_starts = $this->get_element_page_starts($per_page, $top_level_elements, $children_elements);
      $this->max_pages = count($page_starts);

      if(isset($page_starts[$page_num])){ // valid page
        $start = $page_starts[$page_num];

        // set end to start key for next page
        if(isset($page_starts[$page_num + 1])) $end = $page_starts[$page_num + 1];

        // no next page, end is last key + 1
        else $end = $total_top;
      }else{ // invalid page number - void indexes
        $start = $total_top;
        $end = $start + $per_page;
      }

    }else{
      $start = 0;
      $end = $total_top;
    }

    if(!empty($args[0]['reverse_top_level'])){
      $top_level_elements = array_reverse($top_level_elements);
      //!!
      $oldstart = $start;
      $start = $total_top - $end;
      $end = $total_top - $oldstart;
    }

    if(!empty($args[0]['reverse_children']))
      foreach($children_elements as $parent => $children) $children_elements[$parent] = array_reverse($children);

    foreach($top_level_elements as $k => $e){

      $count++;

      // HK: current iteration index, will be added to global index
      // NOTE: will only be added to global index if already printed
      $iteration_comment_print_index = 1;
      // HK: count of current iteration children (includes grand children too)
      $iteration_comment_print_index += $this->count_children($e->comment_ID, $children_elements);

      //for the last page, need to unset earlier children in order to keep track of orphans
      if($end >= $total_top && $count < $start) $this->unset_children($e, $children_elements);

      if($count < $start){
        // HK: if we have already printed this top level comment
        // HK: then just add the count (including children) to global index and continue
        $this->current_comment_print_index += $iteration_comment_print_index;
        continue;
      }

      if($count >= $end) break;


           //!!
      // for the last page, need to unset earlier children in order to keep track of orphans
      if($end >= $total_top && $k < $start) $this->unset_children($e, $children_elements);
      if($k < $start) continue;
      if($k >= $end) break;

      $this->display_element($e, $children_elements, $max_depth, 0, $args, $output);
    }

    if($end >= $total_top && count($children_elements) > 0){
      $empty_array = array();
      foreach($children_elements as $orphans)
      foreach($orphans as $op)
      $this->display_element($op, $empty_array, 1, 0, $args, $output);
    }

    return $output;
  }

  public function display_element($element, &$children_elements, $max_depth, $depth = 0, $args, &$output){

    if(!$element) return;

    $id_field = $this->db_fields['id'];
    $id = $element->$id_field;

    // increment for current comment we are printing
    $this->current_comment_print_index += 1;

    parent::display_element($element, $children_elements, $max_depth, $depth, $args, $output);


    // If we're at the max depth, and the current element still has children, loop over those and display them at this level
    // This is to prevent them being orphaned to the end of the list.
    if($max_depth <= $depth + 1 && isset($children_elements[$id])){
      foreach($children_elements[$id] as $child)
        $this->display_element($child, $children_elements, $max_depth, $depth, $args, $output);

      unset($children_elements[$id]);
    }

  }



  private function count_children($comment_id, $children_elements){
    $children_count = 0;
    if(isset($children_elements[$comment_id])){
      $children_count = count($children_elements[$comment_id]);
      foreach($children_elements[$comment_id] as $child)
        $children_count += $this->count_children($child->comment_ID, $children_elements);

    }
    return $children_count;
  }



  // Get total number of children for an element, recursively working down the tree if neccessary.
  private function get_total_children($id, $child_elements = array()){
    if(empty($id) || empty($child_elements[$id])) return 0;
    $count = count($child_elements[$id]);
    $id_field = $this->db_fields['id'];

    // iterate over children and recursively call if they themselves have children
    foreach($child_elements[$id] as $child){
      if(!empty($child_elements[$child->$id_field]))
        $count = $count + $this->get_total_children($child->$id_field, $child_elements);
    }

    return $count;
  }



  // Separate elements into two buckets: top level and children elements.
  // Children elements is a two dimensional array, indexed by parent ID.
  private function get_top_and_child_elements($elements){
    $parent_field = $this->db_fields['parent'];

    $top_elements = $child_elements = array();

    foreach($elements as $e)
      if($e->$parent_field == 0) $top_elements[] = $e; else $child_elements[$e->$parent_field][] = $e;

    return array($top_elements, $child_elements);
  }



  // Get the page start indexes for $top_elements.
  private function get_element_page_starts($per_page, $top_elements, $child_elements){
    $id_field = $this->db_fields['id'];
    $page_starts = array(1 => 0);
    $stack_count = 0;

    foreach($top_elements as $k => $e){

      // add *this* and ALL children to the count stack
      $stack_count = ++$stack_count + $this->get_total_children($e->$id_field, $child_elements);

      if($stack_count < $per_page) continue; // keep-a-counting

      // hit maximum for the page, start a new one with next element
      if(isset($top_elements[$k + 1])) $page_starts[] = $k + 1;
      $stack_count = 0; // reset stack
    }

    return $page_starts;
  }



  // This does not actually return the total number of root elements!
  // It's a trick so that {@see get_comment_pages_count()} calculates the correct number of pages.
  // Will break if you start passing custom 'per_page' arguments about.
  public function get_number_of_root_elements($elements){
    $per_page = (int)get_query_var('comments_per_page');

    if($per_page === 0) $per_page = (int)get_option('comments_per_page');

    if($per_page === 0) $per_page = 1;

    list($top_elements, $child_elements) = $this->get_top_and_child_elements($elements);
    $page_starts = $this->get_element_page_starts($per_page, $top_elements, $child_elements);

    return count($page_starts) * $per_page;
  }

  //*/


  // @see Walker::start_lvl()
  function start_lvl(&$output, $depth, $args){
    $GLOBALS['comment_depth'] = $depth + 1;

    switch($args['style']){
      case 'div':
      break;
      case 'ol':
      echo "<ol class='children'>\n";
      break;
      default:
      case 'ul':
      echo "<ul class='children'>\n";
      break;
    }
  }



  // @see Walker::end_lvl()
  public function end_lvl(&$output, $depth, $args){
    $GLOBALS['comment_depth'] = $depth + 1;

    switch($args['style']){
      case 'div':
      break;
      case 'ol':
      echo "</ol>\n";
      break;
      default:
      case 'ul':
      echo "</ul>\n";
      break;
    }
  }



  /**
  * @see Walker::start_el()
  * @since 2.7.0
  *
  * @param string $output Passed by reference. Used to append additional content.
  * @param object $comment Comment data object.
  * @param int $depth Depth of comment in reference to parents.
  * @param array $args
  */
  public function start_el(&$output, $comment, $depth, $args){
    $depth++;

    $GLOBALS['comment_depth'] = $depth;

    Atom::app()->setCurrentComment($comment);
    Atom::app()->comment->display_index = $this->current_comment_print_index;
    Atom::app()->template($args['type'] !== 'comment' ? 'ping' : 'comment');
  }



  /**
  * @see Walker::end_el()
  * @since 2.7.0
  *
  * @param string $output Passed by reference. Used to append additional content.
  * @param object $comment
  * @param int $depth Depth of comment.
  * @param array $args
  */
  public function end_el(&$output, $comment, $depth, $args){
    echo ($args['style'] !== 'div') ? "</li>\n" : "</div>\n";
  }
}

