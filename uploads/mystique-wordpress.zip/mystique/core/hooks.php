<?php
/**
 * Atom filters and actions that change WP's behaviour
 *
 * @link http://digitalnature.eu
 *
 * @package ATOM
 * @subpackage Template
 */



/**
 * Check WordPress version and register out hooks if everything is OK
 *
 * @since 1.7
 */
function atom_register_hooks(){
  global $wp_version;

  // if the current wp version is lower than the minimum required version display a error message and don't go further
  if($wp_version < ATOM_REQ_WP_VERSION){
    add_action('admin_notices',            'atom_unsupported_wp_version');
    add_action('wp',                       'atom_unsupported_wp_version');

    // stop, don't register hooks...
    return false;
  }

  // css class adjustments
  add_filter('body_class',                 'atom_body_class');
  add_filter('post_class',                 'atom_post_class');
  add_filter('comment_class',              'atom_comment_class');
  add_filter('wp_nav_menu_args',           'atom_nav_menu_settings');
  add_filter('page_css_class',             'atom_page_css_classes', 10, 2);
  add_filter('nav_menu_css_class',         'atom_menu_css_classes', 10, 2);

  // generator meta
  add_filter('get_the_generator_xhtml',    'atom_meta_generator', 10, 2);

  // change 'index' on archive page
  add_filter('index_rel_link',             'atom_link_rel_index');

  // ajax/get requests -- should be on "init" but some requests might need the post data to be set up
  add_action('wp',                         'atom_requests');

  // hook widget visibility options
  add_filter('widget_display_callback',    'atom_visibility_check');

  // setup widgets
  add_action('widgets_init',               'atom_widgets_init');


  add_action('admin_bar_menu',             'atom_wp_admin_bar_menu', 79);

  // template redirect
  add_action('template_redirect',          'atom_redirect');


  // style / scripts output
  add_action('wp_head',                    'atom_inline_css', 420);

  if(!is_admin()){
    add_action('wp_print_scripts',           'atom_print_scripts');
    add_action('wp_print_styles',            'atom_print_styles');
  }

  add_action('wp',                         'atom_enqueue_scripts');
  add_action('wp',                         'atom_enqueue_styles');

  add_action('wp_scheduled_delete',        'atom_delete_expired_transients');
  add_action('init',                       'atom_set_thumb_sizes');

  // atom hooks
  add_action('atom_before_page',           'atom_check_js');

  // remove post relational links
  remove_action('wp_head',                 'start_post_rel_link', 10, 0 );
  remove_action('wp_head',                 'adjacent_posts_rel_link_wp_head', 10, 0);

  add_filter('query_vars',                 'atom_query_vars');
  add_action('parse_query',                'atom_register_app_query_var');

  add_filter('pre_get_posts',              'atom_include_cpt_in_archives');

  Atom::action('init');

  return true;
}



/**
 * Get the translation of a string
 * Uses WP's __() function.
 * These functions only exist to make templating easier by omitting the textdomain (ATOM) :)
 *
 * @since 1.2
 *
 * @param string $string
 *
 * @return string Translated string
 */
function _a($string){
  return __($string, ATOM);
}



/**
 * Output the translation of a string
 * Uses WP's _e() function.
 *
 * @since 1.2
 *
 * @param string $string
 */
function _ae($string){
  _e($string, ATOM);
}



/**
 * Get the single/plural form of a string
 * Uses WP's _n() function.
 *
 * @since 1.2
 *
 * @param string $string
 *
 * @return string Translated string
 */
function _an($single, $plural, $number){
  return _n($single, $plural, $number, ATOM);
}



/**
 * register the "atom" query variable
 *
 * @since 1.0
 */
function atom_query_vars($public_query_vars){
  $public_query_vars[] = 'atom';
  return $public_query_vars;
}



/**
 * Expose $app inside default wp templates
 * @todo: build & load custom templates and remove this (just like teaser/comment)
 *
 * @since 1.7
 */
function atom_register_app_query_var(){
  set_query_var('app', Atom::app());
}



/**
 * User functions, on all pages except dashboard & /wp-login
 *
 * @since 1.7
 */
function atom_user_functions($_user_functions){

  // check page
  if(is_admin() || (strpos($_SERVER['REQUEST_URI'], 'wp-login.php') !== false) || !is_child_theme() || !is_readable($_user_functions)) return;

  // expose $app
  $app = &Atom::app();

  require $_user_functions;
}



/**
 * Checks for the "post_type" query argument on archive pages, and changes the query if needed
 * This filter is required for CPT-related options in the Atom Archives / Calendar widgets to work
 *
 * @since 1.7
 *
 * @param object $query
 *
 * @return object new query
 */
function atom_include_cpt_in_archives($query){
  if(is_archive() && isset($_GET['post_type']) && post_type_exists($_GET['post_type'])) // validate
    $query->set('post_type', $_GET['post_type']);

  return $query;
}



/**
 * Template redirect
 *
 * @since 1.3
 */
function atom_redirect(){
  // expose $app
  $app = Atom::app();

  // check for internal pages
  if(get_query_var('pagename')){
    $_page = get_query_var('pagename');

    if($_page && is_child_theme() && file_exists(STYLESHEETPATH.'/internal-'.$_page.'.php'))
      $_template = STYLESHEETPATH.'/internal-'.$_page.'.php';
    elseif($_page && file_exists(TEMPLATEPATH.'/internal-'.$_page.'.php'))
      $_template = TEMPLATEPATH.'/internal-'.$_page.'.php';

    if(isset($_template)){
      // a 404 code will not be returned in the HTTP headers if the page does not exist in the db
      status_header(200);
      $GLOBALS['wp_query']->is_404 = false;

      // used to set a body class
      $app->is_internal_page = $_page;

      // include the corresponding template
      require $_template;
      die();
    }

  }

  // redirect (only on single posts or pages if custom field exists)
  if(is_single() || is_page()){
    global $post;
        
    if($url = get_post_meta($post->ID, 'redirect', true)){
      wp_redirect(esc_url($url), 301); // @todo: add redirect type cf.
      exit;
    }
  } 
}



/**
 * Append the Atom version in the generator meta field
 *
 * @since 1.0
 *
 * @param string $generator
 * @param string $type
 */
function atom_meta_generator($generator, $type){
  return '<meta name="generator" content="WordPress '.get_bloginfo('version').', ATOM '.ATOM_VERSION.'" />';
}



/**
 * Changes the default <index rel="index" /> value depending on the current page context
 *
 * @since 1.7
 *
 * @param string $link Current link
 *
 * @return string new value
 */
function atom_link_rel_index($link){

  // defaults
  $title = esc_attr(get_bloginfo('name', 'display'));
  $url = esc_url(user_trailingslashit(get_bloginfo('url', 'display')));

  // single page/post/cpt
  if(is_singular()){
    $post_type = get_post_type();

    // @todo - maybe - handle hierarchy?
    if(!in_array($post_type, array('post', 'page'))){
      $title = post_type_archive_title($post_type);
      $post_type_object = get_post_type_object($post_type);
      $title = $post_type_object->labels->name;
      $url = get_post_type_archive_link($post_type);

    }elseif($post_type === 'post'){

      // if the blog is not the index page, then make the index the blog page
      if(get_option('show_on_front') === 'page' && get_option('page_on_front')){
        $blog = get_option('page_for_posts'); // get blog page ID
        $title = get_the_title($blog);
        $url = get_page_link($blog);
      }

    }

  // archives, including category/date/author etc.
  }elseif(is_archive()){

    // handle hierarchy, set the index to parent term
    $term = get_queried_object();
    if(!is_wp_error($term) && !empty($term->parent)){
      $tax = get_taxonomy($term->taxonomy);
      $title = $tax->labels->name;
      $url = get_term_link((int)$term->parent, $term->taxonomy);

    }else{

      // root-term, let the index be the homepage, unless...

      // ...the blog is not the index page, then make the index the blog page
      if((is_category() || is_tag() || is_date()) && get_option('show_on_front') === 'page' && get_option('page_on_front')){
        $blog = get_option('page_for_posts'); // get blog page ID
        $title = get_the_title($blog);
        $url = get_page_link($blog);
      }
    }

  }

  return '<link rel="index" title="'.$title.'" href="'.$url.'" />'."\n";
}



/**
 * Generates semantic classes for BODY element (mostly based on the sandbox theme)
 *
 * @since 1.0
 * @global $wp_query object
 *
 * @param array $classes
 */
function atom_body_class($classes){
  global $wp_query, $is_lynx, $is_gecko, $is_IE, $is_opera, $is_NS4, $is_safari, $is_chrome, $is_iphone;

  // Special classes for BODY element when a single post
  if(is_single()){
    $postname = $wp_query->post->post_name;
    the_post();

    // post title
    $classes[] = "title-{$postname}";

    // Adds category classes for each category on single posts
    if($cats = get_the_category())
      foreach($cats as $cat) $classes[] = "category-{$cat->slug}";

    // Adds tag classes for each tags on single posts
    if($tags = get_the_tags())
      foreach($tags as $tag) $classes[] = "tag-{$tag->slug}";

    // Adds author class for the post author
    $classes[] = "author-".sanitize_html_class(strtolower(get_the_author_meta('user_login')));
    rewind_posts();

  }elseif(is_page()){ 	// Page author for BODY on 'pages'
    $pagename = $wp_query->post->post_name;
    the_post();
    $classes[] = "page-{$pagename}";
    $classes[] = "author-".sanitize_html_class(strtolower(get_the_author_meta('user_login')));
    rewind_posts();

  }elseif(!empty(Atom::app()->is_internal_page)){
    $classes[] = 'int';
    $classes[] = 'int-'.Atom::app()->is_internal_page;
  }

  // generate layout related classes
  if(Atom::app()->options('layout')){
    $classes[] = Atom::app()->getLayoutType();
    $classes[] = Atom::app()->options('page_width'); // fluid/fixed
  }

  // custom background image (used for theme preview)
  if(Atom::previewMode() && Atom::app()->options('background_image'))
    $classes[] = Atom::app()->options('custom-bg');

  // detect browser
  if($is_lynx) $browser = 'lynx';
  elseif($is_gecko) $browser = 'gecko';
  elseif($is_opera) $browser = 'opera';
  elseif($is_NS4) $browser = 'ns4';
  elseif($is_safari) $browser = 'safari';
  elseif($is_chrome) $browser = 'chrome';
  elseif($is_IE) $browser = 'ie';
  else $browser = 'unknown';

  // iphone?
  if($is_iphone) $browser .= '-iphone';

  $classes[] = "browser-{$browser}";

  return $classes;
}


/**
 * Generates semantic classes for posts
 *
 * @since 1.0
 * @global $wp_query object
 *
 * @param array $classes
 */
function atom_post_class($classes){
  global $wp_query;

  $current_post = $wp_query->current_post + 1;

  // post alt
  $classes[] = "count-{$current_post}";
  $classes[] = ($current_post % 2) ? 'odd' : 'even alt';

  // thumbnail classes
  if(!in_array('thumb-only', $classes) && (Atom::app()->options('post_thumbs', 'post_thumbs_mode') === TRUE) && !is_singular())
    $classes[] = 'thumb-'.Atom::app()->options('post_thumbs_mode');

  // author
  $classes[] = 'author-'.sanitize_html_class(strtolower(get_the_author_meta('user_nicename')), get_the_author_meta('ID'));

  // password-protected?
  if(post_password_required()) $classes[] = 'protected';

  // first/last class ("first" and "count-1" are the same)
  if($current_post === 1) $classes[] = 'first'; elseif($current_post === $wp_query->post_count) $classes[] = 'last';

  return $classes;
}



/**
 * Generates semantic classes for comments
 *
 * @since 1.0
 * @global $post object
 * @global $comment object
 *
 * @param array $classes
 */
function atom_comment_class($classes) {
  global $post, $comment;

  // avatars enabled?
  if(get_option('show_avatars'))
     $classes[] = 'with-avatars';

  // user roles
  if($comment->user_id > 0){
    $user = new WP_User($comment->user_id);

    if(is_array($user->roles))
      foreach ($user->roles as $role) $classes[] = 'role-'.$role;
    $classes[] = 'user-'.sanitize_html_class(strtolower($user->user_nicename), $user->ID);
  }else{
    $classes[] = 'reader name-'.sanitize_html_class(strtolower(get_comment_author()));
  }

  // needs moderation?
  if($comment->comment_approved == '0') $classes[] = 'awaiting-moderation';

  // karma-related
  if(Atom::app()->comment->isBuried()) $classes[] = 'buried';
  if(Atom::app()->options('comment_karma'))
    if((int)$comment->comment_karma < 0) $classes[] = 'karma-negative'; elseif((int)$comment->comment_karma > 0) $classes[] = 'karma-positive';

  return $classes;
}



/**
 * Adjust classes added by the page walker
 *
 * @since 1.0
 *
 * @param array $classes CSS classes
 * @param object $page Current page
 *
 * @return array Updated classses
 */
function atom_page_css_classes($old_classes, $page){
  // use page (safe) name instead of ID; nobody styles IDs...
  $classes = array("page-{$page->post_name}");

  // adjust active menu classes to match the ones added by wp_nav_menu()
  foreach($old_classes as $class)
    if($class === 'current_page_item')
      $classes[] = 'active';
    elseif($class === 'current_page_parent' || $class === 'current_page_ancestor') // no need for a "ancestor" class, useless
      $classes[] = 'active-parent';

  // overwrite
  return $classes;
}



/**
 * Adjust classes added by the menu walker
 *
 * @since 1.0
 *
 * @param array $classes CSS classes
 * @param object $item Current menu item
 *
 * @return array Updated classses
 */
function atom_menu_css_classes($old_classes, $item){
  // remove useless classes like id-xxx and only keep the object title
  $classes = array('menu-'.sanitize_html_class(strtolower($item->title)));

  // we are going to replace old classes with 'active' or 'active-parent'
  $allowed_classes = array('current-menu-item', 'current-menu-parent', 'current-menu-ancestor', 'extends');
  $new_classes = array('active', 'active-parent', 'active-parent', 'extends');

  foreach($old_classes as $class)
    if(in_array($class, $allowed_classes))
      $classes[] = str_replace($allowed_classes, $new_classes, $class);

  return $classes;
}



/**
 * Add "extends" css class to menus that have children
 * used for adding padding for the graphic arrow, and for identifying expandable-collapsible lists within the custom menu widget
 *
 * @since 1.0
 */
class Walker_Nav_Menu_Arrow extends Walker_Nav_Menu{
  function display_element($element, &$children_elements, $max_depth, $depth = 0, $args, &$output) {
    $id_field = $this->db_fields['id'];

    if(!empty($children_elements[$element->$id_field]))
      $element->classes[] = 'extends';

    parent::display_element($element, $children_elements, $max_depth, $depth, $args, $output);
  }
}



/**
 * Hook the arrow class above to custom menus
 *
 * @since 1.0
 *
 * @param array $args Arguments
 */
function atom_nav_menu_settings($args){

  if(empty($args['fallback_cb']) && Atom::app()->options('jquery'))
    $args['walker'] = new Walker_Nav_Menu_Arrow();

  return $args;
}



/**
 * Sets up widgets
 *
 * @since 1.0
 */
function atom_widgets_init(){

  // sidebars
  $widget_areas = Atom::app()->get('widget_areas');

  // default widgets (used if the theme is installed for the 1st time and if they are not already present in the sidebar, see below)
  $widget_fallbacks = array();

  if(!empty($widget_areas))
    foreach($widget_areas as $area){
      if(isset($area['default_widgets'])){
        $widget_fallbacks[$area['id']] = $area['default_widgets'];
        unset($area['default_widgets']);
      }

      register_sidebar($area);
    }

  // register widgets
  $widgets = Atom::app()->get('widgets');
  if(!empty($widgets))
    foreach((array)$widgets as $widget)
      if((!Atom::app()->get('mu_parent') && $widget !== 'Blogs') || Atom::app()->get('mu_parent')){

      // unregister default widget correspondent
      if($widget === 'Menu') unregister_widget('WP_Nav_Menu_Widget');
      if($widget === 'Meta') unregister_widget('WP_Widget_Meta');
      elseif($widget === 'Posts') unregister_widget('WP_Widget_Recent_Posts');
      elseif($widget === 'Search') unregister_widget('WP_Widget_Search');
      elseif($widget === 'Terms') unregister_widget('WP_Widget_Categories');
      else unregister_widget('WP_Widget_'.preg_replace('/\B([A-Z])/', '_$1', $widget));

      require "AtomWidget{$widget}.php";
      register_widget("AtomWidget{$widget}");
    }

  // first run and no active widgets?
  // add a few then, since a lot of people don't know about widgets.
  // this way they may find out about them by trying to remove these ones :)
  ///
  // @note: this code only runs when the theme is activated, and not on theme options reset
  if(apply_filters('atom_widget_fallback_condition', defined('INSTALLING_ATOM') && !empty($widget_fallbacks))){

    $sidebars_widgets = get_option('sidebars_widgets');
    $have_tabs = false;
    foreach($widget_fallbacks as $sidebar_id => $sidebar_widgets){
      $active_widgets = array();

      // only proceed if this sidebar is empty
      if(empty($sidebars_widgets[$sidebar_id])){
        foreach($sidebar_widgets as $widget => $instance){

          // not a associative array? assume the value is the widget ID base
          if(is_numeric($widget)){
            $widget = $instance;
            $instance = array();
          }

          $widget_options = get_option("widget_{$widget}"); // options for all instances

          Atom::app()->addDebugMessage("A default widget was added to the &lt;{$sidebar_id}&gt; area: {$widget}");

          $widget_options[] = $instance;
          end($widget_options);

          // widget instance ID, eg. atom-posts-2
          $instance_id = key($widget_options);
          $active_widgets[] = $widget.'-'.$instance_id;

          if(!isset($widget_options['_multiwidget'])) $widget_options['_multiwidget'] = 1;

          update_option("widget_{$widget}", $widget_options);

          if($widget === 'atom-tabs') $have_tabs = $instance_id;

        }

        $sidebars_widgets[$sidebar_id] = $active_widgets;
        update_option('sidebars_widgets', $sidebars_widgets);

      }
    }

    // set up first tab widget instance to use all widgets from the 'arbitrary' area
    // -- only if it was found above & if it's "widgets" option is empty
    if($have_tabs){
      $widget_options = get_option('widget_atom-tabs');
      if(empty($widget_options[$have_tabs]['widgets'])){
        $widget_options[$have_tabs]['widgets'] = $sidebars_widgets['arbitrary'];
        update_option('widget_atom-tabs', $widget_options);
      }
    }

  }
}



/**
 * Hide widget/item based on the current context.
 * The check is not strict, ie. if a certain page ID or role is not present in the $instance array (and has a false value),
 * then the item will be considered visible on that page ID / role etc.
 *
 * Important: always use identical operators to check what this functions returns, like === or !===
 * because in some cases $instance might be a empty array (ie. widget doesn't have options set)
 *
 * @since 1.0
 *
 * @param array $instance Instance options
 * @return array|bool returns instance options if widget should be visible on the current page, false otherwise
 */
function atom_visibility_check($instance){
  global $current_user;

  if(is_404() || !is_array($instance)) return false;

  $restricted_post_types = $restricted_taxonomies = $restricted_roles = array();

  // generic pages
  if(is_home())
    $show = isset($instance['page-home']) ? ($instance['page-home']) : true;
  elseif(is_author())
    $show = isset($instance['page-author']) ? ($instance['page-author']) : true;
  elseif(is_date())
    $show = isset($instance['page-date']) ? ($instance['page-date']) : true;
  elseif(is_search())
    $show = isset($instance['page-search']) ? ($instance['page-search']) : true;
  elseif(is_category())
    $show = isset($instance['page-category']) ? ($instance['page-category']) : true;
  elseif(is_tag())
    $show = isset($instance['page-tag']) ? ($instance['page-tag']) : true;
  else $show = true;

  // check single post pages
  foreach($instance as $key => $enabled)
    if(strpos($key, 'page-singular-') === 0 && !$enabled) $restricted_post_types[] = substr($key, 14);

  if(!empty($restricted_post_types))
    foreach($restricted_post_types as $post_type)
      if(is_singular($post_type)) $show = false;


  // check taxonomies
  foreach($instance as $key => $enabled)
    if(strpos($key, 'page-tax-') === 0 && !$enabled) $restricted_taxonomies[] = substr($key, 9);

  if(!empty($restricted_taxonomies))
    foreach($restricted_taxonomies as $tax)
      if(is_tax($tax)) $show = false; // surprisingly category/tags are not considered taxonomies by is_tax(); hopefully this won't change in the future...


  // check pages
  if(is_page()){
    global $wp_query;
    $post_id = $wp_query->get_queried_object_id();
    $show = isset($instance["page-{$post_id}"]) ? ($instance["page-{$post_id}"]) : true;
  }


  // check user roles
  if(is_user_logged_in()){

    foreach($instance as $key => $enabled)
      // we're checking for all keys starting with "role-" and disable the widget only if the current user role matches a disabled role from $instance
      if((strpos($key, 'role-') === 0) && !$enabled) $restricted_roles[] = substr($key, 5);

    $has_not_role = true;
    foreach($restricted_roles as $role)
      if(in_array($role, $current_user->roles) && $has_not_role) $show = $has_not_role = false;

  }else{
    $show = (isset($instance['user-visitor']) && !$instance['user-visitor']) ? false : $show;
  }

  return $show ? $instance : false;
}



/**
 * Same as the above, but will perform a strict check,
 * meaning that it will only return true if the current page/taxonomy/post_type/role is present within the $instance array (and has a true value)
 *
 * @since 1.7
 *
 * @param array $instance Instance options
 * @return array|bool returns instance options if widget should be visible on the current page, false otherwise
 */
function atom_strict_visibility_check($instance){
  global $current_user;

  if(is_404() || !is_array($instance)) return false;

  // assume hidden
  $show = false;
  $allowed_post_types = $allowed_taxonomies = $allowed_roles = array();

  // generic pages
  if(is_home())
    $show = isset($instance['page-home']) && $instance['page-home'];
  elseif(is_author())
    $show = isset($instance['page-author']) && $instance['page-author'];
  elseif(is_date())
    $show = isset($instance['page-date']) && $instance['page-date'];
  elseif(is_search())
    $show = isset($instance['page-search']) && $instance['page-search'];
  elseif(is_category())
    $show = isset($instance['page-category']) && $instance['page-category'];
  elseif(is_tag())
    $show = isset($instance['page-tag']) && $instance['page-tag'];

  // check single post pages
  foreach($instance as $key => $enabled)
    if(strpos($key, 'page-singular-') === 0 && $enabled) $allowed_post_types[] = substr($key, 14);

  if(!empty($allowed_post_types))
    foreach($allowed_post_types as $post_type)
      if(is_singular($post_type)) $show = true;


  // check taxonomies
  foreach($instance as $key => $enabled)
    if(strpos($key, 'page-tax-') === 0 && $enabled) $allowed_taxonomies[] = substr($key, 9);

  if(!empty($allowed_taxonomies))
    foreach($allowed_taxonomies as $tax)
      if(is_tax($tax)) $show = true; // surprisingly category/tags are not considered taxonomies by is_tax(); hopefully this won't change in the future...


  // check pages
  if(is_page()){
    global $wp_query;
    $post_id = $wp_query->get_queried_object_id();
    $show = isset($instance["page-{$post_id}"]) && $instance["page-{$post_id}"];
  }


  // check user roles
  if(is_user_logged_in()){
    foreach($instance as $key => $enabled)
      // we're checking for all keys starting with "role-" and disable the widget only if the current user role matches a disabled role from $instance
      if((strpos($key, 'role-') === 0) && $enabled) $allowed_roles[] = substr($key, 5);

    $has_role = false;
    foreach($allowed_roles as $role)
      if(in_array($role, $current_user->roles) && $has_role){
        $has_role = true;
        $show = $show && $has_role;
      }

  }else{
    $show = isset($instance['user-visitor']) && $instance['user-visitor'] && $show;
  }

  return $show ? $instance : false;
}


/**
 * Check if jQuery is enabled and removes the "no-js" class from body
 * This function should be called just after <body> to avoid visual flickers
 *
 * @since 1.3
 */
function atom_check_js(){
  // "no js" means "no jquery" too so we leave the class if js is on, but jquery is disabled for some reason
  if(!Atom::app()->options('jquery')) return;
  echo "<script> document.body.className = document.body.className.replace('no-js',''); </script>";
}



/**
 * Load jQuery & related .js
 *
 * @since 1.3
 *
 * @todo load locales in order (eg. one of the js files from the Symposium plugin requires a locale loaded before it)
 */
function atom_print_scripts(){
  global $wp_scripts, $wp_filesystem;

  if(!is_a($wp_scripts, 'WP_Scripts') || !ATOM_CONCATENATE_JS || Atom::app()->previewMode() || ATOM_DEV_MODE) return;

  // remove admin-bar js if jquery is enabled
  //wp_dequeue_script('admin-bar');

  $scripts = $locales = array();
  $queue = $wp_scripts->queue;
  $wp_scripts->all_deps($queue);   // arrange the list of scripts based on dependencies

  foreach($wp_scripts->to_do as $key => $handle){

    if($wp_scripts->registered[$handle]->ver === null) $ver = '';
    else $ver = $wp_scripts->registered[$handle]->ver ? $wp_scripts->registered[$handle]->ver : $wp_scripts->default_version;

    if(isset($wp_scripts->args[$handle]))
      $ver = $ver ? $ver.'&amp;'. $wp_scripts->args[$handle] : $wp_scripts->args[$handle];

    $src = $wp_scripts->registered[$handle]->src;
    if($locale = $wp_scripts->print_scripts_l10n($handle, false)) $locales[] = $locale;
//    if($locale = $wp_scripts->print_scripts_l10n($handle, false)) continue;

    if(!preg_match('|^https?://|', $src) && ! ($wp_scripts->content_url && 0 === strpos($src, $wp_scripts->content_url)))
      $src = $wp_scripts->base_url.$src;

    if(!empty($ver))
      $src = add_query_arg('ver', $ver, $src);

    $src = esc_url_raw(apply_filters('script_loader_src', $src, $handle));

    $scripts[$handle] = $src;
//    unset($wp_scripts->to_do[$key]);
//    $wp_scripts->done[] = $handle;

  }

  if(empty($scripts)) return;

  if(($cache = get_transient('atom_js_cache')) === false) $cache = array();

  // wp-content/uploads
  $upload_dir = wp_upload_dir();

  $handles = implode(', ', array_keys($scripts));
  $cache_name = ATOM.'-'.md5($handles);
  $cache_file_path = "{$upload_dir['basedir']}/{$cache_name}.js";
  $cache_file_url = "{$upload_dir['baseurl']}/{$cache_name}.js";

  // calculate modified tag
  $hash = 0;
  foreach($scripts as $handle => $script){
    $parts = parse_url($script);
    $file_path = str_replace(site_url('/'), ABSPATH, $parts['scheme'].'://'.$parts['host'].$parts['path']);
    $hash += @filemtime($file_path);
  }

  // decide whether to build cache or not
  if(!isset($cache[$cache_name]) || ($cache[$cache_name] !== $hash) || !is_readable($cache_file_path)){

    require_once(ABSPATH.'wp-admin/includes/file.php');
    if(!WP_Filesystem())  // return and load them normally
      return Atom::app()->addDebugMessage("Failed to initialize WPFS for javascript caching. Your host's \"security settings\" prevent direct file writes...", 1);

    $script_urls = array_values($scripts);
    $url = 'http://closure-compiler.appspot.com/compile?code_url='.array_shift($script_urls);
    foreach($script_urls as $script_url)
      $url .= '&code_url='.urlencode($script_url);

    $compression_options = array(
      'body' => array(
        'compilation_level' => 'SIMPLE_OPTIMIZATIONS',
        'output_format'     => 'json',
        'output_info'       => 'compiled_code',
    ));

    $raw_response = wp_remote_post($url, $compression_options);

    if(!is_wp_error($raw_response) && ($raw_response['response']['code'] == 200))
      $response = json_decode($raw_response['body']);

    if(!empty($response->compiledCode) && empty($response->serverErrors) &&  empty($response->errors)){
      $compressed_js = $response->compiledCode;

      // save file
      if($wp_filesystem->is_writable($upload_dir['basedir']) && $wp_filesystem->put_contents($cache_file_path, "/*\nCache: {$handles}\n*/\n{$compressed_js}", FS_CHMOD_FILE)){
        $saved = true;
        $cache[$cache_name] = $hash;
        set_transient('atom_js_cache', $cache, 60*60*24*30); // 30 day cache
        Atom::app()->addDebugMessage("Javascript cache rebuilt ({$cache_file_url})");

      }else{ // return and load them normally
        return Atom::app()->addDebugMessage("Failed to create javascript cache ({$cache_file_url}). Try reloading again or disable the 'optimize' option to avoid slowdowns.", 1);
      }

    }else{ // return and load them normally
        return Atom::app()->addDebugMessage("Failed to create javascript cache: the Google Closure Compiler service returned error(s). Please disable the 'optimize' option to avoid slowdowns.", 1);
    }

  }

  foreach($scripts as $id => $url)
    foreach($wp_scripts->to_do as $key => $handle)
      if($id == $handle){
        unset($wp_scripts->to_do[$key]);
        $wp_scripts->done[] = $handle;
      }

  echo '<script src="'.$cache_file_url.'"></script>'."\n";

  if(!empty($locales)){
    echo "<script>\n";
    foreach($locales as $locale){
      echo "{$locale}\n";
    }
    echo "</script>\n";
  }


//  Atom::app()->addContextArgs('footer', array('js_cache' => $cache_file_url));
//  wp_enqueue_script(ATOM.'-js-cache', $cache_file_url, array(), false, true);

//  $wp_scripts->reset();
//  return $wp_scripts->done;
}



/**
 * Load stylesheets.
 * Will compress and concatenate them all into a single file, if "optimize" is checked.
 * Slightly based on "JS & CSS Script Optimizer" by evgenniy - http://4coder.info/en/
 *
 * @since 1.3
 *
 * @todo test rtl
 */
function atom_print_styles(){
  global $wp_styles, $wp_filesystem;
  if(!is_a($wp_styles, 'WP_Styles') || !Atom::app()->options('optimize') || Atom::app()->previewMode()) return;

  $styles = array();

  $queue = $wp_styles->queue;
  $wp_styles->all_deps($queue);
  $queue_unset = array();
  $home = site_url('/');
  foreach($wp_styles->to_do as $key => $handle){
    if($wp_styles->registered[$handle]->ver === null) $ver = '';
    else $ver = $wp_styles->registered[$handle]->ver ? $wp_styles->registered[$handle]->ver : $wp_styles->default_version;

    if(isset($wp_styles->args[$handle]))
      $ver = $ver ? $ver.'&amp;'.$wp_styles->args[$handle] : $wp_styles->args[$handle];

    if(isset($wp_styles->registered[$handle]->args)) $media = esc_attr($wp_styles->registered[$handle]->args); else $media = 'all';

    $href = $wp_styles->_css_href($wp_styles->registered[$handle]->src, $ver, $handle);

    // rtl?
    if('rtl' === $wp_styles->text_direction && isset($wp_styles->registered[$handle]->extra['rtl']) && $wp_styles->registered[$handle]->extra['rtl'])
      if(is_bool( $wp_styles->registered[$handle]->extra['rtl'])){
        $suffix = isset($wp_styles->registered[$handle]->extra['suffix']) ? $wp_styles->registered[$handle]->extra['suffix'] : '';
        $href = str_replace("{$suffix}.css", "-rtl{$suffix}.css", $wp_styles->_css_href($wp_styles->registered[$handle]->src , $ver, "$handle-rtl"));
      }else{
        $href = $wp_styles->_css_href($wp_styles->registered[$handle]->extra['rtl'], $ver, "$handle-rtl");
      }

    // ignore external styles
    $external = false;
    if((strpos($href, 'http', 0) !== false) && (strpos($href, $home, 0) === false)) $external = true;
    if($external) continue;

    $styles[$media][$handle] = $href;
  }

  if(($cache = get_transient('atom_css_cache')) === false) $cache = array();

  // wp-content/uploads
  $upload_dir = wp_upload_dir();

  foreach($styles as $media => $items){
    $handles = array_keys($items);
    $handles = implode(', ', $handles);
    $cache_name = ATOM.'-'.md5($handles);
    $cache_file_path = "{$upload_dir['basedir']}/{$cache_name}.css";
    $cache_file_url = "{$upload_dir['baseurl']}/{$cache_name}.css";

    // calculate modified tag
    $hash = 0;
    foreach($items as $handle => $style){
      $parts = parse_url($style);
      $file_path = str_replace(site_url('/'), ABSPATH, $parts['scheme'].'://'.$parts['host'].$parts['path']);
      $hash += @filemtime($file_path);
    }

    if(!isset($cache[$media][$cache_name]) || ($cache[$media][$cache_name] !== $hash) || !is_readable($cache_file_path)){ // build cache

      require_once(ABSPATH.'wp-admin/includes/file.php');
      if(!WP_Filesystem())  // return and load them normally
        return Atom::app()->addDebugMessage("Failed to initialize WPFS for stylesheet caching. Your host's \"security settings\" prevent direct file writes...", 1);

      $css = '';
      foreach($items as $handle => $style){
        $css .= "/* $handle: ($style) */\n";
        $content = $wp_filesystem->get_contents($style);

        // compress CSS (remove spaces & comments)
        $content = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $content);
        $content = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), '', $content);
        $dir = dirname($style).'/'; // url()
        $content = preg_replace('|url\(\'?"?([a-zA-Z0-9\-_\s\./]*)\'?"?\)|', "url(\"$dir$1\")", $content);

        $css .= "{$content}\n";
      }

      // save file
      if($wp_filesystem->is_writable($upload_dir['basedir']) && $wp_filesystem->put_contents($cache_file_path, "/*\nCache: {$handles}\n*/\n{$css}", FS_CHMOD_FILE)){
        $saved = true;
        $cache[$media][$cache_name] = $hash;
        set_transient('atom_css_cache', $cache, 60*60*24*7); // 1 week cache
        Atom::app()->addDebugMessage("Stylesheet cache rebuilt ({$cache_file_url}), media: {$media}");

      }else{ // return and load them normally
        return Atom::app()->addDebugMessage("Failed to create stylesheet cache ({$cache_file_url}), media: {$media}", 1);
      }

    }

    echo "\n<link rel=\"stylesheet\" href=\"{$cache_file_url}\" type=\"text/css\" media=\"{$media}\" />\n";
  }

  foreach($wp_styles->to_do as $key => $handle){
    unset($wp_styles->to_do[$key]);
    $wp_styles->done[] = $handle;
  }
  
}



/**
 * Inline styles (layout dimensions, custom bg image etc.)
 *
 * @since 1.3
 */
function atom_inline_css(){

  $app = &Atom::app();

  // get the theme settings
  $s = $app->options();

  $css = array();

  if($app->isOptionEnabled('layout')){
    $layout = $app->getLayoutType();

    // column dimensions
    $w = $s['page_width'];
    $unit = ($w !== 'fluid') ? 'px' : '%';
    $gs = ($w !== 'fluid') ? 960: 100;

    if($layout !== 'c1'){
      $sb = explode(';', $s["dimensions_{$w}_{$layout}"]);
      switch($layout){
        case 'c2left':
          $css[] = '.'.$w.'.c2left #primary-content{width:'.($gs-$sb[0]).$unit.';left:'.$gs.$unit.'}';
          $css[] = '.'.$w.'.c2left #sidebar{width:'.$sb[0].$unit.';left:0}';
          $css[] = '.'.$w.'.c2left #mask-1{right:'.($gs-$sb[0]).$unit.'}';
          break;
        case 'c2right':
          $css[] = '.'.$w.'.c2right #primary-content{width:'.($gs-($gs-$sb[0])).$unit.';left:'.($gs-$sb[0]).$unit.'}';
          $css[] = '.'.$w.'.c2right #sidebar{width:'.($gs-$sb[0]).$unit.';left:'.($gs-$sb[0]).$unit.'}';
          $css[] = '.'.$w.'.c2right #mask-1{right:'.($gs-$sb[0]).$unit.'}';
          break;
        case 'c3':
          $css[] = '.'.$w.'.c3 #primary-content{width:'.($gs-$sb[0]-($gs-$sb[1])).$unit.';left:'.$gs.$unit.'}';
          $css[] = '.'.$w.'.c3 #sidebar{width:'.$sb[0].$unit.';left:'.($gs-$sb[1]).$unit.'}';
          $css[] = '.'.$w.'.c3 #sidebar2{width:'.($gs-$sb[1]).$unit.';left:'.($gs-$sb[0]).$unit.'}';
          $css[] = '.'.$w.'.c3 #mask-2{right:'.($gs-$sb[1]).$unit.'}';
          $css[] = '.'.$w.'.c3 #mask-1{right:'.($gs-$sb[0]-($gs-$sb[1])).$unit.'}';
          break;
        case 'c3left':
          $css[] = '.'.$w.'.c3left #primary-content{width:'.($gs-$sb[1]).$unit.';left:'.($gs+($sb[1]-$sb[0])).$unit.'}';
          $css[] = '.'.$w.'.c3left #sidebar{width:'.$sb[0].$unit.';left:'.($sb[1]-$sb[0]).$unit.'}';
          $css[] = '.'.$w.'.c3left #sidebar2{width:'.($sb[1]-$sb[0]).$unit.';left:'.($sb[1]-$sb[0]).$unit.'}';
          $css[] = '.'.$w.'.c3left #mask-2{right:'.($gs-$sb[1]).$unit.'}';
          $css[] = '.'.$w.'.c3left #mask-1{right:'.($sb[1]-$sb[0]).$unit.'}';
          break;
        case 'c3right':
          $css[] = '.'.$w.'.c3right #primary-content{width:'.$sb[0].$unit.';left:'.(($gs-$sb[0]-($gs-$sb[1]))+($gs-$sb[1])).$unit.'}';
          $css[] = '.'.$w.'.c3right #sidebar{width:'.($gs-$sb[0]-($gs-$sb[1])).$unit.';left:'.($gs-$sb[0]).$unit.'}';
          $css[] = '.'.$w.'.c3right #sidebar2{width:'.($gs-$sb[1]).$unit.';left:'.($gs-$sb[0]).$unit.'}';
          $css[] = '.'.$w.'.c3right #mask-2{right:'.($gs-$sb[1]).$unit.'}';
          $css[] = '.'.$w.'.c3right #mask-1{right:'.($sb[1]-$sb[0]).$unit.'}';
          break;
      }
    }
    // page width
    if(($w !== 'fixed'))
      $css[] = ".page-content{max-width:{$s['page_width_max']}px;}\n";

  }

  // background image
  if($app->isOptionEnabled('background_image') && $s['background_image'])
    $css[] = $s['background_image_selector'].'{background-image:url("'.$s['background_image'].'");}';

  // background color
  if($app->isOptionEnabled('background_color') && ($s['background_color']) && ($s['background_color'] != '000000')){
    $css[] = $s['background_color_selector'].'{background-color:#'.$s['background_color'].';}';

    if(empty($s['background_image']))
      $css[] = $s['background_image_selector'].'{background-image:none;}';
  }

  // extra css may be added by plugins etc.
  $css = apply_filters('atom_inline_css', implode("\n", $css));

  // user css (use template system)
  if($s['css']) $css .= $app->getBlockTemplate($s['css'], array(
    'THEME_URL'       => $app->get('theme_url'),
    'CHILD_THEME_URL' => $app->get('child_theme_url'),
    'BLOG_URL'        => home_url(),
  ));

  // search for CSS custom field
  if(is_single() || is_page()){
    $meta_css = $app->post->getMeta('css', true);
    if(!empty($meta_css)) $css .= $app->getBlockTemplate($s['css'], array(
      'THEME_URL'       => $app->get('theme_url'),
      'CHILD_THEME_URL' => $app->get('child_theme_url'),
      'BLOG_URL'        => home_url(),
    ));
  }

  $css = trim($css);

  if(!empty($css))
    echo "<style>\n{$css}\n</style>\n";
}




/**
 * Register javascript files used by ATOM
 *
 * @since 1.3
 */
function atom_enqueue_scripts(){
  // enqueue jquery & related scripts
  if(is_admin()) return;

  Atom::action('js');

  if(Atom::app()->options('jquery')){

    // load google's jquery, should be faster theoretically
    if(!ATOM_DEV_MODE && Atom::app()->options('optimize')){
      wp_deregister_script('jquery');
      wp_register_script('jquery', ('http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js'));
    }

    // jquery
    wp_enqueue_script('jquery');

    // jquery plugins
    wp_enqueue_script(ATOM, Atom::app()->jsURL('jquery.atom'), array('jquery'), Atom::app()->get('theme_version'), true);

    // post-message
    if(Atom::app()->previewMode())
      wp_enqueue_script('post-message', Atom::app()->jsURL('pm'), array('jquery'), Atom::app()->get('theme_version'), true);

  }
}




/**
 * Register CSS files used by ATOM
 *
 * @since 1.3
 */
function atom_enqueue_styles(){
  if(is_admin()) return;

  Atom::action('css');

  //@todo
  //wp_dequeue_style('admin-bar');

  if(!is_child_theme() && !Atom::app()->isOptionEnabled('color_scheme'))
    wp_enqueue_style(ATOM.'-core', Atom::app()->get('theme_url').'/css/core.css', array(), Atom::app()->get('theme_version'));

  if(Atom::app()->isOptionEnabled('color_scheme')){
    // color/design scheme (add custom field for testing)
    if(is_single() || is_page()) $style = get_post_meta($GLOBALS['post']->ID, 'style', true);

    // if no c.f. use the theem setting
    if(empty($style)) $style = Atom::app()->options('color_scheme');

    if(!empty($style)){
      wp_enqueue_style(ATOM.'-core', Atom::app()->get('theme_url').'/css/core.css', array(), Atom::app()->get('theme_version'));
      wp_enqueue_style(ATOM.'-style', Atom::app()->get('theme_url').'/css/style-'.$style.'.css', array(ATOM.'-core'), Atom::app()->get('theme_version'));
    }

  if(is_child_theme())
    wp_enqueue_style(ATOM, get_stylesheet_uri(), array(), Atom::app()->get('theme_version'));
    
  }

  //if(USE_THEMED_ADMIN_BAR){ // remove default admin-bar styles, the theme will handle these
  //  wp_dequeue_style('admin-bar');
  //  remove_action('wp_head', 'wp_admin_bar_header');
  //  remove_action('wp_head', '_admin_bar_bump_cb');
  //}

  /*/ print styles -- removed
  wp_enqueue_style(ATOM."-print", Atom::app()->get('theme_url').'/css/print.css', array(ATOM), Atom::app()->get('theme_version'), 'print');
  //*/
}



/**
 * Set up post thumbnail sizes (must run before the ajax)
 *
 * @since 1.0
 */
function atom_set_thumb_sizes(){

  if(!Atom::app()->options('post_thumbs')) return;
  $post_thumb = (Atom::app()->options('post_thumb_size') === 'media') ? array(get_option('thumbnail_size_w'), get_option('thumbnail_size_h')) : explode('x', Atom::app()->options('post_thumb_size'));

  list($w, $h) = $post_thumb;

  set_post_thumbnail_size($w, $h, true); // same as add_image_size('post-thumbnail' ...);

  //if(Atom::app()->options('featured_post_thumb_size')){
  //  list($w, $h) = explode('x', Atom::app()->options('featured_post_thumb_size'));
  //  add_image_size('featured-thumbnail', $w, $h, true);
  //}

  Atom::action('thumb_sizes');
}




/**
 * Removes expired transients from the database
 * http://wordpress.stackexchange.com/questions/6602/are-transients-garbage-collected
 * This should be integrated in the WP core...
 *
 * @since `1.3
 */
function atom_delete_expired_transients(){
  global $wpdb;
  if($GLOBALS['_wp_using_ext_object_cache']) return;

  $time = isset($_SERVER['REQUEST_TIME']) ? (int)$_SERVER['REQUEST_TIME'] : time();
  $expired = $wpdb->get_col("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout%' AND option_value < {$time};");

  foreach($expired as $transient)
    delete_transient(str_replace('_transient_timeout_', '', $transient));

  Atom::app()->addDebugMessage('Deleted '.count($expired).' expired transients.'); // probably never shown because this runs in a separate request
}



/**
 * GET requests
 *
 * @since 1.0
 */
function atom_requests(){
  $app = Atom::app();

  if(is_single()) $app->post->incrementViews();

  // ajax requests
  require('requests.php');

  // print preview
  // @todo: move this inside a template file
  if(isset($_GET['print'])): ?>
   <html>
   <head>
   <style>
     @import "<?php echo $app->get('theme_url'); ?>/css/print.css";
   </style>

   </head>
   <body onload='window.print()'>

    <?php $app->action("before_print"); ?>
    <?php $app->logo(); ?>

    <?php while(have_posts()): ?>
      <?php the_post(); ?>

      <!-- post -->
      <div class="post hentry">

        <?php if(!get_post_meta(get_the_ID(), 'hide_title', true)): ?>
        <h1 class="title"><?php the_title(); ?></h1>
        <?php endif; ?>

        <div class="clear-block">
         <?php the_content(); ?>
        </div>

      </div>
      <!-- /post -->

      <?php if($app->post->getTerms('post_tag')): ?>
      <div class="post-extra clear-block">
        <div class="post-tags">
          <?php printf(_a("Tags: %s"), $app->post->getTerms('post_tag', ',')); ?>
        </div>
      </div>
      <?php endif; ?>

    <?php endwhile; ?>

   <?php $app->action("after_print"); ?>
   </body>
   </html> <?php
   die();
  endif;

  Atom::action("requests");
}



/**
 * wp_footer hook
 *
 * @since 1.0
 */
function atom_footer(){
  // expose $app;
  $app = &Atom::app();

  if($app->options('jquery')){
    echo "<script>\n";
    require(TEMPLATEPATH.'/js/jquery.init.php');
    echo "</script>\n";
  }

  // debug info?
  if($app->options('debug') && current_user_can('edit_theme_options') && !Atom::previewMode()){

    if(1 === 0 && !ATOM_DEV_MODE){  // disabled for now... until the html5 validator is not more experimental :)
      // html validation
      $url = 'http://validator.w3.org/check?uri='.urlencode($app->getCurrentPageURL());
      $response = wp_remote_retrieve_body(wp_remote_request("{$url}&output=soap12"));

      foreach(explode("\n", $response) as $line)
        // we could use simplexml for more accuracy here -- @todo ?
        if((strpos($line, "m:errorcount") !== false) && ($errors = (int)trim(strip_tags($line))))
          $app->addDebugMessage('Found '.$errors.' markup error(s) in the current page. Please <a href="'.$url.'" target="_blank">validate</a> your HTML, otherwise this page might not display properly.', 1);
    }

    // page load & db requests info
    $app->addDebugMessage(do_shortcode('[load]'));

    if(is_wp_error($app->get('debug_messages'))){
      ?>
      <style>
        #debug{font:12px "Courier New", Courier, "Lucida Console", Monaco, "DejaVu Sans Mono", "Nimbus Mono L", "Bitstream Vera Sans Mono", monospace;color:#fff;}
        #debug p{padding:3px 10px;margin:0;color: #fff;}
        #debug p.warning{background: #cf5454;}
        #debug p.warning.even{background: #cd4a4a;}
        #debug p.notice{background: #09649b;}
        #debug p.notice.even{background: #005f98;}
        #debug a{color:#fff;text-decoration:underline;}
        #page #debug{display:none;} /* to avoid flicker before messages are appended to the <body> */
      </style>
      <div id="debug">
         <?php foreach($app->get('debug_messages')->get_error_messages(1) as $key => $message): ?>
         <p class="warning <?php if($key %2) echo 'even'; ?>"><?php echo $message; ?></p>
         <?php endforeach; ?>
         <?php foreach($app->get('debug_messages')->get_error_messages(2) as $key => $message): ?>
         <p class="notice <?php if($key %2) echo 'even'; ?>"><?php echo $message; ?></p>
         <?php endforeach; ?>
      </div>
      <script>
        /* <![CDATA[ */
        document.body.insertBefore(document.getElementById('debug'), document.body.firstChild);
        /* ]]> */
      </script>
      <?php
    }
  }
}


/**
 * Displays a error message telling the user that he needs to upgrade his Worpdress installation
 *
 * @since 1.0
 */
function atom_unsupported_wp_version(){

  // message for all users when inside dashboard, and only for blog admin if outside
  if(current_user_can('edit_theme_options') || is_admin()){
    $message = sprintf(_a('Your site is running on %1$s. %2$s requires at least %3$s. Please update your site even if you\'re not going to use this theme, because outdated applications expose you to security risks'),
       'WordPress '.$GLOBALS['wp_version'],
       '<strong>'.Atom::app()->get('theme_name').'</strong>',
       '<a href="http://codex.wordpress.org/Upgrading_WordPress/">WordPress '.ATOM_REQ_WP_VERSION.'</a>'
    );

  // message for normal visitors
  }else{
    $message = sprintf(_a('The site is temporarily down for maintainance. Come back in a few minutes, or login in <a%s>here</a> if you\'re de site admin'), ' href="'.get_admin_url().'"');
  }

  // extra message for logged in blog admins, if outside the dashboard
  if(current_user_can('edit_theme_options') && !is_admin())
    $message .= ' '.sprintf(_a('Go to your %s'), '<a href="'.get_admin_url().'">'._a('Dashboard').'</a>');

  // not in the admin area, show message and stop script
  if(!is_admin())
    wp_die($message);

  // in the admin area, display the message as a notice
  echo '<div class="error"><p>'.$message.'</p></div>';
}



/**
 * Add the theme settings page to the WP admin bar appearance menu
 *
 * @since 1.2
 */
function atom_wp_admin_bar_menu(){
  if(!current_user_can('edit_theme_options') || !is_admin_bar_showing()) return;

  global $wp_admin_bar;

  $wp_admin_bar->add_menu(array(
    'parent'   => 'appearance',
    'id'       => 'atom-settings',
    'title'    => sprintf(_a('%s settings'), Atom::app()->get('theme_name')),
    'href'     => admin_url('themes.php?page='.ATOM),
  ));
}


/*** UNUSED HOOKS (@TODOS) ***/



/**
* Renders the admin bar
* Replaces WP_Admin_Bar::render() and wp_admin_bar_render() (add some extra markup)
*
* @since 1.4
*/
function atom_admin_bar(){
  global $wp_admin_bar;
  if(!is_admin_bar_showing() || ! is_object($wp_admin_bar)) return false;

  $wp_admin_bar->load_user_locale_translations();
  do_action_ref_array('admin_bar_menu', array(&$wp_admin_bar));
  do_action('wp_before_admin_bar_render');
  ?>
  <div id="wpadminbar" class="nav clear-block">
    <ul class="quicklinks menu">
      <?php foreach((array)$wp_admin_bar->menu as $id => $menu_item) $wp_admin_bar->recursive_render($id, $menu_item); ?>
    </ul>

    <form action="<?php echo home_url(); ?>" method="get">
      <input type="text" id="adminbar-search" maxlength="150" name="s" data-default="<?php _ae("Search Website"); ?>" class="adminbar-input text alignleft clearField suggestTerms" value="" />
    </form>
  </div>

  <?php
  $wp_admin_bar->menu = null;
  do_action('wp_after_admin_bar_render');
  $wp_admin_bar->unload_user_locale_translations();
}


