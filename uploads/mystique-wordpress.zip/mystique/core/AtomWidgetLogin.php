<?php

/**
 * Atom Login widget
 *
 * Displays the login form and lost pw/ register links.
 * If jquery/javascript is enabled it will attempt to authenticate trough ajax
 *
 * @since 1.0
 * @todo use a login/register form template file
 * @todo add lost pass / register forms...
 */
 

 
class AtomWidgetLogin extends AtomWidget{

  public function AtomWidgetLogin(){

    $this->WP_Widget('atom-login', _a("Login"), array('classname' => 'login', 'description' => _a("Login and Lost Password forms")), array('width' => 500));

    // default settings
    $this->setDefaults(array(
      'title'      => _a('Log in'),
      'text'       => _a("Hello Guest. Login below if you have an account"),
      'dashboard'  => 1,
      'profile'    => 1,
      'write'      => 1,
      'comments'   => 0,
    ));

    Atom::add('requests',    array(&$this, 'login'));

    // include in jQuery(document).ready()
    Atom::add('jquery_init', array(&$this, 'js'));
  }

  public function login(){
    if(Atom::app()->request('login')):

      $creds = array(
        'user_login'     => isset($_POST['user']) ? esc_attr(strip_tags($_POST['user'])) : false,
        'user_password'  => isset($_POST['pass']) ? esc_attr(strip_tags($_POST['pass'])) : false,
        'remember'       => isset($_POST['remember']) ? true : false,
      );

      $instance = isset($_POST['instance']) ? esc_attr(strip_tags($_POST['instance'])) : false;

      $user = wp_signon($creds, false);
      $error = false;
      if(is_wp_error($user))
        if($user->get_error_message()) $error = $user->get_error_message(); else $error = _a("Please enter a valid user name and password");

      if(isset($_POST['ajax'])):
        echo json_encode(array('error' => $error));
        die();
      elseif($error):
        define("{$instance}_ERROR", $error);
      else:
        wp_redirect(esc_url($_POST['redirect_to']));
      endif;

    endif;
  }

  public function js(){
    // we need to process all instances because this function gets to run only once
    $widget_settings = get_option($this->option_name);

    foreach((array)$widget_settings as $instance => $options):

      // identify instance
      $id = "{$this->id_base}-{$instance}";
      $block_id = "instance-{$id}";

      if(is_active_widget(false, $id, $this->id_base)): ?>

      $('#<?php echo $id; ?>_login').submit(function(event){
        event.preventDefault();

        var form = $('#<?php echo $id; ?>_login'),
            url = form.attr('action'),
            status = $("#<?php echo $block_id; ?> .status");

        $.ajax({
          type: 'POST',
          url: url,
          data:{ _ajax_nonce: "<?php Atom::app()->nonce('login'); ?>",
                  atom: 'login',
                  ajax: true,
                  user: form.find('input[name="user"]').val(),
                  pass: form.find('input[name="pass"]').val(),
                  remember: form.find('input[name="remember"]').val()
          },
          dataType: 'json',
          context: this,
          beforeSend: function(){
            status.removeClass("error").addClass("loading").text("<?php _ae("Checking..."); ?>");
          },

          success: function(response){

            if(!response.error){
              status.removeClass("loading error").addClass("success").html('<?php _ae("Login Successful, redirecting..."); ?>');
              window.location.reload();

            }else{
              status.removeClass("loading").addClass("error").html(response.error);
            };
          }

        });
      });
      <?php endif;
    endforeach;
  }

  public function widget($args, $instance){
    extract($args);
    $instance = wp_parse_args($instance, $this->getDefaults());
    $title = apply_filters('widget_title', $instance['title'], $instance, $this->id_base);

    // retrieve info about the current user
    global $current_user, $user_level;
    get_currentuserinfo();

    if(is_user_logged_in()) $title = sprintf(_a('Welcome %s'), $current_user->display_name);
    echo $before_widget.($title ? $before_title.$title.$after_title : null);

    echo '<div class="box fadethis login-block clear-block">';

    // the user is logged in, display the menu links
    if(is_user_logged_in()):
      echo '<div class="avatar">'.Atom::app()->getAvatar($current_user->user_email, 96, '', $current_user->display_name).'</div>';
      echo '<ul class="menu fadeThis">';

      if($instance['dashboard']) echo '<li class="first"><a class="dashboard" href="'.admin_url().'">'._a('Dashboard').'</a></li>';

      if($user_level >= 1): // need permissions
        if($instance['write'])  echo '<li><a class="write" href="'.admin_url('post-new.php').'">'._a('Write').'</a></li>';
        if($instance['comments']) echo '<li><a class="edit-comments" href="'.admin_url('edit-comments.php').'">'._a('Comments').'</a></li>';
      endif;

      if($instance['profile']) echo '<li><a class="profile" href="'.admin_url('profile.php').'">'._a('Profile').'</a></li>';
      echo '<li><a class="log-out last" id="wp-logout" href="'.wp_logout_url(Atom::app()->getCurrentPageURL()).'">'._a('Log Out').'</a></li>';
      echo '</ul>';

    // the user is not logged in, display the login form
    else: ?>

      <?php if(defined("{$this->id}_ERROR")): ?>
      <div class="status error clear-block"><?php echo constant("{$this->id}_ERROR"); ?></div>
      <?php else: ?>
      <div class="status clear-block"><?php echo $instance['text']; ?></div>
      <?php endif; ?>

      <form id="<?php echo $this->id; ?>_login" action="<?php echo Atom::app()->currentPageURL(); ?>" method="post">

        <div>
          <input type="text" data-default="<?php echo _a("User"); ?>" name="user" id="<?php echo $this->id; ?>_user" class="text clearField" value="" />
          <input type="password" data-default="<?php echo _a("Password"); ?>" name="pass" id="<?php echo $this->id; ?>_pass" class="text clearField" value="" />
        </div>

        <div class="clear-block">
          <input type="submit" name="wp-submit" class="alignleft" value="<?php _ae('Log In'); ?>" tabindex="100" />

          <input type="hidden" name="redirect_to" value="<?php echo Atom::app()->currentPageURL(); ?>" />
          <input type="hidden" name="atom" value="login" />
          <input type="hidden" name="instance" value="<?php echo $this->id; ?>" />

          <label for="<?php echo $this->id; ?>_login_remember" class="remember alignleft">
            <input name="remember" type="checkbox" id="<?php echo $this->id; ?>_login_remember" value="forever" />
            <?php _ae('Remember me'); ?>
          </label>
        </div>
      </form>

      <p class="meta">
        <a class="forgot_pass" href="<?php echo site_url('wp-login.php?action=lostpassword', 'login'); ?>"><?php _ae('Lost your password?'); ?></a>

      <?php
       if(get_option('users_can_register')):

        // internal page, highest priority
        $register_url = Atom::app()->getPageURL('sign-up', true);

        // budypress
        if(!$register_url && function_exists('bp_get_signup_page'))
          $register_url = bp_get_signup_page();

        // mu + wp3
        elseif(!$register_url && file_exists(ABSPATH."/wp-signup.php"))
          $register_url = site_url('wp-signup.php', 'login');

        // old wp? normally we shouldn't get here
        elseif(!$register_url)
          $register_url = site_url('wp-login.php?action=register', 'login');
        ?>
        <br />
        <a class="register" href="<?php echo $register_url; ?>"><?php _ae('Register'); ?></a>
      <?php endif; ?>
      </p>
      <?php
   endif;

   	echo '</div>';
	echo $after_widget;
  }

  public function update($new_instance, $old_instance){
    $instance['title']     = esc_attr($new_instance['title']);
    $instance['text']      = current_user_can('unfiltered_html') ? $new_instance['text'] : stripslashes(wp_filter_post_kses(addslashes($new_instance['text'])));
    $instance['dashboard'] = isset($new_instance['dashboard']);
    $instance['profile']   = isset($new_instance['profile']);
    $instance['write']     = isset($new_instance['write']);
    $instance['comments']  = isset($new_instance['comments']);
    return $instance;
  }

  public function form($instance){
    $instance = wp_parse_args($instance, $this->getDefaults());
    ?>
    <div <?php $this->formClass(); ?>>
      <p>
        <label for="<?php echo $this->get_field_id('title'); ?>"><?php _ae('Title:'); ?>
        <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php if (isset($instance['title'])) echo esc_attr($instance['title']); ?>" /></label>
      </p>

      <p>
        <label for="<?php echo $this->get_field_id('text'); ?>"><?php _ae('Initial Status Text (or HTML):'); ?>
        <textarea class="widefat code" id="<?php echo $this->get_field_id('text'); ?>" name="<?php echo $this->get_field_name('text'); ?>" rows="6" cols="28" mode="atom/html"><?php if (isset($instance['text'])) echo format_to_edit($instance['text']); ?></textarea>
        </label>
      </p>
      <hr />
      <p><strong><?php _ae("Welcome screen links (if enough permissions):"); ?></strong></p>
      <p>
       <label for="<?php echo $this->get_field_id('dashboard'); ?>">
         <input id="<?php echo $this->get_field_id('dashboard'); ?>" name="<?php echo $this->get_field_name('dashboard'); ?>" type="checkbox" value="1" <?php checked(isset($instance['dashboard']) ? $instance['dashboard'] : 0); ?> />
         <?php _ae('Dashboard'); ?>
       </label>
       <br />

       <label for="<?php echo $this->get_field_id('profile'); ?>">
         <input id="<?php echo $this->get_field_id('profile'); ?>" name="<?php echo $this->get_field_name('profile'); ?>" type="checkbox" value="1" <?php checked(isset($instance['profile']) ? $instance['profile'] : 0); ?> />
         <?php _ae('Profile'); ?>
       </label>
       <br />

       <label for="<?php echo $this->get_field_id('write'); ?>">
         <input id="<?php echo $this->get_field_id('write'); ?>" name="<?php echo $this->get_field_name('write'); ?>" type="checkbox" value="1" <?php checked(isset($instance['write']) ? $instance['write'] : 0); ?> />
         <?php _ae('Write'); ?>
       </label>
       <br />

       <label for="<?php echo $this->get_field_id('comments'); ?>">
         <input id="<?php echo $this->get_field_id('comments'); ?>" name="<?php echo $this->get_field_name('comments'); ?>" type="checkbox" value="1" <?php checked(isset($instance['comments']) ? $instance['comments'] : 0); ?> />
         <?php _ae('Comments'); ?>
       </label>
       <br />

       <label>
         <input disabled="disabled" type="checkbox" value="1" checked="checked" />
         <?php _ae('Log out'); ?>
       </label>
      </p>
    </div>
    <?php
  }
}