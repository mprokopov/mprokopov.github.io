<?php

/**
 * Atom Menu Widget
 *
 * Displays a custom menu as a expandable/collapsible (or collapsed) menu
 *
 * @since 1.2
 */
 

 
class AtomWidgetMenu extends AtomWidget{

  public function AtomWidgetMenu(){

    $this->WP_Widget('atom-menu', _a('Menus'), array('classname' => 'menu', 'description' => _a('Display a custom menu')));

    // default settings
    $this->setDefaults(array(
      'title'     => '',
      'nav_menu'  => '',
      'behaviour' => 'collapsible',
      'event'     => 'click',
    ));
  }

  public function widget($args, $instance){
    extract($args);

    $instance = wp_parse_args($instance);

    // Get menu
    $nav_menu = wp_get_nav_menu_object($instance['nav_menu']);
    if(!$nav_menu) return
      Atom::app()->addDebugMessage("No menu selected in {$args['widget_id']} ({$args['widget_name']}). Widget marked as inactive");

    $title = apply_filters('widget_title', $instance['title'], $instance, $this->id_base);
    echo $before_widget;

    if(!empty($instance['title']))
      echo $before_title.$title.$after_title;

    wp_nav_menu(array(
      'menu'            => $nav_menu,
//      'container_class' => 'menu',
      'after'           => ($instance['behaviour'] !== 'expanded') ? "<span class=\"expand\"></span>" : '',
      'menu_class'      => "menu fadeThis {$instance['behaviour']} event-{$instance['event']}",
      'fallback_cb'     => '',
    ));

    echo $after_widget;
  }

  public function update($new_instance, $old_instance){
    $instance['title']     = esc_attr($new_instance['title']);
    $instance['nav_menu']  = (int)$new_instance['nav_menu'];
    $instance['behaviour'] = esc_attr($new_instance['behaviour']);
    $instance['event']     = esc_attr($new_instance['event']);
    return $instance;
  }

  public function form($instance){
    // defaults
    $instance = wp_parse_args($instance, $this->getDefaults());

    // get menus
    $menus = get_terms('nav_menu', array('hide_empty' => false));

    // if no menus exist, direct the user to go and create some
    if(!$menus): ?>
      <p><?php _ae('No menus have been created yet.'); ?> <a href="<?php echo admin_url('nav-menus.php'); ?>"><?php _ae('Create some'); ?></a></p>
      <?php
      return;
    endif;
    ?>
    <div <?php $this->formClass(); ?>>
      <p>
        <label for="<?php echo $this->get_field_id('title'); ?>"><?php _ae('Title:') ?></label>
        <input type="text" class="wide" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $instance['title']; ?>" />
      </p>
      <p>
        <label for="<?php echo $this->get_field_id('nav_menu'); ?>"><?php _ae('Select Menu:'); ?></label><br />
        <select class="wide" id="<?php echo $this->get_field_id('nav_menu'); ?>" name="<?php echo $this->get_field_name('nav_menu'); ?>">
        <?php
         foreach($menus as $menu):
           $selected = ($instance['nav_menu'] == $menu->term_id) ? ' selected="selected"' : '';
           echo "<option{$selected} value=\"{$menu->term_id}\">{$menu->name}</option>\n";
         endforeach;
        ?>
        </select>
      </p>

      <p>
        <label for="<?php echo $this->get_field_id('behaviour'); ?>" <?php if(!Atom::app()->options('jquery')) echo "class=\"disabled\""; ?>><?php _ae('Behaviour:'); ?></label><br />
        <select class="wide" <?php if(!Atom::app()->options('jquery')) echo "disabled=\"disabled\""; ?> id="<?php echo $this->get_field_id('behaviour'); ?>" name="<?php echo $this->get_field_name('behaviour'); ?>">
          <option value="expanded" <?php selected($instance['behaviour'], 'expanded'); ?>><?php _ae('Expanded'); ?></option>
          <option value="collapsible" <?php selected($instance['behaviour'], 'collapsible'); ?>><?php _ae('Collapsible, Standard'); ?></option>
          <option value="accordion" <?php selected($instance['behaviour'], 'accordion'); ?>><?php _ae('Collapsible, Accordion style'); ?> (BETA)</option>
        </select>
      </p>

      <p>
        <label for="<?php echo $this->get_field_id('event'); ?>" <?php if(!Atom::app()->options('jquery')) echo "class=\"disabled\""; ?>><?php _ae('Expand/Collapse Fire Event:'); ?></label><br />
        <select class="wide" <?php if(!Atom::app()->options('jquery')) echo "disabled=\"disabled\""; ?> id="<?php echo $this->get_field_id('event'); ?>" name="<?php echo $this->get_field_name('event'); ?>">
          <option value="click" <?php selected($instance['event'], 'click'); ?>><?php _ae('Click'); ?></option>
          <option value="dblclick" <?php selected($instance['event'], 'dblclick'); ?>><?php _ae('Double-Click'); ?></option>
          <option value="mouseover" <?php selected($instance['event'], 'mouseover'); ?>><?php _ae('Mouse Over'); ?></option>
        </select>
      </p>
      <p><em><?php printf(_a("Note: Links with the %s URL will behave the same way as the arrows. You should use them on menus with children"), '<code>#</code>'); ?></em></p>
    </div>
    <?php
  }
}