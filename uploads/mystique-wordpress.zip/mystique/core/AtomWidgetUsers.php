<?php

/**
 * Atom Users Widget
 *
 * A list of Users (or Authors, depending on role selection)
 *
 * @since 1.0
 * @todo add user feed link option
 */


class AtomWidgetUsers extends AtomWidget{
  public function AtomWidgetUsers() {

    $this->WP_Widget('atom-users', _a('Users'), array('classname' => 'users', 'description' => _a('A list of users/authors from your blog')), array('width' => 500));

    // set up default templates
    $this->registerTemplates(array(
      'full'     =>  "<a class=\"clear-block\" href=\"{URL}\" title=\"{NAME}\">\n"
                    ." {AVATAR}\n"
                    ." <span class=\"base\">\n"
                    ."   <span class=\"tt\">{NAME}</span>\n"
                    ."   <span class=\"c1\">{POST_COUNT}</span>\n"
                    ." </span>\n"
                    ."</a>",

      'images'   =>  "<a class=\"clear-block tt\" href=\"{URL}\" title=\"{NAME} ({POST_COUNT})\">\n"
                    ." {AVATAR}\n"
                    ."</a>",

      'brief'    =>  "<a class=\"clear-block\" href=\"{URL}\" title=\"{NAME} ({POST_COUNT})\">\n"
                    ." <span class=\"base\">\n"
                    ."   <span class=\"tt\">{NAME}</span>\n"
                    ." </span>\n"
                    ."</a>",

      'detailed' => "<a class=\"clear-block\" href=\"{URL}\" title=\"{NAME}\">\n"
                   ." <span class=\"base\">\n"
                   ."   <span class=\"tt\">{NAME}</span>\n"
                   ."   <span class=\"c1\">{POST_COUNT}</span>\n"
                   ." </span>\n"
                   ."</a>",

    ));

    // default settings
    $this->setDefaults(array(
      'title'         => _a("Authors"),
      'role'          => 'author',
      'mode'          => 'full',
      'avatar_size'   => 48,
      'sort_by'       => 'post_count',
      'hide_empty'    => true,
      'exclude'       => '',
      'number'        => 5,
      'more'          => true,
      'template'      => '',
    ));



    Atom::add('ajax_requests',              array(&$this, 'ajax'));

    // include in jQuery(document).ready()
    Atom::add('jquery_init',                array(&$this, 'js'));

    // flush cache when posts or users change
    add_action('save_post',                 array(&$this, 'flushCache'));
    add_action('deleted_post',              array(&$this, 'flushCache'));
    add_action('user_register',             array(&$this, 'flushCache'));
    add_action('delete_user',               array(&$this, 'flushCache'));
  }

  public function js(){

    // we need to process all instances because this function gets to run only once
    $widget_options = get_option($this->option_name);

    foreach((array)$widget_options as $instance => $options){

      // identify instance
      $id = "{$this->id_base}-{$instance}";

      if(!is_active_widget(false, $id, $this->id_base)) continue;

      $options = wp_parse_args($options, AtomWidget::getObject($id)->getDefaults());

      if(isset($options['more']) && $options['more'])
        echo "\$('#instance-{$id}').showMoreControl('{$instance}', 'get_users', '".wp_create_nonce('atom_get_users')."');\n";

    }
  }

  public function ajax(){
    // not our request
    if(!Atom::app()->request('get_users')) return;

    Atom::app()->ajaxHeader('get_users', 'application/json');

    $settings = get_option($this->option_name);
    $instance = (int)$_GET['instance'];
    $settings = wp_parse_args($settings[$instance], $this->getDefaults());

    $offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
    $output = $this->getUsers($settings, $next, $offset);
    $offset = $offset + $settings['number'];

    echo json_encode(array('output' => $output, 'more' => $next, 'offset' => $offset));
    die();
  }

  private function getUsers($args, &$more, $offset = 0){

    extract($args);
    $users = get_users(array(
      //'blog_id'    => $GLOBALS['blog_id'],

      'role'         => $role,
      'exclude'      => wp_parse_id_list($exclude),
      'orderby'      => $sort_by,
      'order'        => $sort_by != 'display_name' ? 'DESC' : 'ASC',
      'offset'       => $offset,
      'number'       => $number + 1, // +1 because we need to find out if there are more results (to determine if 'show more' should be displayed)
      'count_total'  => false,
      'fields'       => 'all_with_meta', // it seems we get less queries if we retrieve meta too, instead of just array('ID', 'user_email', 'user_url', 'user_registered', 'display_name') ...wtf?
    ));

    // attempt to count each user's posts (heavy db usage here)
    // sort by post count should be handled by get_users()...
    $user_ids = array();

    foreach($users as $user)
      $user_ids[] = $user->ID;

    $user_post_count = count_many_users_posts($user_ids); // much faster than counting them individually
    foreach($users as $user)
      $user->post_count = $user_post_count[$user->ID];  // $user->getCount() uses it if available

    $output = '';
    $count = 1;
    $more = (count($users) > $number) ? true : false;
    $template = ($mode != 'template') ? $this->getTemplate($mode) : $template;
    foreach($users as $user){

      $user = new AtomObjectAuthor($user);

      if($count++ == $number + 1) break; // -1 (see above)

      $output .= '<li'.($count == 1 && $offset === 0 ? ' class="first"' : '').'>';
      $title = ($mode === 'images' || $mode === 'brief') ? sprintf(_a('%1$s (%2$s posts)'), $user->getName(), $user->getPostCount()) : sprintf(_a('Posts by %s'), $user->getName());

      $fields = array(
        'NAME'         => $user->getName(),
        'URL'          => $user->getPostsURL(),
        'AVATAR'       => $user->getAvatar((int)$avatar_size),
        'KARMA'        => $user->getKarma(),
        'POST_COUNT'   => sprintf(_an('%s post', '%s posts', $user->getPostCount()), number_format_i18n($user->getPostCount())),

         // not used by default
        'REGISTERED'   => Atom::getTimeSince(abs(strtotime($user->get('user_registered').' GMT'))),
        'RSS'          => $user->getFeedURL(),
        'ID'           => $user->get('ID'),
        'EMAIL'        => $user->get('user_email'),
        'SITE_URL'     => $user->get('user_url'),

        // meta
        'BIO'          => $user->getDescription(),
        'ROLE'         => $user->getRole(),
        'AIM'          => $user->get('aim'),
        'YIM'          => $user->get('yim'),
        'JABBER'       => $user->get('jabber'),

      );

      $fields = apply_filters('atom_widget_users_keywords', $fields, $user, $args);

      // output template
      $output .= Atom::app()->getBlockTemplate($template, $fields);

      $output .= '</li>';

    }

    return $output;
  }

  public function widget($args, $instance){
    extract($args);

    // check for a cached instance and display it if we have it
    if($this->getAndDisplayCache($widget_id)) return;

    $instance = wp_parse_args($instance, $this->getDefaults());
    $title = apply_filters('widget_title', $instance['title'], $instance, $this->id_base);

    $users = $this->getUsers($instance, $next);
    if(empty($users))
      return Atom::app()->addDebugMessage("No &lt;{$instance['role']}&gt; users found in {$args['widget_id']} ({$args['widget_name']}). Widget marked as inactive");

    $output = $before_widget;
    if($title) $output .= $before_title.$title.$after_title;

    $output .= "<ul class=\"menu fadeThis users clear-block {$instance['mode']}\">\n{$users}\n</ul>\n";

    if($instance['more'] && $next && Atom::app()->options('jquery'))
      $output .= "<div class=\"fadeThis clear-block\"><a href=\"#\" class=\"more\" data-count=\"{$instance['number']}\">"._a("Show More")."</a></div>";

    $output .= $after_widget;

    echo $output;

    $this->addCache($widget_id, $output);
  }

  public function update($new_instance, $old_instance){
    $instance['title']         = esc_attr($new_instance['title']);
    $instance['role']          = esc_attr($new_instance['role']);
    $instance['mode']          = esc_attr($new_instance['mode']);
    $instance['sort_by']       = esc_attr($new_instance['sort_by']);
    $instance['exclude_admin'] = (bool)$new_instance['exclude_admin'];
    $instance['avatar_size']   = (int)$new_instance['avatar_size'];
    $instance['number']        = min(max((int)$new_instance['number'], 1), 40);
    $instance['exclude']       = esc_attr($new_instance['exclude']);
    $instance['more']          = (bool)$new_instance['more'];

    // html template
    if(isset($new_instance['template']) && current_user_can('edit_themes')) $instance['template'] = $new_instance['template'];

    $this->flushCache();
    return $instance;
  }

  public function form($instance){
    $instance = wp_parse_args($instance, $this->getDefaults());
    $wp_roles = new WP_Roles();
    ?>
    <div <?php $this->formClass(); ?>>
      <p>
        <label for="<?php echo $this->get_field_id('title'); ?>"><?php _ae('Title:') ?></label>
        <input type="text" class="wide" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php if (isset($instance['title'])) echo esc_attr($instance['title']); ?>" />
      </p>

      <p>
        <label for="<?php echo $this->get_field_id('role'); ?>"><?php _ae('Role') ?></label>
        <select id="<?php echo $this->get_field_id('role'); ?>" name="<?php echo $this->get_field_name('role'); ?>">
           <option value="" <?php selected(empty($instance['role'])); ?>><?php _ae("-- Any --"); ?></option>
           <?php foreach($wp_roles->role_names as $role => $label): ?>
           <option value="<?php echo $role; ?>"  <?php selected($instance['role'], $role) ?>><?php echo $label; ?></option>
           <?php endforeach; ?>
        </select>
      </p>

      <p>
        <label for="<?php echo $this->get_field_id('sort_by'); ?>"><?php _ae('Sort by') ?></label>
        <select id="<?php echo $this->get_field_id('sort_by'); ?>" name="<?php echo $this->get_field_name('sort_by'); ?>">
         <option value="display_name" <?php selected($instance['sort_by'], "display_name"); ?>><?php _ae("Name"); ?></option>
         <option value="post_count" <?php selected($instance['sort_by'], "post_count"); ?>><?php _ae("Post count, descending"); ?></option>
         <option value="registered" <?php selected($instance['sort_by'], "registered"); ?>><?php _ae("Date registered, newest first"); ?></option>
        </select>
      </p>


      <?php /* @todo: find a way to re-implement this (excludes must be done within get_users()
      <p>
        <label for="<?php echo $this->get_field_id('hide_empty'); ?>">
          <input type="checkbox" id="<?php echo $this->get_field_id('hide_empty'); ?>" name="<?php echo $this->get_field_name('hide_empty'); ?>"<?php checked($instance['hide_empty']); ?> />
          <?php _ae('Only get users with posts'); ?>
        </label>
      </p>
      */
      ?>

      <p>
        <label for="<?php echo $this->get_field_id('exclude'); ?>"><?php _ae('Exclude:'); ?></label>
        <input type="text" value="<?php echo esc_attr($instance['exclude']); ?>" name="<?php echo $this->get_field_name('exclude'); ?>" id="<?php echo $this->get_field_id('exclude'); ?>" class="wide" />
        <br />
        <small><?php _ae('User IDs, separated by commas.'); ?></small>
      </p>

      <p>
       <label for="<?php echo $this->get_field_id('number'); ?>"><?php _ae('How many entries to display?'); ?></label>
       <input id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="text" value="<?php if (isset($instance['number'])) echo (int)$instance['number']; ?>" size="3" />
      </p>

      <p>
       <input <?php if(!Atom::app()->options('jquery')) echo "disabled=\"disabled\""; ?> type="checkbox" id="<?php echo $this->get_field_id('more'); ?>" name="<?php echo $this->get_field_name('more'); ?>"<?php checked($instance['more']); ?> />
       <label for="<?php echo $this->get_field_id('more'); ?>" <?php if(!Atom::app()->options('jquery')) echo "class=\"disabled\""; ?>><?php printf(_a('Display %s Link'), '<code>'._a("Show More").'</code>'); ?></label>
      </p>

      <p>
        <label for="<?php echo $this->get_field_id('avatar_size'); ?>"><?php _ae('Avatar Size:') ?></label>
        <input type="text" size="3" id="<?php echo $this->get_field_id('avatar_size'); ?>" name="<?php echo $this->get_field_name('avatar_size'); ?>" value="<?php if (isset($instance['avatar_size'])) echo esc_attr($instance['avatar_size']); ?>" /> <?php _ae("pixels"); ?>
      </p>

      <div class="template-selector clear-block">
        <div class="title"><?php _ae('Display mode') ?></div>
        <a href="#" class="select t-full" rel="full" title="<?php _ae("Full"); ?>"><?php _ae("Full"); ?></a>
        <a href="#" class="select t-detailed" rel="detailed" title="<?php _ae("Details"); ?>"><?php _ae("Details"); ?></a>
        <a href="#" class="select t-brief" rel="brief" title="<?php _ae("Brief"); ?>"><?php _ae("Brief"); ?></a>
        <a href="#" class="select t-images" rel="images" title="<?php _ae("Avatar thumbnails"); ?>"><?php _ae("Avatars thumbnails"); ?></a>
        <a href="#" class="select t-custom" rel="template" title="<?php _ae("Custom Template"); ?>"><?php _ae("Custom Template"); ?></a>
        <input class="select" type="hidden" value="<?php echo $instance['mode']; ?>" id="<?php echo $this->get_field_id('mode'); ?>" name="<?php echo $this->get_field_name('mode'); ?>" />
      </div>

      <?php if(current_user_can('edit_themes')): ?>
      <div class="user-template <?php if($instance['mode'] !== 'template') echo 'hidden'; ?>">
        <textarea class="wide code" id="<?php echo $this->get_field_id('template'); ?>" name="<?php echo $this->get_field_name('template'); ?>" rows="8" cols="28" mode="atom/html"><?php echo (empty($instance['template'])) ? format_to_edit($this->getTemplate()) : format_to_edit($instance['template']); ?></textarea>
        <small>
          <?php printf(_a("Read the %s to see all available keywords."), '<a href="'.Atom::THEME_DOC_URI.'" target="_blank">'._a("documentation").'</a>'); ?>
        </small>
      </div>
      <?php endif; ?>
    </div>
    <?php
  }
}