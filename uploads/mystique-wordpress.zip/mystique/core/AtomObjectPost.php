<?php
/**
 * Atom Post class - Handles individual posts
 *
 * @link http://digitalnature.eu
 *
 * @package ATOM
 * @subpackage Template
 */



class AtomObjectPost extends AtomObject{

  private
    $post_format,
    $post_title,
    $post_url,
    $post_content,
    $post_excerpt,
    $post_thumb,                    // array, caches requested thumb sizes
    $post_terms,                    // array, caches taxonomy terms
    $post_views,

    $comment_list,                  // stores the comment list for the current post

    $meta,                          // array, post meta

    $current_author,                // author object
    $related_posts;                 // caches the related posts array



  public function __construct($user_post = false){
    global $post;

    if(is_numeric($user_post)){
      $this->data = &get_post($user_post);

      if(!is_object($this->data))
        throw new Exception("Failed to get post {$user_post}");

      $post = $this->data;
      setup_postdata($post);

    }elseif(is_object($user_post)){
      $this->data = $user_post;
      $post = $this->data;
      setup_postdata($post);

    }else{

      // stupid WP globals...
      $this->data = &$post;
    }


    // set up control links
	if($url = get_edit_post_link($this->data->ID)) // get_edit_post_link handles permissions...
      $this->controls['edit'] = array(
        'target' => $url,
        'label'  => _a('Edit'),
      );

    $this->controls['print'] = array(
      'target'   => add_query_arg('print', 1, Atom::app()->getCurrentPageURL()),
      'label'    => _a('Print'),
      'onclick'  => 'return !window.open(this.href, document.title, \'width=650,height=440,scrollbars=yes\')', // @todo
    );

  }



  public function getFormat(){
    $this->post_format = isset($this->post_format) ? $this->post_format : get_post_format($this->data->ID);

    return $this->post_format;
  }


  public function getType(){
    return $this->data->post_type;
  }


  public function getID(){
    return $this->data->ID;
  }


  public function getParent(){
    return $this->data->post_parent;
  }

  public function getMeta($field, $single = true){
    if(!isset($this->meta[$field]))
      $this->meta[$field] = get_post_meta($this->data->ID, $field, $single);

    return $this->meta[$field];
  }


  /**
   * Get all post's comments
   * Replaces WP's comments_template(), so we can use the nice ajax comments feature
   * @todo: reduce database usage, by finding a way to load only the requested comments instead of all comments. This can be done using LIMIT, but then we get the wrong comment/ping count :(
   *
   * @since 1.2
   *
   * @param int $post_id Optional post ID
   * @return array comments
   */
  private function queryComments(){
    if(!isset($this->comment_list)){

      global $user_ID, $overridden_cpage, $wpdb, $wp_query;

      if(!(is_single() || is_page() || $GLOBALS['withcomments'])) return false;

      $commenter = wp_get_current_commenter();
      $comment_author = wp_specialchars_decode($commenter['comment_author'], ENT_QUOTES); // Escaped by sanitize_comment_cookies()
      $comment_author_email = $commenter['comment_author_email'];  // Escaped by sanitize_comment_cookies()
      $comment_author_url = esc_url($commenter['comment_author_url']);

      $filter = Atom::app()->commentSearch() ? mysql_real_escape_string(Atom::app()->commentSearch()) : '';
      if(!empty($filter)) $filter = "AND (comment_content LIKE '%%{$filter}%%' OR comment_author LIKE '%%{$filter}%%')";

      // show non-approved comments based on the current user context
      if(current_user_can('moderate_comments')){
        $filter .= " AND (comment_approved != 'trash')"; // we don't want trashed comments visible to anyone
      }else{
        if($user_ID)
          $filter .= " AND (comment_approved = '1' OR (user_id = '{$user_ID}' AND comment_approved = '0'))";
        elseif(empty($comment_author))
          $filter .= " AND comment_approved = '1'";
        else
          $filter .= " AND (comment_approved = '1' OR (comment_author = '".wp_specialchars_decode($comment_author, ENT_QUOTES)."' AND comment_author_email = '{$comment_author_email}' AND comment_approved = '0'))";
      }

      $query = $wpdb->prepare("SELECT * FROM {$wpdb->comments} WHERE comment_post_ID = %d {$filter} ORDER BY comment_date_gmt", $this->data->ID);

      /*/ check cache -- too much memory on many comments...
      $key = md5($query);
      $cache = wp_cache_get('get_comments', 'atom');
      if(!isset($cache[$key])){
        $this->comment_list = $wpdb->get_results($query);
        $cache[$key] = $this->comment_list;
        wp_cache_set('get_comments', $cache, 'atom');
      }else{
        $this->comment_list = $cache[$key];
      }
      /*/
      $this->comment_list = $wpdb->get_results($query);

      $wp_query->comments = apply_filters('comments_array', $this->comment_list, $this->data->ID);
      $wp_query->comment_count = count($wp_query->comments);
      update_comment_cache($this->comment_list);
      $wp_query->comments_by_type = &separate_comments($this->comment_list);

      $overridden_cpage = false;
      if(get_query_var('cpage') == '' && get_option('page_comments')){
        set_query_var('cpage', (get_option('default_comments_page') === 'newest') ? $this->countCommentPages() : 1);
        $overridden_cpage = true;
      }

    }
    return $this->comment_list;
  }



  /**
  * List comments
  *
  * Used in the comments.php template to list comments for a particular post
  *
  * @since 2.7.0
  * @uses Walker_Comment
  *
  * @param string|array $args Formatting options
  * @param array $comments Optional array of comment objects.  Defaults to $wp_query->comments
  */
  public function comments($type = 'comment', $args = array()){

    global $wp_query, $comment_alt, $comment_depth, $comment_thread_alt, $overridden_cpage, $in_comment_loop;

    $comments = $this->queryComments();
    if(empty($comments)) return;

    $in_comment_loop = true;
    $comment_alt = $comment_thread_alt = 0;
    $comment_depth = 1;

    $args = wp_parse_args($args, array(
      'max_depth'         => get_option('thread_comments') ? (int)get_option('thread_comments_depth') : -1,
      'style'             => 'ul',
      'type'              => $type,
      'page'              => $overridden_cpage ? false : (int)get_query_var('cpage'),
      'per_page'          => get_option('page_comments') ? get_query_var('comments_per_page') : 0,
      'per_page_force'    => true,
      'reverse_top_level' => (get_option('comment_order') === 'desc'),
      'reverse_children'  => false,
    ));

    if($args['type'] !== 'all'){
      $comments_by_type = &separate_comments($comments);
      if($args['type'] === 'ping') $args['type'] = 'pings'; // stupid wp...
      if(empty($comments_by_type[$args['type']])) return;
      $comments = $comments_by_type[$args['type']];
    }                                      //

    if(empty($args['per_page']) || (int)$args['per_page'] < 1 || Atom::app()->commentSearch()){
      $args['per_page'] = 0;
      $args['page'] = 0;
    }

    if($args['page'] === false){
      $args['page'] = (get_option('default_comments_page') === 'newest') ? $this->countCommentPages($comments, $args['per_page'], (($args['max_depth'] !== -1))) : 1;
      set_query_var('cpage', $args['page']);
    }

    $walker = new AtomWalkerComments;
    $walker->paged_walk($comments, $args['max_depth'], $args['page'], $args['per_page'], $args);

    $wp_query->max_num_comment_pages = $walker->max_pages;

    $in_comment_loop = false;
  }



  public function getCommentCount(){

    // comments have been loaded and separated
    if(isset($GLOBALS['wp_query']->comments_by_type)) return count($GLOBALS['wp_query']->comments_by_type['comment']);

    // we're outside the meta template, return the recorded comment count from $post (imprecise, counts both comments and pings)
    elseif(isset($this->data->comment_count)) return $this->data->comment_count;

    // invalid context, maybe outside the loop on a category page?
    else return 0;
  }



  public function getPingCount(){

    if(is_singular() && post_type_supports($this->getType(), 'comments'))
      $this->queryComments();

    if(isset($GLOBALS['wp_query']->comments_by_type)) return count($GLOBALS['wp_query']->comments_by_type['pings']);

    // we're not in the meta template...
    else return 0;
  }



  public function countCommentPages($comments = null, $per_page = null, $threaded = null){
    global $wp_query;

    if(null === $comments && null === $per_page && null === $threaded && !empty($wp_query->max_num_comment_pages)) return (int)$wp_query->max_num_comment_pages;

    if(!$comments || !is_array($comments)) $comments = $this->queryComments();

    if(empty($comments)) return 0;

    if(!isset($per_page)) $per_page = (int)get_query_var('comments_per_page');
    if($per_page === 0) $per_page = (int)get_option('comments_per_page');
    if($per_page === 0) return 1;

    if(!isset($threaded)) $threaded = get_option('thread_comments');

    if($threaded){
      $walker = new AtomWalkerComments;
      $count = ceil($walker->get_number_of_root_elements($comments) / $per_page);
    } else {
      $count = ceil(count($comments) / $per_page);
    }

    return $count;
  }



  /**
   * Return the post date
   *
   * @since 1.0
   *
   * @param string $mode
   */
  public function getDate($mode = ''){
    // 'relative' or a date string like 'd-M-Y'
    if(empty($mode))
      $mode = Atom::app()->options('post_date_mode');

    if($mode === 'absolute')
      $mode = get_option('date_format');

    return ($mode !== 'relative') ? get_the_date($mode) : Atom::getTimeSince(abs(strtotime("{$this->data->post_date} GMT")));
  }



  /**
  * Get post view count
  *
  * @since 1.4
  */
  function getViews(){
    // also check for swc + mu
    if(!isset($this->post_views))
      $this->post_views = isset($this->data->views) ? (int)$this->data->views : (int)get_post_meta($this->data->ID, apply_filters('post_views_meta_key', 'views'), true);

    return $this->post_views;
  }



  /**
  * Get the blog ID of the current post.
  * Only relevant within a "Atom Site-Wide Content" query
  *
  * @since 1.4
  */
  function getBlogID(){
    if(isset($this->data->blog_id))
      return $this->data->blog_id;

    return get_current_blog_id();
  }



  /**
   * Update post view count
   *
   * @since 1.4
   */
  public static function incrementViews(){

    // wp-postviews installed? don't do anything then...
    if((defined('ATOM_LOG_VIEWS') && !ATOM_LOG_VIEWS) || function_exists('increment_views')) return;

    $post_id = Atom::app()->post->getID();
    $new_records = $posts_seen = array();

    $current_user = wp_get_current_user();
    if($current_user->ID)
      $posts_seen = explode('-', get_user_meta($current_user->ID, 'posts-seen', true));

    // import IDs from the cookie if it exists
    if(isset($_COOKIE['posts-seen'])){
      $posts_seen = array_merge($posts_seen, explode('-', $_COOKIE['posts-seen']));
    }

    // validate current records
    foreach(array_unique($posts_seen) as $entry)
      if(is_numeric($entry) && $entry > 0) $new_records[] = $entry;

    // post has already been seen by the current user
    if(in_array($post_id, $new_records)) return;

    $meta_key = apply_filters('post_views_meta_key', 'views');
    $views = get_post_meta($post_id, $meta_key, true);

    update_post_meta($post_id, $meta_key, absint($views) + 1, $views);

    $new_records[] = $post_id;

    // limit to 50 records
    if(count($new_records) > 50) array_splice($new_records, 0, count($new_records) - 40);

    if($current_user->ID){
      update_user_meta($current_user->ID, 'posts-seen', implode('-', $new_records));

      // expire cookie if set
      if(isset($_COOKIE['posts-seen']))
        setcookie('posts-seen', '', time() - 3600, '/');
    }else{
      setcookie('posts-seen', implode('-', $new_records), time() + 60*60*24*90, '/'); // 3 months (should get renewed every time the user reads a new   post)
    }
  }



  /**
   * Retrieve the post title URL (to be used only inside the loop)
   * title_url custom field overrides the assigned permalink
   *
   * @since 1.0
   *
   * @return string URL
   */
  public function getURL(){
    if(!isset($this->post_url)){

      // mu / swc
      if(isset($this->data->permalink)){
        $this->post_url = $this->data->permalink;
      }else{
        $title_url = get_post_meta($this->data->ID, 'title_url', true);
        $this->post_url = $title_url ? $title_url : get_permalink($this->data->ID);
      }
    }
    return $this->post_url;
  }



  /**
   * Create a TinyURL link - see tinyurl.com
   *
   * @since 1.0
   *
   * @param string $url Website URL to convert to a TinyURL link; default is the current post permalink
   * @return string The TinyURL link
   */
  public function getTinyURL($url = ''){
    // only connect to tinyurl if the transient is not present in the database (to avoid slowing down page load)
    $response = false;
    $id = md5($url);

    if(($response = get_transient("tinyurl_{$id}")) === false){
      $response = wp_remote_retrieve_body(wp_remote_get('http://tinyurl.com/api-create.php?url='.($url ? $url : $this->getURL())));

      // add transient in the db for 1 day
      set_transient("tinyurl_{$id}", $response, 60*60*24);
    }
    return $response;
  }



  /**
   * Get the post title, trim if necessary
   *
   * @since 1.2
   *
   * @param int $character_limit Limit title length
   *
   * @return string post title
   */
  public function getTitle($character_limit = 0){
    if(!isset($this->post_title))
      $this->post_title = get_the_title();  // @todo find a way to pass the post ID, without screwing up the SWC query...

    // limit number of characters and append '...' ?
    if($character_limit > 0 && (strlen($this->post_title) > $character_limit)) return substr($this->post_title, 0, $character_limit).'...';

    return $this->post_title;
  }



  /**
   * Retrieve the terms for a post.
   * uses wp_get_post_terms()
   *
   * @since 1.0
   *
   * @param string $tax Term Taxonomy (optional, defaults to tags)
   * @param string $separator Separator
   * @param string $template Entry template; if set to false the function will return the raw objects as an array
   *
   * @return array|string Terms
   */
  public function getTerms($tax = 'post_tag', $separator = ' ', $template = '<a href="%url%" rel="tag" title="%title%">%name%</a>'){

    if(!isset($this->post_terms[$tax])){
      $terms = wp_get_post_terms($this->data->ID, $tax);

      if(is_wp_error($terms))
        return Atom::app()->addDebugMessage("Unable to get terms for post {$this->data->ID} ({$tax} taxonomy)", 1);

      $this->post_terms[$tax] = $terms;
    }

    // no template, return array
    if(empty($template))
      return $this->post_terms[$tax];

    $output = array();
    foreach($this->post_terms[$tax] as $term){
      $keywords = array('%url%', '%title%', '%name%');
      $url = get_term_link($term, $tax);
      $title = "{$term->name} (".(sprintf(_an('%s topic', '%s topics', $term->count), number_format_i18n($term->count))).")";

      $output[] = str_replace($keywords, array($url, $title, $term->name), $template);
    }

    if(!empty($output)) return implode($separator, $output);
  }



  /**
   * Get post content
   * uses get_the_content()
   *
   * @since 1.0
   *
   * @param int|string $mode mode ("full", "excerpt" or number of words)
   * @param array $options Options to pass to getFilteredContent()
   *
   * @return string
   */
  public function getContent($mode = '', $options = array()){

    if(!$mode)
      $mode = Atom::app()->options('post_content_mode');

    $defaults = array(
      'limit' => is_numeric($mode) ? $mode : 0,
      'more'  => _a('More &gt;')
    );

    $defaults = Atom::app()->getContextArgs('post_content', $defaults);

    // "more" text, link by default
    if(!empty($defaults['more']))
      $defaults['more'] = '<a href="'.$this->getURL().'" class="more-link" data-post="'.$this->data->ID.'">'.strip_tags($defaults['more']).'</a>';

    // function arguments override everything
    $options = array_merge($defaults, $options);

    if($mode[0] == 'e'){
      if(!isset($this->post_excerpt))
        $this->post_excerpt = get_the_excerpt();

      return $this->post_excerpt;

    }else{
      if(!isset($this->post_content)){
        $this->post_content = apply_filters('the_content', get_the_content());
        $this->post_content = str_replace(']]>', ']]&gt;', $this->post_content);
      }

      return ($mode !== 'f') ? Atom::getFilteredContent($this->post_content, $options) : $this->post_content;
    }
  }



  /**
   * Output the post thumbnail
   * Replaces get_the_post_thumbnail()
   *
   * @since 1.0
   *
   * @param string $size Optional. Thumbnail size
   * @return string|array Thumbnail image
   */
  public function getThumbnail($size = 'post-thumbnail', $attr = ''){

    $avail_image_sizes = $GLOBALS['_wp_additional_image_sizes'];
    $size_id = is_array($size) ? implode('x', $size) : $size;

    // handle an array type size
    if(is_array($size)){
      list($width, $height) = $size;
      foreach($avail_image_sizes as $id => $sizes)
        if(($width == $sizes['width']) && ($height == $sizes['height'])) $size = $id;
    }

    // already have it in cache?
    if(isset($this->post_thumb[$size_id]))
      return $this->post_thumb[$size_id];

    // swc + mu
    if(isset($this->data->thumbnails)){

      // we need array here
      $size = is_string($size) ? $avail_image_sizes[$size] : array('width' => $size[0], 'height' => $size[1]);

      foreach($this->data->thumbnails as $thumb_size => $url){
        list($thumb_width, $thumb_height) = explode('x', $thumb_size);

        // we have a match
        if($size['width'] == $thumb_width && $size['height'] == $thumb_height){

          $hwstring = image_hwstring($thumb_width, $thumb_height);
          $attributes = array(
            'src'   => $url,
            'class' => "attachment-{$size_id}",
            'alt'   => $this->getTitle(), // post title
          );
          $html = rtrim("<img {$hwstring}");
          foreach($attributes as $name => $value) $html .= " {$name}=".'"'.$value.'"';
          $html .= ' />';

          // maybe we shouldn't apply this filter?
          $this->post_thumb[$size_id] = apply_filters('post_thumbnail_html', $html, $this->data->ID, $this->data->ID, $size_id, $attr);
          return $this->post_thumb[$size_id];
        }
      }
      $this->post_thumb[$size_id] = '<span class="no-img" style="width:'.$size['width'].'px;height:'.$size['height'].'px">&nbsp;</span>';
      return $this->post_thumb[$size_id];
    }

    $html = '';
    //  $t = get_post_meta($this->data->ID, '_thumbnail_id', true);
    $t = get_post_thumbnail_id($this->data->ID);

    if(empty($t) && Atom::app()->options('post_thumb_auto')){
      $attachments = get_children(array(
        'post_parent'    => $this->data->ID,
        'post_status'    => 'inherit',
        'post_type'      => 'attachment',
        'post_mime_type' => 'image',
        'order'          => 'ASC',
        'orderby'        => 'menu_order ID',
      ));
      $attachment = array_shift($attachments);
      $t = $attachment ? $attachment->ID : false;
    }

    $done = false;
    if(!isset($width) && !isset($height)){
      $width = $avail_image_sizes[$size]['width'];
      $height = $avail_image_sizes[$size]['height'];
    }

    if(is_numeric($t) && $this->thumbnailNeedsRegeneration($t, $size)){
      if(is_string($size))
        $html = '<span class="no-img regen" id="regen-'.$this->data->ID.'-'.$t.'" style="width:'.$width.'px;height:'.$height.'px" data-size="'.$size_id.'">&nbsp;</span>';
      else
        $html = '<span class="no-img" style="width:'.$width.'px;height:'.$height.'px">&nbsp;</span>';

    }elseif(is_numeric($t)){
      do_action('begin_fetch_post_thumbnail_html', $this->data->ID, $t, $size);
      $html = wp_get_attachment_image($t, $size, false, $attr);
      do_action('end_fetch_post_thumbnail_html', $this->data->ID, $t, $size);
    }

    $html = apply_filters('post_thumbnail_html', $html, $this->data->ID, $t, $size, $attr);
    $this->post_thumb[$size_id] = $html ? $html : "<span class=\"no-img\" style=\"width:{$width}px;height:{$height}px\"></span>";

    return $this->post_thumb[$size_id];
  }



  /**
   * Retrieves all attached images to a post
   *
   * @since 1.2
   *
   * @param int $post_id Post ID.
   * @param string $order Order, ASC/DESC
   * @param string $orderby Order byl
   *
   * @return array results
   */
  public function getGallery($order = 'ASC', $orderby = 'menu_order ID'){
    return get_children(array(
      'post_parent'     => $this->data->ID,
      'post_status'     => 'inherit',
      'post_type'       => 'attachment',
      'post_mime_type'  => 'image',
      'order'           => $order,
      'orderby'         => $orderby,
    ));
  }


  /**
   * Check if a post thumbnail needs to be updated (missing size)
   * @todo: attempt to create and generate missing array(w,h) sizes (need a proper security check here)
   *
   * @since 1.3
   *
   * @param int $attachment_id Attachment ID
   * @param string|array $size Thumbnail size
   * @return bool
   */
  public static function thumbnailNeedsRegeneration($attachment_id, $size = 'post-thumbnail'){

    // handle an array type size
    if(is_array($size)){
      list($width, $height) = $size;
      foreach($GLOBALS['_wp_additional_image_sizes'] as $id => $sizes)
        if(($width == $sizes['width']) && ($height == $sizes['height'])) $size = $id;
    }

    // a string size is required by this point
    if(!is_string($size)) return true;

    // no such size, probably fake request
    if(!isset($GLOBALS['_wp_additional_image_sizes'][$size])) return false;

    $requested_width = $GLOBALS['_wp_additional_image_sizes'][$size]['width'];
    $requested_height = $GLOBALS['_wp_additional_image_sizes'][$size]['height'];

    $meta = wp_get_attachment_metadata($attachment_id);
    if(!is_array($meta) || empty($meta)) return false;

    // small image? WP doesn't enlarge images
    if(!isset($meta['sizes'][$size]) && ($meta['width'] < $requested_width) && ($meta['height'] < $requested_height)) return false;

    // check if we have a size match
    if(isset($meta['sizes'][$size]['width']) && isset($meta['sizes'][$size]['height']))
      if(($meta['sizes'][$size]['width'] == $requested_width) || ($meta['sizes'][$size]['height'] == $requested_height)) return false;
      
    // check if original size matches the requested size
    if(isset($meta['width']) && isset($meta['height']))
      if(($meta['width'] == $requested_width) || ($meta['height'] == $requested_height)) return false;      

    return true;
  }



  /**
   * Update a post thumbnail (generate new image sizes)
   * Should be called trough ajax because it requires a lot of cpu and it will slow down page loading
   * - based on the 'regenerate thumbnails' plugin by Viper007Bond
   *
   * @since 1.0
   *
   * @param int $t Thumbnail (attachment) ID
   * @param string|array $size Optional. Thumbnail size
   * @return bool true if new meta data was generated, false otherwise
   */
  public static function regenerateThumbnail($attachment_id, $size = 'post-thumbnail'){
    if(!Atom::app()->options('generate_thumbs') || !AtomObjectPost::thumbnailNeedsRegeneration($attachment_id, $size)) return false;

    $full_size_path = get_attached_file($attachment_id);

    // The originally uploaded image file cannot be found at $full_size_path
    if($full_size_path == false || !file_exists($full_size_path)) return false;

    require_once(ABSPATH.'/wp-admin/includes/image.php');

    @set_time_limit(300); // 5 minutes should be PLENTY
    $metadata = wp_generate_attachment_metadata($attachment_id, $full_size_path);
    if(is_wp_error($metadata)) return false; // $metadata->get_error_message();

    wp_update_attachment_metadata($attachment_id, $metadata);

    return true;
  }



  /**
   * Output the social media links to allow the user to share the current post
   * to be used only inside the loop!
   *
   * @since 1.0
   *
   * @todo Re-check all website URLs + parameters
   * @return string HTML
   */
  public function getShareLinks(){

    // data to expose
    $fields = apply_filters('atom_share_fields', array(
      '{TITLE}'     => urlencode($this->getTitle()),
      '{AUTHOR}'    => urlencode($this->author->getName()),
      '{URL}'       => urlencode($this->getURL()),
      '{SHORT_URL}' => urlencode($this->getTinyURL()),
      '{EXCERPT}'   => urlencode($this->getContent('e')),
      '{SOURCE}'    => urlencode(get_bloginfo('name')),
    ));

    // @todo: update this list, some links might not work anymore...
    $sites = apply_filters('atom_share_urls', array(
      'Twitter'          => 'http://twitter.com/home?status={TITLE}+-+{SHORT_URL}',
      'Digg'             => 'http://digg.com/submit?phase=2&amp;url={URL}&amp;title={TITLE}',
      'Facebook'         => 'http://www.facebook.com/share.php?u={URL}&amp;t={TITLE}',
      'Delicious'        => 'http://del.icio.us/post?url={URL}&amp;title={TITLE}',
      'StumbleUpon'      => 'http://www.stumbleupon.com/submit?url={URL}&amp;title={TITLE}',

      /*/ more?
      'Google Bookmarks' => 'http://www.google.com/bookmarks/mark?op=add&amp;bkmk={URL}&amp;title={TITLE}',
      'LinkedIn'         => 'http://www.linkedin.com/shareArticle?mini=true&amp;url={URL}&amp;title={TITLE}&amp;summary={EXCERPT}&amp;source={SOURCE}',
      'Yahoo Bookmarks'  => 'http://buzz.yahoo.com/buzz?targetUrl={URL}&amp;headline={TITLE}&amp;summary={EXCERPT}',
      'Technorati'       => 'http://technorati.com/faves?add={URL}',
      //*/
    ));

    $output = '';
    if(!empty($sites)){
      $output .= '<ul class="share-this">';
      $i = 1;
      $total = count($sites);
      foreach($sites as $name => $url){
        $classes = array(sanitize_html_class(strtolower($name)));
        if($i++ === $total) $classes[] = 'last';
        $url = str_replace(array_keys($fields), array_values($fields), $url);
        $output .= '<li class="'.implode(' ', $classes).'"><a href="'.$url.'" title="'.sprintf(_a('Share this post on %s'), $name).'">'.$name.'</a></li>';
      }
      $output .= '</ul>';
    }

    return $output;
  }



  /**
   * Displays page-links for paginated posts.
   * Same as wp_link_pages(), but formats the output to match the other pagination blocks.
   * Must be used inside the loop
   *
   * @since 1.0
   * @todo: find a way to integrate this into pageNavi()
   */
  function paginate(){
    $pages =
       wp_link_pages(array(
         'before'         => '<div class="page-navi clear-block"><span class="pages">'._a('Pages &raquo;').'</span>',
         'after'          => '</div>',
         'link_before'    => '<span class="current">',
         'link_after'     => '</span>',
         'next_or_number' => 'number',
         'echo'           => 0,
       ));

    // remove the <span class="current> & </span> tags (that we added above) from inside links
    echo $pages ? preg_replace('@\<a([^>]*)>\<span([^>]*)>(.*?)\<\/span>@i', '<a$1>$3', $pages) : '';
  }



  /**
   * Get the post author
   *
   * @since 1.0
   * @return object Atom author object
   */
  public function getCurrentAuthor(){
    if(!isset($this->current_author)) $this->current_author = new AtomObjectAuthor();
    return $this->current_author;
  }



  /**
   * Output posts related to the current post, by taxonomy terms
   *
   * @since 1.6
   *
   * @return array|bool array of post objects, or false if no related posts were found
   */
  public function getCurrentRelated(){
    if(!isset($this->related_posts)){

      $tax_query = array();

      // figure out post taxonomies and attempt to match terms from all of them
      $taxonomies = ($this->data->post_type !== 'post') ? get_object_taxonomies($this->data->post_type) : array('post_tag');
      foreach($taxonomies as $taxonomy){
        if(!isset($this->post_terms[$taxonomy])) $this->post_terms[$taxonomy] = wp_get_post_terms($this->data->ID, $taxonomy);

        $term_ids = array();
        if(isset($this->post_terms[$taxonomy]))
          foreach($this->post_terms[$taxonomy] as $term) $term_ids[] = $term->term_id;

        if(!empty($term_ids))
          $tax_query[] = array(
            'taxonomy'  => $taxonomy,
            'field'     => 'id',
            'terms'     => $term_ids,
            'operator'  => 'IN',
          );
      }

      // no terms to compare = no related posts
      if(empty($tax_query)) return false;

      if(count($tax_query) > 1) // more than one taxonomy? set a relation
        $tax_query['relation'] = 'OR';

      $query = Atom::app()->getContextArgs('related_posts', array(
        'offset'               => 0,
        'post__not_in'         => array($this->data->ID),
        'posts_per_page'       => 10,
        'tax_query'            => $tax_query,
        'ignore_sticky_posts'  => true,
        'suppress_filters'     => true,
      ));

      $related = new WP_Query($query);

      // do we have more posts than we initially requested?
      if(!defined('DOING_AJAX') && ($related->found_posts > $query['posts_per_page']))
        $this->controls['related'] = array(
          'data' => array(
            'offset' => $query['posts_per_page'].', '.$related->found_posts,
            'post'   => $this->data->ID,
           ),
          'label' => sprintf(_a('And %s more...'), ($related->found_posts - $query['posts_per_page'])),
        );

      $this->related_posts = $related ? new AtomIteratorPosts($related->posts) : false;
    }

    return $this->related_posts;
  }



}