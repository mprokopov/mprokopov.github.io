<?php

/**
 * Atom Top Commenters widget
 *
 * A list of users who comment on the site
 *
 * @since 1.0
 * @todo implement 'more' link
 * @todo add fade to image links in avatar-only mode
 */



class AtomWidgetTopCommenters extends AtomWidget{

  public function AtomWidgetTopCommenters(){

    $this->WP_Widget('atom-top-commenters', _a('Top Commenters'), array('classname' => 'top-commenters', 'description' => _a("People who frequently comment the blog")), array('width' => 500));

    // set up default templates
    $this->registerTemplates(array(
      'full'     =>  "<a id=\"{ID}\" class=\"clear-block\" href=\"{URL}\" rel=\"external nofollow\">\n"
                    ." {AVATAR}\n"
                    ." <span class=\"base\">\n"
                    ."   <span class=\"tt\">{NAME}</span>\n"
                    ."   <span class=\"c1\">{COMMENT_COUNT}</span>\n"
                    ." </span>\n"
                    ."</a>",

      'images'   =>  "<a id=\"{ID}\" class=\"clear-block tt\" href=\"{URL}\" title=\"{NAME} ({COMMENT_COUNT})\" rel=\"external nofollow\">\n"
                    ." {AVATAR}\n"
                    ."</a>",

      'brief'    =>  "<a id=\"{ID}\" class=\"clear-block\" href=\"{URL}\" title=\"{NAME} ({COMMENT_COUNT})\" rel=\"external nofollow\">\n"
                    ." <span class=\"base\">\n"
                    ."   <span class=\"tt\">{NAME}</span>\n"
                    ." </span>\n"
                    ."</a>",

      'detailed' =>  "<a id=\"{ID}\" class=\"clear-block\" href=\"{URL}\" title=\"{NAME}\" rel=\"external nofollow\">\n"
                    ." <span class=\"base\">\n"
                    ."   <span class=\"tt\">{NAME}</span>\n"
                    ."   <span class=\"c1\">{COMMENT_COUNT}</span>\n"
                    ." </span>\n"
                    ."</a>",
    ));

    // default settings
    $this->setDefaults(array(
      'title'       => _a("Top Commenters"),
      'number'      => 12,
      'mode'        => 'images',
      'avatar_size' => 72,
      'template'    => '',
    ));

    // flush cache when comments are changed
    add_action('comment_post',              array(&$this, 'flushCache'));
    add_action('transition_comment_status', array(&$this, 'flushCache'));
  }

  public function widget($args, $instance){
    global $wpdb;

    extract($args, EXTR_SKIP);

    // check for a cached instance and display it if we have it
    if($this->getAndDisplayCache($widget_id)) return;

    $instance = wp_parse_args($instance, $this->getDefaults());
    $title = apply_filters('widget_title', $instance['title'], $instance, $this->id_base);
    $output = $before_widget;

    // query based on "Top Commenters Gravatar" plugin - http://suhanto.net/top-commenters-gravatar-widget-wordpress/
    $sql = "SELECT comment_author, comment_author_email, comment_author_url, comment_author_IP, user_id, count(1) as counter from {$wpdb->comments} WHERE comment_approved = '1' AND comment_type != 'pingback'";

    // group by (only the first two are used):
    //  - comment_author (name, default)
    //  - comment_author_email (same users may have different emails)
    //  - comment_author_url (people can have multiple sites)
    //  - comment_author_IP (really useless, lots of people have dynamic IPs)
    $sql .= " GROUP BY comment_author, comment_author_email ORDER BY counter DESC, comment_date DESC LIMIT ".(int)$instance['number'];
    $commenters = $wpdb->get_results($wpdb->prepare($sql));
    if(!$commenters) return Atom::app()->addDebugMessage("No relevant entries found in {$args['widget_id']} ({$args['widget_name']}). Widget marked as inactive");;

    if($title) $output .= $before_title.$title.$after_title;

    $output .= "<ul class=\"menu fadeThis top-commenters {$instance['mode']}\">";
    $template = ($instance['mode'] === 'template') ? $instance['template'] : $this->getTemplate($instance['mode']);
    $count = 0;
    foreach($commenters as $commenter):
      $count++;
      $comment_count = isset($commenter->counter) ? sprintf(_an('%s comment', '%s comments', $commenter->counter), number_format_i18n($commenter->counter)) : '';
      //$author_has_url = !(empty($commenter->comment_author_url) || 'http://' == $commenter->comment_author_url);
      $output .= '<li'.($count == 1 ? ' class="first"' : NULL).'>';

      $fields = array(
        'ID'             => 'a-'.uniqid(),
        'NAME'           => $commenter->comment_author,
        'AVATAR'         => Atom::app()->getAvatar($commenter->comment_author_email, (int)$instance['avatar_size'], '', $commenter->comment_author),
        'URL'            => esc_url($commenter->comment_author_url),
        'KARMA'          => (int)get_user_meta($commenter->user_id, "karma", true),
        'COMMENT_COUNT'  => $comment_count,
        'EMAIL'          => esc_url($commenter->comment_author_email) // should not be used
      );

      $fields = apply_filters('atom_widget_top_commenters_keywords', $fields, $commenter, $args);

      // output template
      $output .= Atom::app()->getBlockTemplate($template, $fields);

      $output .= '</li>';
    endforeach;
    $output .= '</ul>';

    $output .= $after_widget;

    echo $output;

    $this->addCache($widget_id, $output);
  }

  public function update($new_instance, $old_instance){
    $instance['title']       = esc_attr($new_instance['title']);
    $instance['number']      = min(max((int)$new_instance['number'], 1), 50);
    $instance['mode']        = esc_attr($new_instance['mode']);
    $instance['avatar_size'] = (int)$new_instance['avatar_size'];

    // html template
    if(isset($new_instance['template']) && current_user_can('edit_themes')) $instance['template'] = $new_instance['template'];

    $this->flushCache();
    return $instance;
  }

  public function form($instance){
    $instance = wp_parse_args($instance, $this->getDefaults());
    ?>
    <div <?php $this->formClass(); ?>>
      <p>
        <label for="<?php echo $this->get_field_id('title'); ?>"><?php _ae('Title:') ?></label>
        <input type="text" class="wide" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php if (isset($instance['title'])) echo esc_attr($instance['title']); ?>" />
      </p>

      <p>
        <label for="<?php echo $this->get_field_id('number'); ?>"><?php _ae('How many entries to display?') ?></label>
        <input type="text" size="3" id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" value="<?php if (isset($instance['number'])) echo (int)$instance['number']; ?>" />
      </p>

      <p>
        <label for="<?php echo $this->get_field_id('avatar_size'); ?>"><?php _ae('Avatar Size:') ?></label>
        <input type="text" size="3" id="<?php echo $this->get_field_id('avatar_size'); ?>" name="<?php echo $this->get_field_name('avatar_size'); ?>" value="<?php if (isset($instance['avatar_size'])) echo (int)$instance['avatar_size']; ?>" /> <?php _ae("pixels"); ?>
      </p>

      <div class="template-selector clear-block">
        <div class="title"><?php _ae('Display mode') ?></div>
        <a href="#" class="select t-full" rel="full" title="<?php _ae("Full"); ?>"><?php _ae("Full"); ?></a>
        <a href="#" class="select t-detailed" rel="detailed" title="<?php _ae("Details"); ?>"><?php _ae("Details"); ?></a>
        <a href="#" class="select t-brief" rel="brief" title="<?php _ae("Brief"); ?>"><?php _ae("Brief"); ?></a>
        <a href="#" class="select t-images" rel="images" title="<?php _ae("Post thumbnails"); ?>"><?php _ae("Post thumbnails"); ?></a>
        <a href="#" class="select t-custom" rel="template" title="<?php _ae("Custom Template"); ?>"><?php _ae("Custom Template"); ?></a>
        <input class="select" type="hidden" value="<?php echo $instance['mode']; ?>" id="<?php echo $this->get_field_id('mode'); ?>" name="<?php echo $this->get_field_name('mode'); ?>" />
      </div>

      <?php if(current_user_can('edit_themes')): ?>
      <div class="user-template <?php if($instance['mode'] !== 'template') echo 'hidden'; ?>">
        <textarea class="wide code" id="<?php echo $this->get_field_id('template'); ?>" name="<?php echo $this->get_field_name('template'); ?>" rows="8" cols="28" mode="atom/html"><?php echo (empty($instance['template'])) ? format_to_edit($this->getTemplate()) : format_to_edit($instance['template']); ?></textarea>
        <small>
          <?php printf(_a("Read the %s to see all available keywords."), '<a href="'.Atom::THEME_DOC_URI.'" target="_blank">'._a("documentation").'</a>'); ?>
        </small>
      </div>
      <?php endif; ?>

    </div>
    <?php
  }

}