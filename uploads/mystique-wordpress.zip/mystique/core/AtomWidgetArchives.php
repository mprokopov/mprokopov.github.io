<?php

/**
 * Atom Archives Widget
 *
 * Similar to the default widget, but this one also allows the archive type / post type selection and count
 *
 * @todo maybe -- give more control over the output trough templates
 *
 * @since 1.0
 */



class AtomWidgetArchives extends AtomWidget{

  public function AtomWidgetArchives(){

    $this->WP_Widget('atom-archives', _a('Archives'), array('classname' => 'archives', 'description' => _a("Archives of your site's posts")));

    // default settings
    $this->setDefaults(array(
      'title'         => _a('Archives'),
      'type'          => 'monthly',
      'post_type'     => 'post',
      'limit'         => 12,
      'day_format'    => get_option('date_format'),
      'week_format'   => get_option('date_format'),
      'post_count'    => true,
      'dropdown'      => false,
    ));


    // flush cache when posts are changed
    add_action('save_post',       array(&$this, 'flushCache'));
    add_action('deleted_post',    array(&$this, 'flushCache'));    
  }

  public function flushCache(){
    wp_cache_delete('get_archives', 'atom');
  }


  // get results from the db; or from the cache if the query we're making was made before
  private function getResults($query){
    $key = md5($query);
    $cache = wp_cache_get('get_archives', 'atom');
    if(!isset($cache[$key])){
      $entries = $GLOBALS['wpdb']->get_results($query);
      $cache[$key] = $entries;
      wp_cache_set('get_archives', $cache, 'atom');
    }else{
      $entries = $cache[$key];
    }

    return empty($entries) ? array() : (array)$entries;
  }


  // displays archive links -- replaces wp_get_archives so we can use cpt and build our own markup
  private function getArchives($args = array()) {
    global $wpdb;

    $args = wp_parse_args($args, array(
      'type'        => 'monthly',
      'post_type'   => 'post',
      'limit'       => '',
      'day_format'  => 'Y/m/d',
      'week_format' => 'Y/m/d',
    ));

    extract($args, EXTR_SKIP);

    $limit = !empty($limit) ? ' LIMIT '.(int)$limit : '';

    // filters
    $where = apply_filters('getarchives_where', "WHERE post_type = '{$post_type}' AND post_status = 'publish'", $args);
    $join = apply_filters('getarchives_join', '', $args);

    $output = array();

    // month mode
    if($type === 'monthly'){
      $query = "SELECT YEAR(post_date) AS `year`, MONTH(post_date) AS `month`, count(ID) as posts FROM $wpdb->posts $join $where GROUP BY YEAR(post_date), MONTH(post_date) ORDER BY post_date DESC $limit";

      foreach($this->getResults($query) as $entry){
        $url = get_month_link($entry->year, $entry->month);
        if($post_type !== 'post') $url = add_query_arg('post_type', $post_type, $url);
        $output[] = array(
          'url'        => $url,
          'title'      => wptexturize(sprintf(_a('%1$s %2$d'), $GLOBALS['wp_locale']->get_month($entry->month), $entry->year)),  // month name + 4 digit year
          'post_count' => $entry->posts,
          'context'    => strtolower(date('F', mktime(0, 0, 0, $entry->month, 1, 0))),
        );
      }

    // year mode
    }elseif($type === 'yearly'){
      $query = "SELECT YEAR(post_date) AS `year`, count(ID) as posts FROM $wpdb->posts $join $where GROUP BY YEAR(post_date) ORDER BY post_date DESC $limit";

      foreach($this->getResults($query) as $entry){
        $url = get_year_link($entry->year);
        if($post_type !== 'post') $url = add_query_arg('post_type', $post_type, $url);
        $output[] = array(
          'url'        => $url,
          'title'      => sprintf('%d', $entry->year),  // 4 digit year
          'post_count' => $entry->posts,
          'context'    => "year-{$entry->year}",
        );
      }

    // day mode
    }elseif($type === 'daily'){
      $query = "SELECT YEAR(post_date) AS `year`, MONTH(post_date) AS `month`, DAYOFMONTH(post_date) AS `dayofmonth`, count(ID) as posts FROM $wpdb->posts $join $where GROUP BY YEAR(post_date), MONTH(post_date), DAYOFMONTH(post_date) ORDER BY post_date DESC $limit";

      foreach($this->getResults($query) as $entry){
        $url = get_day_link($entry->year, $entry->month, $entry->dayofmonth);
        if($post_type !== 'post') $url = add_query_arg('post_type', $post_type, $url);
        $output[] = array(
           'url'        => $url,
           'title'      => mysql2date($day_format, sprintf('%1$d-%2$02d-%3$02d 00:00:00', $entry->year, $entry->month, $entry->dayofmonth)),
           'post_count' => $entry->posts,
           'context'    => strtolower(mysql2date('l', sprintf('%1$d-%2$02d-%3$02d 00:00:00', $entry->year, $entry->month, $entry->dayofmonth))),
        );
      }

    // week mode
    }elseif($type === 'weekly'){
      $week = _wp_mysql_week('`post_date`');
      $query = "SELECT DISTINCT $week AS `week`, YEAR( `post_date` ) AS `yr`, DATE_FORMAT( `post_date`, '%Y-%m-%d' ) AS `yyyymmdd`, count( `ID` ) AS `posts` FROM `$wpdb->posts` $join $where GROUP BY $week, YEAR( `post_date` ) ORDER BY `post_date` DESC $limit";

      $arc_w_last = '';
      foreach($this->getResults($query) as $entry)
        if($entry->week != $arc_w_last){
          $arc_w_last = $entry->week;
          $arc_week = get_weekstartend($entry->yyyymmdd, get_option('start_of_week'));
          $arc_week_start = date_i18n($week_format, $arc_week['start']);
          $arc_week_end = date_i18n($week_format, $arc_week['end']);
          $url = sprintf('%1$s/%2$s%3$sm%4$s%5$s%6$sw%7$s%8$d', home_url(), '', '?', '=', $entry->yr, '&amp;', '=', $entry->week);
          if($post_type !== 'post') $url = add_query_arg('post_type', $post_type, $url);
          $output[] = array(
            'url'        => $url,
            'title'      => $arc_week_start.' &#8211; '.$arc_week_end,
            'post_count' => $entry->posts,
            'context'    => "week-{$entry->week}",
          );
        }

    }

    return $output;
  }

  public function widget($args, $instance){
    extract($args);
    $instance = wp_parse_args($instance, $this->getDefaults());
    $title = apply_filters('widget_title', $instance['title'], $instance, $this->id_base);

    $results = $this->getArchives(apply_filters('widget_archives_args', $instance));

    if(!$results) return
      Atom::app()->addDebugMessage("No entries of type &lt;{$instance['post_type']}&gt; were found in {$args['widget_id']} ({$args['widget_name']}). Widget marked as inactive");

    echo $before_widget;
    if($title) echo $before_title.$title.$after_title;

    $dropdown_labels = array(
      'daily'   => _a('Select Day:'),
      'weekly'  => _a('Select Week:'),
      'monthly' => _a('Select Month:'),
      'yearly'  => _a('Select Year:'),
    );

    $count = count($results);

    if($instance['dropdown']): // dropdown? ?>
    <div class="box">
    <select class="wide" name="archive-dropdown" onchange='document.location.href=this.options[this.selectedIndex].value;'>
       <option value=""><?php echo $dropdown_labels[$instance['type']]; ?></option>
       <?php foreach($results as $index => $entry): ?>
       <option value="<?php echo $entry['url']; ?>"><?php echo $entry['title']; ?> <?php if($instance['post_count']) echo "({$entry['post_count']})"; ?></option>
       <?php endforeach; ?>
    </select>
    </div>
    <?php else: ?>
    <ul class="menu fadeThis">
      <?php foreach($results as $index => $entry): ?>
      <li class="<?php echo sanitize_html_class($entry['context']); if($index == 0) echo ' first'; elseif($index == $count - 1) echo ' last' ?>">
        <a href="<?php echo esc_url($entry['url']); ?>"><?php echo $entry['title']; ?> <?php if($instance['post_count']) echo "({$entry['post_count']})"; ?></a>
      </li>
      <?php endforeach; ?>
    </ul>
    <?php endif;

    echo $after_widget;
  }

  public function update($new_instance, $old_instance){
    $instance = $old_instance;
    $instance['title']       = esc_attr($new_instance['title']);
    $instance['type']        = esc_attr($new_instance['type']);
    $instance['post_type']   = post_type_exists($new_instance['post_type']) ? $new_instance['post_type'] : 'post';
    $instance['limit']       = (int)$new_instance['limit'];
    $instance['day_format']  = esc_attr($new_instance['day_format']);
    $instance['week_format'] = esc_attr($new_instance['week_format']);
    $instance['post_count']  = (bool)$new_instance['post_count'];
    $instance['dropdown']    = (bool)$new_instance['dropdown'];
    return $instance;
  }

  public function form($instance){
    $instance = wp_parse_args($instance, $this->getDefaults());
    ?>
    <div <?php $this->formClass(); ?>>
      <p>
       <label for="<?php echo $this->get_field_id('title'); ?>"><?php _ae('Title:'); ?></label>
       <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($instance['title']); ?>" />
      </p>

      <?php
        /*
        $this->formAddTextfield('title', array(
           'label'    => _a('Title:'),
           'class'    => 'widefat',
           'value'    => $instance['title'],
        ));

        $this->formAddSelect('type', array(
           'label'    => _a('Type:'),
           'options'  => array(
                           'yearly'   => _a('Yearly'),
                           'monthly'  => _a('Monthly'),
                           'weekly'   => _a('Weekly'),
                           'daily'    => _a('Daily'),
                         ),
           'class'    => 'wide',
           'selected' => $instance['type'],
        ));

        $this->formAddCheckbox('dropdown', array(
           'label'    => _a('Show as dropdown'),
           'checked'  => isset($instance['dropdown']) ? (bool)$instance['dropdown'] : false,
        ));

        $this->formAddCheckbox('count', array(
           'label'    => _a('Show post count'),
           'checked'  => isset($instance['count']) ? (bool)$instance['count'] : false,
        ));
        */

       ?>

      <p>
       <label for="<?php echo $this->get_field_id('type'); ?>"><?php _ae('Type:'); ?></label>
       <select class="wide" id="<?php echo $this->get_field_id('type'); ?>" name="<?php echo $this->get_field_name('type'); ?>">
        <option value="yearly" <?php selected('yearly', esc_attr($instance['type'])) ?>><?php _ae("Yearly"); ?></option>
        <option value="monthly" <?php selected('monthly', esc_attr($instance['type'])) ?>><?php _ae("Monthly"); ?></option>
        <option value="weekly" <?php selected('weekly', esc_attr($instance['type'])) ?>><?php _ae("Weekly"); ?></option>
        <option value="daily" <?php selected('daily', esc_attr($instance['type'])) ?>><?php _ae("Daily"); ?></option>
       </select>
      </p>

      <p>
       <label for="<?php echo $this->get_field_id('post_type'); ?>"><?php _ae('Post Type:'); ?></label>
       <select id="<?php echo $this->get_field_id('post_type'); ?>" name="<?php echo $this->get_field_name('post_type'); ?>" class="wide" followRules>
         <?php foreach($GLOBALS['wp_post_types'] as $post_type => $data): ?>
          <?php if($data->public): ?>
          <option value="<?php echo esc_attr($post_type); ?>" <?php selected($instance['post_type'], $post_type); ?>><?php echo $data->label; ?></option>
          <?php endif; ?>
         <?php endforeach; ?>
       </select>
      </p>

      <p>
       <label for="<?php echo $this->get_field_id('limit'); ?>"><?php _ae('Limit to:'); ?></label><br />
       <input size="5" id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="text" value="<?php echo (int)$instance['limit']; ?>" /> <small><em><?php _ae("Entries"); ?></em></small>
      </p>

      <hr />

      <p>
       <input type="checkbox" <?php checked(isset($instance['post_count']) ? (bool)$instance['post_count'] : false); ?> id="<?php echo $this->get_field_id('post_count'); ?>" name="<?php echo $this->get_field_name('post_count'); ?>" />
       <label for="<?php echo $this->get_field_id('post_count'); ?>"><?php _ae('Show post count'); ?></label>
      </p>

      <p>
       <input type="checkbox" <?php checked(isset($instance['dropdown']) ? (bool)$instance['dropdown'] : false); ?> id="<?php echo $this->get_field_id('dropdown'); ?>" name="<?php echo $this->get_field_name('dropdown'); ?>" />
       <label for="<?php echo $this->get_field_id('dropdown'); ?>"><?php _ae('Show as dropdown'); ?></label>
      </p>

      <hr />

      <p>
       <label for="<?php echo $this->get_field_id('day_format'); ?>"><?php _ae('Day archive date format:'); ?></label>
       <input class="widefat" id="<?php echo $this->get_field_id('day_format'); ?>" name="<?php echo $this->get_field_name('day_format'); ?>" type="text" value="<?php echo esc_attr($instance['day_format']); ?>" />
      </p>

      <p>
       <label for="<?php echo $this->get_field_id('week_format'); ?>"><?php _ae('Week archive date format:'); ?></label>
       <input class="widefat" id="<?php echo $this->get_field_id('week_format'); ?>" name="<?php echo $this->get_field_name('week_format'); ?>" type="text" value="<?php echo esc_attr($instance['week_format']); ?>" />
      </p>

    </div>
    <?php
  }
}