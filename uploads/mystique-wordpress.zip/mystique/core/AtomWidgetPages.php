<?php

/**
 * Atom Pages Widget
 *
 * Show a list of pages based on the current context
 *
 * @todo add template system
 *
 * @since 1.0
 */



 
class AtomWidgetPages extends AtomWidget{

  public function AtomWidgetPages(){

    $this->WP_Widget('atom-pages', _a('Pages'), array('classname' => 'pages', 'description' => _a('Your site&#8217;s WordPress Pages')));

    // default settings
    $this->setDefaults(array(
      'type'      => 'all',
      'root'      => true,
      'child_of'  => 0,
      'sortby'    => 'menu_order',
      'title'     => _a("Pages"),
      'exclude'   => '',
      'depth'     => 0,
    ));
  }

  public function widget($args, $instance){
    extract($args);

    $instance = wp_parse_args($instance, $this->getDefaults());

    $title = apply_filters('widget_title', $instance['title'], $instance, $this->id_base);
    $sortby = empty($instance['sortby']) ? 'menu_order' : $instance['sortby'];
    $type = (empty($instance['type']) ? 'all' : esc_attr($instance['type']));

    // newest dates first
    $order = ($sortby == 'post_date' || $sortby == 'post_modified') ? 'DESC' : 'ASC';

    if($sortby == 'menu_order') $sortby = 'menu_order, post_title';

    $parent = 0;
    if($type == 'sub'):
      global $post;
      $parent = $post;
      if($instance['root']):
        while ($parent->post_parent != 0) $parent = &get_post($parent->post_parent);
        $title = '<a href="'.get_permalink($parent).'">'.$parent->post_title.'</a>';
      endif;
      $parent = $parent->ID;

    elseif($type == 'child'):
      $parent = $instance['child_of'];
    endif;

    $out = wp_list_pages(apply_filters('widget_pages_args',
      array(
        'title_li'     => '',
        'echo'         => 0,
        'sort_order'   => $order,
        'sort_column'  => $sortby,
        'depth'        => (int)$instance['depth'],
        'exclude'      => $instance['exclude'],
        'child_of'     => $parent,
      )));

    if(empty($out)) return
      Atom::app()->addDebugMessage("No pages found for the current context in {$args['widget_id']} ({$args['widget_name']}). Widget marked as inactive");

    echo $before_widget;
    if($title) echo $before_title.$title.$after_title;
    ?>
    <div class="box">
      <ul> <?php echo $out; ?> </ul>
    </div>
    <?php
    echo $after_widget;

  }

  public function update($new_instance, $old_instance){

    $instance['type']     = esc_attr($new_instance['type']);
    $instance['root']     = (bool)$new_instance['root'];
    $instance['child_of'] = (int)$new_instance['child_of'];
    $instance['title']    = esc_attr($new_instance['title']);
    $instance['sortby']   = esc_attr($new_instance['sortby']);
    $instance['exclude']  = esc_attr($new_instance['exclude']);
    $instance['depth']    = (int)$new_instance['depth'];
    return $instance;
  }

  public function form($instance){
    // defaults
    $instance = wp_parse_args($instance, $this->getDefaults());
    ?>
    <div <?php $this->formClass(); ?>>
      <div class="high-priority-block">
        <p><strong><?php _ae("Display:"); ?></strong></p>
        <label for="<?php echo $this->get_field_id('type'); ?>_all">
          <input id="<?php echo $this->get_field_id('type'); ?>_all" followRules name="<?php echo $this->get_field_name('type'); ?>" value="all" type="radio" <?php checked($instance['type'], 'all'); ?> />
          <?php _ae('All Pages'); ?>
        </label>
        <br />
        <label for="<?php echo $this->get_field_id('type'); ?>_sub">
          <input id="<?php echo $this->get_field_id('type'); ?>_sub" followRules name="<?php echo $this->get_field_name('type'); ?>" value="sub" type="radio" <?php checked($instance['type'], 'sub'); ?> />
          <?php _ae('Children of the active page'); ?>
        </label>
        <br />
        <input style="margin-left: 20px;" id="<?php echo $this->get_field_id('root'); ?>" name="<?php echo $this->get_field_name('root'); ?>" type="checkbox" <?php checked(isset($instance['root']) ? $instance['root'] : 0); ?> followRules rules="DEPENDS ON <?php echo $this->get_field_name('type'); ?> BEING sub" />
        <label for="<?php echo $this->get_field_id('root'); ?>"><?php _ae('Start from root'); ?></label>


        <br />
        <label for="<?php echo $this->get_field_id('type'); ?>_child">
          <input id="<?php echo $this->get_field_id('type'); ?>_child" name="<?php echo $this->get_field_name('type'); ?>" followRules value="child" type="radio" <?php checked($instance['type'], 'child'); ?> />
          <?php _ae('Children of:'); ?>
        </label>
        <br />
        <?php
         Atom::app()->Dropdown('page', array(
           'name'             => $this->get_field_name('child_of'),
           'id'               => $this->get_field_id('child_of'),
           'selected'         => (int)$instance['child_of'],
           'orderby'          => 'menu_order',
           'hierarchical'     => 1,
           'extra_attributes' => 'style="margin-left: 20px;" followRules rules="DEPENDS ON '.$this->get_field_name('type').' BEING child"',
         ));
        ?>

      </div>

      <p>
        <label for="<?php echo $this->get_field_id('title'); ?>"><?php _ae('Title:'); ?></label>
        <input class="wide" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($instance['title']); ?>" />
      </p>

      <p>
        <label for="<?php echo $this->get_field_id('sortby'); ?>"><?php _ae('Sort by:'); ?></label>
        <select name="<?php echo $this->get_field_name('sortby'); ?>" id="<?php echo $this->get_field_id('sortby'); ?>" class="wide">
          <option value="post_title" <?php selected($instance['sortby'], 'post_title'); ?>><?php _ae('Page title'); ?></option>
          <option value="menu_order" <?php selected($instance['sortby'], 'menu_order'); ?>><?php _ae('Page order'); ?></option>
          <option value="ID" <?php selected($instance['sortby'], 'ID'); ?>><?php _ae('Page ID'); ?></option>
          <option value="post_date" <?php selected($instance['sortby'], 'post_date'); ?>><?php _ae('Date, created'); ?></option>
          <option value="post_modified" <?php selected($instance['sortby'], 'post_modified'); ?>><?php _ae('Date, modified'); ?></option>
        </select>
      </p>

      <p>
        <label for="<?php echo $this->get_field_id('exclude'); ?>"><?php _ae('Exclude:'); ?></label>
        <input type="text" value="<?php echo esc_attr($instance['exclude']); ?>" name="<?php echo $this->get_field_name('exclude'); ?>" id="<?php echo $this->get_field_id('exclude'); ?>" class="wide" />
        <br />
        <small><?php _ae('Page IDs, separated by commas.'); ?></small>
      </p>

      <p>
        <label for="<?php echo $this->get_field_id('depth'); ?>"><?php _ae('Depth:'); ?></label>
        <input type="text" value="<?php echo (int)$instance['depth']; ?>" name="<?php echo $this->get_field_name('depth'); ?>" id="<?php echo $this->get_field_id('depth'); ?>" class="wide" />
        <br />
        <small><?php _ae('0 = All levels'); ?></small>
      </p>
    </div>
  <?php
  }
}