<?php

/**
 * Atom Blogs Widget
 *
 * A list of blogs hosted on this website.
 * This widget should only be active in MU mode on the first blog (root site)
 *
 * @since 1.3
 */


 
class AtomWidgetBlogs extends AtomWidget{

  function AtomWidgetBlogs(){

    $this->WP_Widget('atom-blogs', _a('Network Blogs'), array('classname' => 'blogs', 'description' => _a('A list of site blogs')), array('width' => 500));

    // set up default templates
    $this->registerTemplates(array(
      'full'     =>  "<a class=\"clear-block\" href=\"{URL}\" title=\"{TITLE}\">\n"
                    ." {AVATAR}\n"
                    ." <span class=\"base\">\n"
                    ."   <span class=\"tt\">{TITLE}</span>\n"
                    ."   <span class=\"c1\">{DESCRIPTION}</span>\n"
                    ."   <span class=\"c2\">Updated {UPDATED}</span>\n"
                    ." </span>\n"
                    ."</a>",
    ));

    // default settings
    $this->setDefaults(array(
      'title'          => _a("Recently updated blogs"),
      'order_by'       => 'last_updated',
      'number'         => 10,
      'exclude'        => '',
      'exclude_mature' => false,
      'avatar_size'    => 48,
      'more'           => true,
      'template'       => '',
    ));

    Atom::add('ajax_requests',       array(&$this, 'ajax'));

    // include in jQuery(document).ready()
    Atom::add('jquery_init',         array(&$this, 'js'));

    // flush cache when blog is updated
    add_action('wpmu_blog_updated',  array(&$this, 'flushCache'));
  }

   function js(){

    // we need to process all instances because this function gets to run only once
    $widget_options = get_option($this->option_name);

    foreach((array)$widget_options as $instance => $options){

      // identify instance
      $id = "{$this->id_base}-{$instance}";
      $block_id = "instance-{$id}";

      if(!is_active_widget(false, $id, $this->id_base)) continue;

      $options = wp_parse_args($options, AtomWidget::getObject($id)->getDefaults());
      if(isset($options['more']) && $options['more'])
        echo "\$('#{$block_id}').showMoreControl('{$instance}', 'get_blogs', '".Atom::app()->getNonce('get_blogs')."');\n";
    }
  }

  function ajax(){
    // not our request
    if(!Atom::app()->request('get_blogs')) return;

    Atom::app()->ajaxHeader('get_blogs', 'application/json');

    $settings = get_option($this->option_name);
    $instance = (int)$_GET['instance'];
    $settings = $settings[$instance];

    $offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
    $output = $this->getBlogs($settings, $next, $offset);
    $offset = $offset + $settings['number'];

    echo json_encode(array('output' => $output, 'more' => $next, 'offset' => $offset));
    die();
  }

  private function getBlogs($args, &$more, $offset = 0){
    extract($args);

    $sites = Atom::app()->getSites(array(
      'exclude_id'     => $exclude,
      'exclude_mature' => $exclude_mature,
      'sort_column'    => $order_by,
      'order'          => ($order_by === 'id') ? 'ASC' : 'DESC',
      'limit_results'  => $number + 1,
      'start'          => $offset
     ));

    // because mysql rand() is slowwwww
    if($order_by === 'rand') shuffle($sites);

    $more = count($sites) > $number ? true : false;
    $count = 1;
    $output = '';
    foreach((array)$sites as $site){

      if($count++ === $number + 1) break;
      $output .= '<li'.($count === 1 && $offset === 0  ? ' class="first"' : NULL).'>';

      $fields = array(
        'TITLE'        => get_blog_option($site['blog_id'], 'blogname'),
        'URL'          => get_blogaddress_by_domain($site['domain'], $site['path']), // should be faster than get_blog_option($site['blog_id'], 'siteurl'),
        'AVATAR'       => Atom::app()->getAvatar($site['email'], $avatar_size, ''),
        'POST_COUNT'   => get_blog_option($site['blog_id'], 'post_count'),
        'DESCRIPTION'  => convert_smilies(get_blog_option($site['blog_id'], 'blogdescription')),
        'UPDATED'      => Atom::app()->getTimeSince(abs(strtotime($site['last_updated']))),
        'REGISTERED'   => Atom::app()->getTimeSince(abs(strtotime($site['registered']))),
        'EMAIL'        => esc_url($site['email']), // should not be used
        'ID'           => $site['blog_id'],
      );

      $fields = apply_filters('atom_widget_blogs_keywords', $fields, $site, $args);

      // output template
      $output .= Atom::app()->getBlockTemplate($template, $fields);

      $output .= '</li>';
    }

    return $output;
  }

  function widget($args, $instance){

    extract($args, EXTR_SKIP);

    // check for a cached instance and display it if we have it
    if($this->getAndDisplayCache($widget_id)) return;

    $instance = wp_parse_args($instance, $this->getDefaults());
    $blogs = $this->getBlogs($instance, $next);
    if(!$blogs) return Atom::app()->addDebugMessage("No blogs found in {$args['widget_id']} ({$args['widget_name']}). Widget marked as inactive");

    $title = apply_filters('widget_title', $instance['title'], $instance, $this->id_base);

    $output = $before_widget;
    if($title) $output .= $before_title.$title.$after_title;

    $output .= "<ul class=\"menu full fadeThis blogs\">{$blogs}</ul>";
    if($instance['more'] && $next && Atom::app()->options('jquery'))
      $output .= "<div class=\"fadeThis clear-block\"><a href=\"#\" class=\"more\" data-count=\"{$instance['number']}\">"._a("Show More")."</a></div>";

    $output .= $after_widget;

    echo $output;

    $this->addCache($widget_id, $output);
  }

  function update($new_instance, $old_instance){

    $instance['title']          = esc_attr($new_instance['title']);
    $instance['order_by']       = esc_attr($new_instance['order_by']);
    $instance['number']         = min(max((int)$new_instance['number'], 1), 20);
    $instance['exclude']        = esc_attr($new_instance['exclude']);
    $instance['exclude_mature'] = (bool)$new_instance['exclude_mature'];
    $instance['avatar_size']    = (int)$new_instance['avatar_size'];
    $instance['more']           = (bool)$new_instance['more'];

    // html template
    if(current_user_can('edit_themes')) $instance['template'] = $new_instance['template'];

    $this->flushCache();
    return $instance;
  }

  function form($instance){
    $instance = wp_parse_args($instance, $this->getDefaults());
    ?>
    <div <?php $this->formClass(); ?>>

      <p>
       <label for="<?php echo $this->get_field_id('title'); ?>"><?php _ae('Title:'); ?></label>
       <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php if (isset($instance['title'])) echo esc_attr($instance['title']); ?>" />
      </p>

      <p>
        <label for="<?php echo $this->get_field_id('order_by'); ?>"><?php _ae('Order by:') ?></label>
        <select id="<?php echo $this->get_field_id('order_by'); ?>" name="<?php echo $this->get_field_name('order_by'); ?>">
         <option value="last_updated" <?php selected($instance['order_by'], "last_updated"); ?>><?php _ae("Last Update"); ?></option>
         <option value="registered" <?php selected($instance['order_by'], "registered"); ?>><?php _ae("Registered Date"); ?></option>
         <option value="id" <?php selected($instance['order_by'], "id"); ?>><?php _ae("Site ID"); ?></option>
         <option value="rand" <?php selected($instance['order_by'], "rand"); ?>><?php _ae("Nothing, Randomize"); ?></option>
        </select>
      </p>

      <p>
       <label for="<?php echo $this->get_field_id('number'); ?>"><?php _ae('How many entries to display?'); ?></label>
       <input id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="text" value="<?php if (isset($instance['number'])) echo (int)$instance['number']; ?>" size="3" />
      </p>

      <p>
        <label for="<?php echo $this->get_field_id('exclude'); ?>"><?php _ae('Exclude:'); ?></label> <input type="text" value="<?php echo esc_attr($instance['exclude']); ?>" name="<?php echo $this->get_field_name('exclude'); ?>" id="<?php echo $this->get_field_id('exclude'); ?>" class="widefat" />
        <br />
        <small><?php _ae('Site IDs, separated by commas.'); ?></small>
      </p>

      <p>
       <label for="<?php echo $this->get_field_id('exclude_mature'); ?>">
       <input type="checkbox" id="<?php echo $this->get_field_id('exclude_mature'); ?>" name="<?php echo $this->get_field_name('exclude_mature'); ?>"<?php checked($instance['exclude_mature']); ?> />
   	   <?php _ae('Exclude sites marked as mature'); ?></label>
      </p>

      <p>
        <label for="<?php echo $this->get_field_id('avatar_size'); ?>"><?php _ae('Avatar Size:') ?></label>
        <input type="text" size="3" id="<?php echo $this->get_field_id('avatar_size'); ?>" name="<?php echo $this->get_field_name('avatar_size'); ?>" value="<?php if (isset($instance['avatar_size'])) echo esc_attr($instance['avatar_size']); ?>" /> <?php _ae("pixels"); ?>
      </p>

      <p>
       <label for="<?php echo $this->get_field_id('more'); ?>" <?php if(!Atom::app()->options('jquery')) echo "class=\"disabled\""; ?>>
       <input <?php if(!Atom::app()->options('jquery')) echo "disabled=\"disabled\""; ?> type="checkbox" id="<?php echo $this->get_field_id('more'); ?>" name="<?php echo $this->get_field_name('more'); ?>"<?php checked($instance['more']); ?> />
       <?php printf(_a('Display %s Link'), '<code>'._a("Show More").'</code>'); ?></label>
      </p>

      <?php if(current_user_can('edit_themes')): ?>
      <div class="user-template">
        <textarea class="wide code" id="<?php echo $this->get_field_id('template'); ?>" name="<?php echo $this->get_field_name('template'); ?>" rows="8" cols="28" mode="atom/html"><?php echo (empty($instance['template'])) ? format_to_edit($this->getTemplate()) : format_to_edit($instance['template']); ?></textarea>
        <small>
          <?php printf(_a("Read the %s to see all available keywords."), '<a href="'.Atom::THEME_DOC_URI.'" target="_blank">'._a("documentation").'</a>'); ?>
        </small>
      </div>
      <?php endif; ?>

    </div>
  <?php
  }
}