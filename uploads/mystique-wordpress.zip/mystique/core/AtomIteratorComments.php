<?php

// "comments" iterator - @todo
// will replace WP's walker (should offer more flexibility in templating and maybe a little more speed?)

class AtomIteratorComments extends AtomIterator{

  public function current(){
    return new AtomObjectComment($this->list[$this->position]);
  }

}