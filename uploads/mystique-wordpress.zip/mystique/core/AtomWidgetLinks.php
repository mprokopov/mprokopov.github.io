<?php

/**
 * Atom Links Widget
 *
 * Displays a list of links, like the blogroll
 *
 * @since 1.0
 * @todo Add link category class to list (remove 'blogroll')
 * @todo Add RSS option
 * @todo Add template option
 * @todo maybe- group into multiple widgets when "all categories" are selected
 */


 
class AtomWidgetLinks extends AtomWidget{

  public function AtomWidgetLinks() {

    $this->WP_Widget('atom-links', _a('Links'), array('classname' => 'links', 'description' => _a("Your blogroll/links")));

    // default settings
    $this->setDefaults(array(
      'title'          => _a("Blogroll"),
      'category'       => '',
      'order_by'       => 'name',
      'hide_invisible' => true,
      'image'          => false,
      'rating'         => true,
      'description'    => true,
      'limit'          => 24,
    ));
  }

  public function widget($args, $instance){
    extract($args);
    $instance = wp_parse_args($instance, $this->getDefaults());
    $title = apply_filters('widget_title', $instance['title'], $instance, $this->id_base);

    $query_args = array(
      'category'       => $instance['category'],
      'orderby'        => $instance['order_by'],
      'order'          => ($instance['order_by'] == 'rating' ? 'DESC' : 'ASC'),
      'limit'          => (int)$instance['limit'],
      'hide_invisible' => (bool)$instance['hide_invisible'],
    );

    $links = get_bookmarks($query_args);

    echo $before_widget;
    if ($title) echo $before_title.$title.$after_title;

    $output = '';
    foreach ($links as $link):
      $output .= '<li><a href="'.esc_url($link->link_url).'"';
      if($t = esc_attr($link->link_target)) $output .= " target=\"{$t}\"";
      if($r = esc_attr($link->link_rel)) $output .= " target=\"{$r}\"";
      $output .= '>';
      $output .= '<span class="base">'.($n = esc_attr($link->link_name));
      if($instance['description'] && $link->link_description) $output .= '<span class="c1">'.esc_attr($link->link_description).'</span>';
      if($instance['image'] && ($i = esc_url($link->link_image)))
        $output .= '<img class="c1" src="'.$i.'" alt="'.$n.'" />';
      if($instance['rating'] && ($r = (int)$link->link_rating))
        $output .= '<span class="rating" title="'.sprintf(_a("%s out of 10"), $r).'"><span class="bar" style="width:'.($r * 10).'%">'.$r.'/10</span></span>';
      $output .= '</span></a></li>';
    endforeach;
    if($output) echo "<ul class=\"menu fadeThis blogroll\">{$output}</ul>";
    else echo '<em>'._a("No links yet :(").'</em>';

    echo $after_widget;
  }

  public function update($new_instance, $old_instance){

    $instance['title']          = esc_attr($new_instance['title']);
    $instance['category']       = esc_attr($new_instance['category']);
    $instance['order_by']       = esc_attr($new_instance['order_by']);
    $instance['hide_invisible'] = (bool)$new_instance['hide_invisible'];
    $instance['image']          = (bool)$new_instance['image'];
    $instance['rating']         = (bool)$new_instance['rating'];
    $instance['description']    = (bool)$new_instance['description'];
    $instance['limit']          = (int)$new_instance['limit'];
    return $instance;
  }

  public function form($instance){
    $instance = wp_parse_args($instance, $this->getDefaults());
    ?>
    <div <?php $this->formClass(); ?>>
      <p>
       <label for="<?php echo $this->get_field_id('title'); ?>"><?php _ae('Title:'); ?></label>
       <input class="wide" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($instance['title']); ?>" />
      </p>

      <p>
       <label for="<?php echo $this->get_field_id('category'); ?>"><?php _ae('Link Category:'); ?></label>
       <select class="wide" id="<?php echo $this->get_field_id('category'); ?>" name="<?php echo $this->get_field_name('category'); ?>">
        <option value="" <?php selected('', esc_attr($instance['category'])) ?>><?php _ae("-- All categories --"); ?></option>
        <?php
          $categories = get_terms('link_category');
          foreach ($categories as $category)
          echo '<option value="'.(int)$category->term_id.'"'.($category->term_id == $instance['category'] ? ' selected="selected"' : '').'>'.$category->name."</option>\n";
        ?>
       </select>
      </p>

      <p>
       <label for="<?php echo $this->get_field_id('order_by'); ?>"><?php _ae('Order by:'); ?></label>
       <select class="wide" id="<?php echo $this->get_field_id('order_by'); ?>" name="<?php echo $this->get_field_name('order_by'); ?>">
        <option value="name" <?php selected('name', esc_attr($instance['order_by'])) ?>><?php _ae("Name"); ?></option>
        <option value="rating" <?php selected('rating', esc_attr($instance['order_by'])) ?>><?php _ae("Rating"); ?></option>
        <option value="url" <?php selected('url', esc_attr($instance['order_by'])) ?>><?php _ae("URL"); ?></option>
        <option value="ID" <?php selected('ID', esc_attr($instance['order_by'])) ?>><?php _ae("ID"); ?></option>
        <option value="owner" <?php selected('owner', esc_attr($instance['order_by'])) ?>><?php _ae("Owner"); ?></option>
        <option value="notes" <?php selected('notes', esc_attr($instance['order_by'])) ?>><?php _ae("Notes"); ?></option>
        <option value="description" <?php selected('description', esc_attr($instance['order_by'])) ?>><?php _ae("Description"); ?></option>
       </select>
      </p>

      <p>
       <input type="checkbox" <?php checked(isset($instance['hide_invisible']) ? (bool)$instance['hide_invisible'] : false); ?> id="<?php echo $this->get_field_id('hide_invisible'); ?>" name="<?php echo $this->get_field_name('hide_invisible'); ?>" />
       <label for="<?php echo $this->get_field_id('hide_invisible'); ?>"><?php _ae('Hide Private Links'); ?></label>

       <br />

       <input type="checkbox" <?php checked(isset($instance['image']) ? (bool)$instance['image'] : false); ?> id="<?php echo $this->get_field_id('image'); ?>" name="<?php echo $this->get_field_name('image'); ?>" />
       <label for="<?php echo $this->get_field_id('image'); ?>"><?php _ae('Display Link Image'); ?></label>

       <br />

       <input type="checkbox" <?php checked(isset($instance['rating']) ? (bool)$instance['rating'] : false); ?> id="<?php echo $this->get_field_id('rating'); ?>" name="<?php echo $this->get_field_name('rating'); ?>" />
       <label for="<?php echo $this->get_field_id('rating'); ?>"><?php _ae('Display Link Rating'); ?></label>

       <br />

       <input type="checkbox" <?php checked(isset($instance['description']) ? (bool)$instance['description'] : false); ?> id="<?php echo $this->get_field_id('description'); ?>" name="<?php echo $this->get_field_name('description'); ?>" />
       <label for="<?php echo $this->get_field_id('description'); ?>"><?php _ae('Display Link Description'); ?></label>
      </p>

      <p>
       <label for="<?php echo $this->get_field_id('limit'); ?>"><?php _ae('Limit to:'); ?></label><br />
       <input size="5" id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="text" value="<?php echo (int)$instance['limit']; ?>" /> <small><em><?php _ae("Links"); ?></em></small>
      </p>
    </div>
    <?php
  }
}