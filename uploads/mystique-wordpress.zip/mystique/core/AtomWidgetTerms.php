<?php

/**
 * Atom Terms Widget
 *
 * Display a list of taxonomy terms
 *
 * @since 1.0
 *
 * @todo: test custom taxanomy dropdown
 */



class AtomWidgetTerms extends AtomWidget{

  public function AtomWidgetTerms(){

    $this->WP_Widget('atom-terms', _a('Terms'), array('classname' => 'terms', 'description' => _a("A list of taxonomy terms like categories or post tags")), array('width' => 500));

    // set up default templates
    $this->registerTemplates(array(
      'full'  =>  "<a class=\"clear-block\" href=\"{URL}\" title=\"".sprintf(_a('View all posts filed under %s'), '{NAME}')."\">\n"
                 ." <span class=\"tt\">{NAME} <strong>({POST_COUNT})</strong></span>\n"
                 ." <span class=\"c1\">{DESCRIPTION}</span>\n"
                 ."</a>",
    ));

    // default settings
    $this->setDefaults(array(
      'title'                  => _a("Categories"),
      'taxonomy'               => 'category',
      'type'                   => 'all',
      'root'                   => true,
      'dropdown'               => 0,
      'hierarchical'           => 1,
      'hide_empty'             => 1,
      'order_by'               => 'name',
      'depth'                  => 0,
      'exclude'                => '',
      'template'               => '',

      // internal settings
      'description_word_limit' => 10,
      'allowed_tags'           => 'abbr,acronym,b,cite,code,del,dfn,em,i,ins,q,strong,sub,sup',
      'content_filter_more'    => '[&hellip;]',
    ));
  }

  /* gets all term ancestors (if taxonomy is hierarchical) */
  /* part of the code snatched from: http://core.trac.wordpress.org/attachment/ticket/12443/get_ancestors.2.12443.diff */
  /* the complete function should be available in 3.1 */
  private function getAncestors($id = 0, $taxonomy = 'category') {
    $ancestors = array();
    if(is_taxonomy_hierarchical($taxonomy)){
      $term = get_term($id, $taxonomy);
      while (!is_wp_error($term) && !empty($term->parent) && !in_array($term->parent, $ancestors)){
        $ancestors[] = (int) $term->parent;
        $term = get_term($term->parent, $taxonomy);
      }
    }

    return $ancestors;
  }

  public function termEntry($term, $args, $depth){
    $description = convert_smilies(Atom::app()->getFilteredContent(apply_filters('category_description', $term->description, $term), array(
      'limit'        => (int)$args['description_word_limit'],
      'allowed_tags' => explode(',', $args['allowed_tags']),
      'more'         => $args['content_filter_more']
    )));

    $fields = array(
      'NAME'        => apply_filters('list_cats', esc_attr($term->name), $term),
      'URL'         => get_term_link($term, $term->taxonomy),
      'POST_COUNT'  => (int)$term->count,
      'DESCRIPTION' => $description,
      'ID'          => $term->term_id,
      'RSS'         => !empty($feed) ? get_term_feed_link($term->term_id, $term->taxonomy, $feed_type) : NULL
    );

    $fields = apply_filters('atom_widget_terms_keywords', $fields, $term, $args);

    return Atom::app()->getBlockTemplate($args['template'], $fields);
  }

  public function widget($args, $instance){
    global $wp_query;

    extract($args);
    $instance = wp_parse_args($instance, $this->getDefaults());

    $title = apply_filters('widget_title', $instance['title'], $instance, $this->id_base);

    if($instance['type'] == 'sub' && is_taxonomy_hierarchical($instance['taxonomy'])){
      // only show on pages where the current category is set

      if (((($instance['taxonomy'] == 'category') && is_category()) || is_tax($instance['taxonomy'] || is_single())) === false)
        return Atom::app()->addDebugMessage("Current category doesn't have children categories requested by {$args['widget_id']} ({$args['widget_name']}). Widget marked as inactive");

      // $root = get_query_var('cat');
      $active_term = $wp_query->get_queried_object();
      $ancestor = end($this->getAncestors($active_term->term_id, $instance['taxonomy']));

      $root = ($instance['root'] && $ancestor) ? $ancestor : $active_term->term_id;

      $term = get_term($root, $instance['taxonomy']);

      $title = '<a href="'.get_term_link($term, $instance['taxonomy']).'">'.$term->name.'</a>';
    }

    echo $before_widget;
    if($title) echo $before_title.$title.$after_title;

    $query_args = array(
      'child_of'               => isset($root) ? $root : 0,
      'orderby'                => $instance['order_by'],
      'hierarchical'           => $instance['hierarchical'] ? '1' : '0',
      'taxonomy'               => $instance['taxonomy'],
      'hide_empty'             => $instance['hide_empty'] ? '1' : '0',
      'title_li'               => '',
      'exclude'                => $instance['exclude'],
      'depth'                  => $instance['depth'],
      'walker'                 => $instance['dropdown'] ? '' : new AtomWalkerTerms(),
      'link-callback'          => array(&$this, 'termEntry'),
      'template'               => $instance['template'],
      'description_word_limit' => $instance['description_word_limit'],
      'allowed_tags'           => $instance['allowed_tags'],
      'content_filter_more'    => $instance['content_filter_more'],
    );
    if($instance['order_by'] == 'count')
      $query_args['order'] = 'DESC';

    $tax = get_taxonomy($instance['taxonomy']);

    if($instance['dropdown'] ? '1' : '0'):
      $query_args['show_option_none'] = $tax->label.':';
      $query_args['class'] = 'wide';
      $query_args['name'] = $this->id.'_terms';
      $query_args['id'] = $this->id.'_terms';
      wp_dropdown_categories(apply_filters('widget_categories_dropdown_args', $query_args));
    ?>

    <script type='text/javascript'>
      /* <![CDATA[ */
      var dropdown = document.getElementById("<?php echo $this->id; ?>_terms");
      function onCatChange(){
       if (dropdown.options[dropdown.selectedIndex].value > 0)
        location.href = "<?php echo home_url(); ?>/?<?php echo ($instance['taxonomy'] == 'category' ? 'cat' : 'term_id'); ?>="+dropdown.options[dropdown.selectedIndex].value;
      }
      dropdown.onchange = onCatChange;
      /* ]]> */
    </script>

    <?php else: ?>
    <ul class="menu fadeThis">
     <?php wp_list_categories(apply_filters('widget_categories_args', $query_args)); ?>
    </ul>
    <?php
    endif;

    echo $after_widget;
  }

  public function update($new_instance, $old_instance){

    $instance['title']        = esc_attr($new_instance['title']);
    $instance['taxonomy']     = esc_attr($new_instance['taxonomy']);
    $instance['type']         = esc_attr($new_instance['type']);
    $instance['root']         = (bool)$new_instance['root'];
    $instance['hierarchical'] = (bool)$new_instance['hierarchical'];
    $instance['dropdown']     = (bool)$new_instance['dropdown'];
    $instance['hide_empty']   = (bool)$new_instance['hide_empty'];
    $instance['order_by']     = esc_attr($new_instance['order_by']);
    $instance['depth']        = (int)$new_instance['depth'];
    $instance['exclude']      = esc_attr($new_instance['exclude']);

    // html template
    if(current_user_can('edit_themes')) $instance['template'] = $new_instance['template'];

    return $instance;
  }

  public function form($instance){
    $instance = wp_parse_args($instance, $this->getDefaults());
    ?>
    <div <?php $this->formClass(); ?>>
      <div class="high-priority-block">
        <p><strong><?php _ae("Display:"); ?></strong></p>
        <label for="<?php echo $this->get_field_id('type'); ?>_all">
          <input id="<?php echo $this->get_field_id('type'); ?>_all" name="<?php echo $this->get_field_name('type'); ?>" followRules value="all" type="radio" <?php checked($instance['type'], 'all'); ?> />
          <?php _ae('All Terms'); ?>
        </label>
        <br />
        <label for="<?php echo $this->get_field_id('type'); ?>_sub">
          <input id="<?php echo $this->get_field_id('type'); ?>_sub" name="<?php echo $this->get_field_name('type'); ?>" followRules value="sub" type="radio" <?php checked($instance['type'], 'sub'); ?> />
          <?php _ae('Children of the active term'); ?>
        </label>
        <br />
        <input style="margin-left: 20px;" id="<?php echo $this->get_field_id('root'); ?>" name="<?php echo $this->get_field_name('root'); ?>" type="checkbox" <?php checked(isset($instance['root']) ? $instance['root'] : 0); ?> followRules rules="DEPENDS ON <?php echo $this->get_field_name('type'); ?> BEING sub" />
        <label for="<?php echo $this->get_field_id('root'); ?>"><?php _ae('Start from root'); ?></label>

        <?php /*/ child of @todo ?>
        <br />
        <label for="<?php echo $this->get_field_id('child'); ?>_child">
          <input id="<?php echo $this->get_field_id('child'); ?>_child" name="<?php echo $this->get_field_name('child'); ?>" followRules value="child" type="radio" <?php checked($instance['child'], 'child'); ?> />
          <?php _ae('Children of'); ?>
        </label>
        <br />

        <?php
         $fc = Atom::app()->getDropdown('category', array(
           'name' => $this->get_field_name('child_of'),
           'id' => $this->get_field_id('child_of'),
           'selected' => (int)$instance['child_of'],
           'show_option_all' => _a('-- All categories --'),
           'hide_empty' => 0,
           'orderby' => 'name',
           'show_count' => 1,          
           'hierarchical' => 1,
           'extra_attributes' => 'followRules rules="DEPENDS ON '.$this->get_field_name('type').' BEING child"',
         ));
        ?>

        <input style="margin-left: 20px;" id="<?php echo $this->get_field_id('root'); ?>" name="<?php echo $this->get_field_name('root'); ?>" type="checkbox" <?php checked(isset($instance['root']) ? $instance['root'] : 0); ?> followRules rules="DEPENDS ON <?php echo $this->get_field_name('type'); ?> BEING child" />
        <label for="<?php echo $this->get_field_id('root'); ?>"><?php _ae('Start from root'); ?></label>
        <?php //*/ ?>

      </div>

      <p>
       <label for="<?php echo $this->get_field_id('title'); ?>"><?php _ae('Title:'); ?></label>
       <input class="wide" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($instance['title']); ?>" />
      </p>

      <p>
       <label for="<?php echo $this->get_field_id('taxonomy'); ?>"><?php _ae('Taxonomy:'); ?></label>
       <select class="wide" id="<?php echo $this->get_field_id('taxonomy'); ?>" name="<?php echo $this->get_field_name('taxonomy'); ?>">
        <?php foreach(get_taxonomies(array('public' => true)) as $taxonomy):
          $tax = get_taxonomy($taxonomy);
          if (empty($tax->labels->name)) continue; ?>
        <option value="<?php echo esc_attr($taxonomy) ?>" <?php selected($taxonomy, esc_attr($instance['taxonomy'])) ?>><?php echo $tax->labels->name; ?></option>
        <?php endforeach; ?>
       </select>
      </p>

      <p>
       <input type="checkbox" id="<?php echo $this->get_field_id('dropdown'); ?>" name="<?php echo $this->get_field_name('dropdown'); ?>" <?php checked(isset($instance['dropdown']) ? (bool)$instance['dropdown'] : false); ?> />
       <label for="<?php echo $this->get_field_id('dropdown'); ?>"><?php _ae('Show as dropdown'); ?></label>
       <br />
       <input type="checkbox" id="<?php echo $this->get_field_id('hierarchical'); ?>" name="<?php echo $this->get_field_name('hierarchical'); ?>" <?php checked(isset($instance['hierarchical']) ? (bool)$instance['hierarchical'] : false); ?> />
       <label for="<?php echo $this->get_field_id('hierarchical'); ?>"><?php _ae('Hierarchical?'); ?></label>
       <br />
       <input type="checkbox" id="<?php echo $this->get_field_id('hide_empty'); ?>" name="<?php echo $this->get_field_name('hide_empty'); ?>" <?php checked(isset($instance['hide_empty']) ? (bool)$instance['hide_empty'] : false); ?> />
       <label for="<?php echo $this->get_field_id('hide_empty'); ?>"><?php _ae('Hide empty?'); ?></label>
      </p>

      <p>
       <label for="<?php echo $this->get_field_id('order_by'); ?>"><?php _ae('Order by:'); ?></label>
       <select class="wide" id="<?php echo $this->get_field_id('order_by'); ?>" name="<?php echo $this->get_field_name('order_by'); ?>">
        <option value="name" <?php selected('name', esc_attr($instance['order_by'])) ?>><?php _ae("Name"); ?></option>
        <option value="count" <?php selected('count', esc_attr($instance['order_by'])) ?>><?php _ae("Post count, descending"); ?></option>
        <option value="ID" <?php selected('ID', esc_attr($instance['order_by'])) ?>><?php _ae("ID"); ?></option>
        <option value="slug" <?php selected('slug', esc_attr($instance['order_by'])) ?>><?php _ae("Slug"); ?></option>
       </select>
      </p>

      <p>
       <label for="<?php echo $this->get_field_id('exclude'); ?>"><?php _ae('Exclude (IDs separated by comma):'); ?></label>
       <input class="wide" id="<?php echo $this->get_field_id('exclude'); ?>" name="<?php echo $this->get_field_name('exclude'); ?>" type="text" value="<?php echo esc_attr($instance['exclude']); ?>" />
      </p>

      <p>
        <label for="<?php echo $this->get_field_id('depth'); ?>"><?php _ae('Depth:'); ?></label> <input type="text" value="<?php echo (int)$instance['depth']; ?>" name="<?php echo $this->get_field_name('depth'); ?>" id="<?php echo $this->get_field_id('depth'); ?>" class="wide" />
        <br />
        <small><?php _ae('0 = All levels'); ?></small>
      </p>

      <?php if(current_user_can('edit_themes')): ?>
      <strong><?php _ae('Template:'); ?></strong>
      <div class="user-template">
        <textarea class="wide code" id="<?php echo $this->get_field_id('template'); ?>" name="<?php echo $this->get_field_name('template'); ?>" rows="8" cols="28" mode="atom/html"><?php echo (empty($instance['template'])) ? format_to_edit($this->getTemplate()) : format_to_edit($instance['template']); ?></textarea>
        <small>
          <?php printf(_a("Read the %s to see all available keywords."), '<a href="'.Atom::THEME_DOC_URI.'" target="_blank">'._a("documentation").'</a>'); ?>
        </small>
      </div>
      <?php endif; ?>
    </div>
    <?php
  }

}