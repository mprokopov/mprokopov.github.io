<?php
/**
 * AtomWidget class - designed to make widget programming easier
 *
 * @since 1.7
 */


class AtomWidget extends WP_Widget{

  // the folder name which stores user-uploaded widget icons
  const USER_ICON_DIR = 'widget-icons';

  private
    $defaults,     // stores default options for this widget (not to be confused with the current widget instance options)
    $templates,    // widget template blocks
    $cache,        // widget cache for all instances (only used by widgets that need it)
    $icons;        // caches user uploaded icon list



  /**
   * Register default widget options
   *
   * @since 1.7
   *
   * @param array $options Options
   */
  final public function setDefaults($options){
    $this->defaults = $options;
  }



  /**
   * Retrieve default widget options.
   * It will call getContextArgs() and check if user-defined options exist, and merge them.
   *
   * @since 1.7
   *
   * @return array Options
   */
  final public function getDefaults(){
    $widget = str_replace('-', '_', $this->widget_options['classname']);
    return Atom::app()->getContextArgs("widget_{$widget}_defaults", $this->defaults);
  }



  /**
   * Register a widget template.
   * uses getContextArgs() to check for user-defined templates
   *
   * @since 1.7
   *
   * @param array Templates
   */
  final public function registerTemplates($templates){
    foreach($templates as $name => $template)
      $this->templates[$name] = $template;

    $widget = str_replace('-', '_', $this->id_base); // eg. "atom-name-of-the-widget"
    $this->templates = Atom::app()->getContextArgs("widget_{$widget}_templates", $this->templates);
  }



  /**
   * Retrieve a widget template
   * It will call getContextArgs() and check if user-defined options exist, and merge them.
   *
   * @since 1.7
   *
   * @param $name Name of the template to get
   */
  final public function getTemplate($name = 'full'){
    if(isset($this->templates[$name])) return $this->templates[$name]; else return array_shift($this->templates);
  }



  /**
   * Get all templates -- @todo
   *
   * @since 1.7
   *
   * @return array
   */
  final public function getTemplates(){
    return $this->templates;
  }



  /**
   * Widget form class - hides the form if the widget instance doesn't appear initialized (the wp-save bug...)
   *
   * @since 1.7
   */
  final public function formClass(){
    // hide widget if it doesn't appear initialized
    echo 'class="'.(is_numeric($this->number) ? "atom-block {$this->id}" : "hidden").'"';
  }



  /**
   * Get the output for a widget instance from the cache and display it on the screen.
   * Return false if it doesn't exist.
   *
   * @since 1.7
   *
   * @param string $instance_id Widget instance ID; $args['id'] inside widget()
   * @return bool
   */
  public function getAndDisplayCache($instance_id){
    $widget = str_replace('-', '_', $this->widget_options['classname']);

    // only call this once per widget class
    if(!is_array($this->cache))
      $this->cache = wp_cache_get("widget_{$widget}", 'widget');

    if(isset($this->cache[$instance_id])){
      echo $this->cache[$instance_id];
      return true;
    }

    // no cache
    return false;
  }



  /**
   * Add the output of a widget instance in the cache
   *
   * @since 1.7
   *
   * @param string $instance_id Widget instance ID; $args['id'] inside widget()
   * @param string $output Widget output
   */
  public function addCache($instance_id, $output = ''){
    $widget = str_replace('-', '_', $this->widget_options['classname']);
    $this->cache[$instance_id] = $output;
    wp_cache_set("widget_{$widget}", $this->cache, 'widget');
  }



  /**
   * Removes the cache records for a widget (all instances).
   *
   * @since 1.7
   */
  public function flushCache($instance_id = false){
    $widget = str_replace('-', '_', $this->widget_options['classname']);
    wp_cache_delete("widget_{$widget}", 'widget');
    unset($this->cache);
  }



  /**
   * Get the callback of a widget.
   * This function handles the "fixes" for Widget Context / Widget Logic
   *
   * @since 1.7
   */
  public static function getCallback($widget_id){
    global $wp_registered_widgets;

    // widget logic
    if(!empty($wp_registered_widgets[$widget_id]['callback_wl_redirect']))
      return $wp_registered_widgets[$widget_id]['callback_wl_redirect'];

    // widget context
    elseif(!empty($wp_registered_widgets[$widget_id]['callback_original_wc']))
      return $wp_registered_widgets[$widget_id]['callback_original_wc'];

    // original
    elseif(!empty($wp_registered_widgets[$widget_id]['callback']))
      return $wp_registered_widgets[$widget_id]['callback'];


    return false;
  }



  /**
   * Get the callback of a widget.
   * This function handles the "fixes" for Widget Context / Widget Logic
   *
   * @since 1.7
   */
  public static function getObject($widget_id){
    $callback = AtomWidget::getCallback($widget_id);

    if(isset($callback[0]))
      return $callback[0];

    return false;
  }



  /**
   * Get the default icon for the given widget
   *
   * @param string $instance Widget instance
   * @since 1.8
   */
  public function getDefaultIcon($instance){

    // default icons.png sprite (all themes should follow this order):
    //
    //  0 = default
    //  1 = star
    //  2 = comment
    //  3 = time
    //  4 = tag
    //  5 = user
    //  6 = search
    //  7 = lock
    //  8 = bird
    //  9 = calendar
    // 10 = folder

    // check if widget is registered (eg. missing widget - plugin is removed)
    $callback = AtomWidget::getObject($instance);
    if(!$callback) return '';

    // get the widget instance settings
    $options = get_option($callback->option_name);
    $options = $options[$wp_registered_widgets[$instance]['params'][0]['number']];

    // parse defaults for atom widgets
    if(method_exists($callback, 'getDefaults'))
      $options = wp_parse_args($options, $callback->getDefaults());

    // generate css classes, that can be used for styling the tabs with things like icons
    $id = $callback->id_base;

    if($id === 'atom-splitter') return ''; // no splitters here

    $icon = 0;
    $classes = array();


   // add extra relevant classes based on widget options from certain Atom widgets
        // this is to allow different styling for widgets of the same type inside the tabs (for eg. recent/popular/random posts)
        switch($id){

          // order + post type, if different than "post" + related if checked + category if different than 0 (all)
          case 'atom-posts':
            $classes[] = $options['order_by'];

            if($options['post_type'] !== 'post')
              $classes[] = $options['post_type'];

            if($options['related'])
              $classes[] = 'related';

            if($options['category'])
              $classes[] = "cat-{$options['category']}";
          break;

          // custom menus, menu id
          case 'atom-menu':
            $classes[] = $options['nav_menu'];
          break;

          // term taxonomy, if different than 'post_tag'
          case 'atom-tag-cloud':
            if($options['taxonomy'] !== 'post_tag')
              $classes[] = $options['taxonomy'];
          break;

          // term taxonomy, if different than 'category'
          case 'atom-terms':
            if($options['taxonomy'] !== 'category')
              $classes[] = $options['taxonomy'];
          break;

          // link category ID
          case 'atom-links':
            if($options['category'])
              $classes[] = $options['category'];
          break;

          // archives, type & post type
          case 'atom-archives':
            $classes[] = $options['type'];
            if($options['post_type'] !== 'post') $classes[] = $options['post_type'];
          break;

          // calendar, post type
          case 'atom-calendar':
            if($options['post_type'] !== 'post') $classes[] = $options['post_type'];
          break;

          // blogs, sort order
          case 'atom-blogs':
            $classes[] = $options['order_by'];
          break;

          // users, role (if set)
          case 'atom-users':
            if($options['role'])
              $classes[] = $options['role'];
          break;

        }

        $base = str_replace('atom-', '', strtolower(preg_replace('/[^a-z0-9\-]+/i', '-', $id)));

        foreach($classes as &$class)
          $class = 'nav-'.$base.'-'.strtolower(preg_replace('/[^a-z0-9\-]+/i', '-', $class));

        array_unshift($classes, 'nav-'.$base); // first class (the widget id_base without "atom-")
  }



  /**
   * Get the user icon list from the child theme directory
   *
   * @since 1.8
   */
  public function getIcons(){

    if(!isset($this->icons)){
      $this->icons = array();

      if(is_child_theme() && is_dir(STYLESHEETPATH.'/'.self::USER_ICON_DIR))
        foreach(glob(STYLESHEETPATH.'/'.self::USER_ICON_DIR.'/*.png') as $filename)
          $this->icons[] = basename($filename, '.png');
    }

    return $this->icons;
  }


  
  /*/ form helpers -- @todo
  final public function formAddSelect($name, $args){

    ob_start();
    $args = wp_parse_args($args, array(
       'options'  => array(),
       'label'    => '',
       'size'     => false,
       'class'    => '',
       'disabled' => false,
       'selected' => '',
       'rules'    => '',
       'after'    => '',
       'echo'     => true,
    ));
    extract($args);
    if($rules){
      $rules = $rules ? "rules=\"{$rules}\"" : '';
      // @todo
    }
    $field_id = $this->get_field_id($name);
    $field_name = $this->get_field_name($name);
    $field_class = $class ? "class=\"{$class}\"": '';
    ?>
    <p>
      <label for="<?php echo $field_id; ?>" <?php if($disabled): ?> class="disabled" <?php endif; ?>> <?php echo $label; ?> </label>
        <select <?php echo $field_class; ?> id="<?php echo $field_id; ?>" name="<?php echo $field_name; ?>" <?php if($disabled): ?> disabled="disabled" <?php endif; ?> <?php echo $rules; ?>>
         <?php foreach($options as $option => $label): ?>
           <option value="<?php echo $option; ?>" <?php selected($selected, $option); ?>><?php echo $label; ?></option>
         <?php endforeach; ?>
        </select>
      <?php if($after): ?><small><?php echo $after; ?></small><?php endif; ?>
    </p>
    <?php
    if($echo) echo ob_get_clean(); else return ob_get_clean();
  }

  final public function formAddCheckbox($name, $args){
    ob_start();
    $args = wp_parse_args($args, array(
       'label'    => '',
       'after'    => '',
       'rules'    => '',
       'disabled' => false,
       'checked'  => false,
       'echo'     => true,
    ));
    extract($args);
    if($rules){
      $rules = $rules ? "rules=\"{$rules}\"" : '';
      // @todo
    }
    $field_id = $this->get_field_id($name);
    $field_name = $this->get_field_name($name);
    $field_class = $class ? "class=\"{$class}\"": '';
    ?>
    <p>
      <input type="checkbox" id="<?php echo $field_id ?>" name="<?php echo $field_name; ?>" <?php checked($checked); ?> <?php if($disabled): ?> disabled="disabled" <?php endif; ?> <?php echo $rules; ?> />
      <label for="<?php echo $field_id ?>" <?php if($disabled): ?> class="disabled" <?php endif; ?>><?php echo $label; ?></label>
      <?php if($after): ?><br /><small><?php echo $after; ?></small><?php endif; ?>
    </p>
    <?php
    if($echo) echo ob_get_clean(); else return ob_get_clean();
  }

  final public function formAddTextfield($name, $args){
    ob_start();
    $args = wp_parse_args($args, array(
       'label'    => '',
       'value'    => '',
       'size'     => '',
       'class'    => '',
       'after'    => '',
       'rules'    => '',
       'disabled' => false,
       'echo'     => true,
    ));
    extract($args);
    if($rules){
      $rules = $rules ? "rules=\"{$rules}\"" : '';
      // @todo
    }
    $field_id = $this->get_field_id($name);
    $field_name = $this->get_field_name($name);
    $field_class = $class ? "class=\"{$class}\"": '';
    $field_size = $size ? "size=\"{$size}\"" : '';
    ?>
    <p>
      <label for="<?php echo $field_id; ?>" <?php if($disabled): ?> class="disabled" <?php endif; ?>><?php echo $label; ?></label>
      <input type="text" <?php echo $size; ?> <?php echo $field_class; ?> id="<?php echo $field_id; ?>" name="<?php echo $field_name; ?>" value="<?php echo $value; ?>" <?php if($disabled): ?> disabled="disabled" <?php endif; ?> <?php echo $rules; ?> />
      <?php if($after): ?><small><?php echo $after; ?></small><?php endif; ?>
    </p>
    <?php
    if($echo) echo ob_get_clean(); else return ob_get_clean();
  }

  final public function formAddTextarea($name, $label = '', $args = array()){
    ob_start();
    $args = wp_parse_args($args, array(
       'value' => '',
       'size' => '8,24',
       'class' => 'widefat code',
       'after' => '',
       'rules' => '',
       'disabled' => false,
       'echo' => true,
    ));
    extract($args);
    if($rules){
      $rules = $rules ? "rules=\"{$rules}\"" : '';
      // @todo
    }
    $field_id = $this->get_field_id($name);
    $field_name = $this->get_field_name($name);
    $field_class = $class ? "class=\"{$class}\"": '';
    $field_size = $size ? "size=\"{$size}\"" : '';
    $size = explode(',', $size);
    $size = isset($size[0]) && isset($size[1]) ? "rows=\"{$size[0]}\" cols=\"{$size[1]}\"" : '';
    ?>
    <p>
      <label for="<?php echo $field_id; ?>" <?php if($disabled): ?> class="disabled" <?php endif; ?>><?php echo $label; ?></label>
      <textarea <?php echo $class; ?> <?php echo $size; ?> id="<?php echo $field_id; ?>" name="<?php echo $field_name; ?>" <?php if($disabled): ?> disabled="disabled" <?php endif; ?> <?php echo $rules; ?>><?php echo format_to_edit($value); ?></textarea>
      <?php if($after): ?><small><?php echo $after; ?></small><?php endif; ?>
    </p>
    <?php
    if($echo) echo ob_get_clean(); else return ob_get_clean();
  }
  //*/

}