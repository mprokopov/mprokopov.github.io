<?php
/**
 * Atom main class
 *
 * @link http://digitalnature.eu
 *
 * @package ATOM
 * @subpackage Template
 */



// framework version
define('ATOM_VERSION', '1.8');

// atom hooks
require 'hooks.php';

// shortcode functions
require 'shortcodes.php';

if(is_admin())
  require 'AtomAdmin.php';

require 'AtomMod.php';
require 'AtomIterator.php';
//require 'AtomIteratorComments.php';
require 'AtomIteratorPosts.php';
require 'AtomObject.php';
require 'AtomObjectAuthor.php';
require 'AtomObjectComment.php';
require 'AtomObjectPost.php';
require 'AtomWalkerComments.php';
require 'AtomWalkerTerms.php';
require 'AtomWidget.php';

/*/ all classes should be loaded automatically when needed
function __autoload($class){
  $root = dirname(__FILE__);
  if(is_file("{$root}/{$class}.php")) require "{$root}/{$class}.php";
}
/*/



/**
 * Main Atom class.
 * To access its methods use Atom::app()->method
 * For static methods, Atom::method() is enough...
 *
 * @since 1.7
 * @author digitalnature
 */
class Atom{

  const
    THEME_DOC_URI      = 'http://digitalnature.eu/docs/',                // theme documentation URI
    THEME_UPDATE_URI   = 'http://digitalnature.eu/',                     // theme updates will be automatically downloaded from here
    YQL_URI            = 'http://query.yahooapis.com/v1/public/yql?q=';  // yahoo query language url (used by some components to get external data)


  private static $instance;   // singleton instance

  private
    $current_theme_options,   // current theme options (the ones stored in the db)
    $debug_messages,          // stores Atom's debug messsages
    $user_functions,          // only if a child theme is used; this is the path to functions-user.php
    $theme_name,              // parent theme name (from style.css)
    $theme_version,           // parent theme version
    $theme_author,            // parent theme author string
    $theme_uri,               // parent theme URI string, ie. digitalnature.eu
    $theme_url,               // local URL to the parent theme, eg. yoursite.com/wp-content/themes/atom/
    $child_theme_url,         // local URL to the child theme (if not used this is the same as the parent theme URL)
    $mu_parent,               // multisite + parent site
    $swc,                     // site-wide content plugin installed & MU parent site?
    $supported_features,      // wp features (add_theme_support)

    $default_theme_options,   // default theme options
    $widget_areas,            // widget areas (sidebars); this will also contain the sidebar contents
    $widgets,                 // active widgets
    $widget_splitter,         // stores the splitter widget state (true = open, false = closed)
    $menus,                   // custom menu locations
    $layout_types,            // enabled layout types
    $post_formats,            // supported post formats

    $current_post,            // current post (should be the same as the $post global)
    $current_author,          // current author (only valid on author archives)
    $current_comment,         // current comment
    $current_commenter,       // registered user or old visitor

    $current_page_title,      // can hold a custom title for the current page
    $page_urls,               // caches requested page URLs

    $context_config;          // stores custom configuration for various methods, like pageNavi, filterContent etc. (array)

  public
    $is_internal_page   = false;    // true, if using a "internal" page template


  /**
   * This will instantiate the class if needed, and return the only class instance if not...
   *
   * @since 1.0
   */
  public static function app(){

    if(!(self::$instance instanceof self)){ // first run?
      self::$instance = new self();

      // get theme meta info from style.css; this is always the parent theme
      $theme = get_theme_data(TEMPLATEPATH.'/style.css');

      self::app()->user_functions     = is_child_theme() ? STYLESHEETPATH.'/functions-user.php' : false;
      self::app()->theme_version      = trim($theme['Version']);
      self::app()->theme_name         = $theme['Name'];
      self::app()->theme_author       = $theme['Author'];
      self::app()->theme_uri          = $theme['URI'];
      self::app()->theme_url          = get_template_directory_uri();
      self::app()->child_theme_url    = get_stylesheet_directory_uri();

      // multisite & 1st blog
      self::app()->mu_parent          = is_multisite() && ($GLOBALS['blog_id'] == 1);

      self::app()->swc                = is_multisite() && ($GLOBALS['blog_id'] == 1) && defined('ATOM_SWC_ACTIVE');

      self::app()->widget_splitter    = false;
      self::app()->context_config     = array();

      add_action('after_setup_theme', array(self::$instance, 'setup'));

      // localize the theme, child theme translations have priority
      if(is_child_theme()){
        $locale = get_locale();
        $locale_file = STYLESHEETPATH."/lang/{$locale}.php";
        if(is_readable($locale_file)) require_once($locale_file);
        load_theme_textdomain(ATOM, STYLESHEETPATH.'/lang');
      }

      // parent theme
      load_theme_textdomain(ATOM, TEMPLATEPATH.'/lang');
      $locale = get_locale();
      $locale_file = TEMPLATEPATH."/lang/{$locale}.php";
      if(is_readable($locale_file)) require_once($locale_file);

    }

    return self::$instance;
  }



  /**
   * Admin interface
   *
   * @since 1.0
   */
  public static function admin(){

    if(!is_admin()) return false;

    static $admin;

    if(!($admin instanceof AtomAdmin)) $admin = new AtomAdmin();

    return $admin;
  }



  /**
   * A single instance only
   *
   * @since 1.0
   */
  final protected function __construct(){}



  /**
   * No cloning
   *
   * @since 1.0
   */
  final protected function __clone(){}



  /**
   * __call magic method -- Allows echo of the output of a method by omitting "get"
   *
   * @since 1.0
   */
  public function __call($name, $args){
    $getter = "get{$name}";
    if(method_exists($this, $getter)) echo call_user_func_array(array(&$this, $getter), $args); else throw new Exception("Method {$name} is not defined");

    /*/ attempt to match the end of the $name string with a existing method
    $matches = preg_split('/('.implode('|', get_class_methods(__CLASS__)).')$/i', $name, 0, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
    if(isset($matches[1])){
      // pass the string difference as the 1st parameter
      array_unshift(&$args, $matches[0]);
      return call_user_func_array(array(&$this, $matches[1]), $args);
    }

    //*/

  }



  /**
   * __get magic method -- only usable for get/setCurrent* methods
   *
   * @since 1.0
   */
  public function __get($name){
    $getter = "getCurrent{$name}";
    if(method_exists($this, $getter)) return $this->$getter();

    throw new Exception("Property {$getter} is not defined.");
  }


  /**
   * __set magic method
   *
   * @since 1.0
   */
  public function __set($name, $value){
    $setter = "setCurrent{$name}";
    if(method_exists($this, $setter)) return $this->$setter($value);

    throw new Exception("Property {$setter} is not defined.");
  }



  /**
   * Get the value of a private variable
   *
   * @param mixed $var variable to get
   *
   * @since 1.0
   */
  public function get($var){
    return $this->$var;
  }



  /**
   * Get current post
   *
   * @since 1.0
   */
  public function getCurrentPost(){
    if(!isset($this->current_post)) $this->current_post = new AtomObjectPost();
    return $this->current_post;
  }



  /**
   * Set current post
   * - if $post is ommited the current post will take the value of WP's $post global
   * - if $post is a number (ID), the post will be fetched from the db and post data set up
   * - if $post is a object, the post data is set up...
   *
   * @param array|int|bool $post $post data / ID / nothing
   *
   * @since 1.0
   */
  public function setCurrentPost($post){
    $this->current_post = new AtomObjectPost($post);
  }



  /**
   * Resets the current post with the one from the main query
   *
   * @since 1.0
   */
  public function resetCurrentPost(){
    wp_reset_postdata();
    $this->setCurrentPost(false);
  }



  /**
   * Get current author
   *
   * @since 1.0
   */
  public function getCurrentAuthor(){
    if(!isset($this->current_author))
      $this->current_author = new AtomObjectAuthor(get_query_var('author'));
      
    return $this->current_author;
  }



  /**
   * Sets up current comment (and all the stupid WP globals etc)
   * - if $comment is a ID the comment will be fetched from the db
   *
   * @param array|int $comment comment data / ID
   *
   * @since 1.0
   */
  public function setCurrentComment($comment){
    $this->current_comment = new AtomObjectComment($comment);
  }



  /**
   * Get current comment
   *
   * @since 1.0
   */
  public function getCurrentComment(){
    if(!$this->current_comment)
      $this->current_comment = new AtomObjectComment();
      
    return $this->current_comment;
  }



  /**
   * Get current commenter info
   *
   * @since 1.0
   */
  public function getCurrentCommenter(){
    if(!isset($this->current_commenter))
      $this->current_commenter = wp_get_current_commenter();
      
    return $this->current_commenter;
  }



  /**
   * Updates the theme options
   *
   * @param array $options theme options
   *
   * @since 1.0
   */
  public function setOptions($options){
    update_option(ATOM, $options);
    $this->current_theme_options = $options;
  }



  /**
   * Updates the theme options.
   * - can check multiple boolean-type options if multiple arguments are passed
   * - if no arguments are provided, all options are returned as a array
   *
   * @param string $option Optional, theme option(s)
   *
   * @since 1.0
   */
  public function options(){

    // check if this is the 1st run, and load the theme settings if necessary
    if(!isset($this->current_theme_options))
      $this->current_theme_options = get_option(ATOM);

    if(empty($this->current_theme_options)) return false;

    $args = func_get_args();
    $options = array_values($args);

    // no arguments, return the theme options array
    if(empty($options))
      return $this->current_theme_options;

    // single option? return value...
    if(count($options) === 1 && isset($this->current_theme_options[reset($options)]))
      return $this->current_theme_options[reset($options)];

    // multiple arguments? (return true if all of them are enabled and have a true value, false if all of them have a false value)
    $results = array();
    foreach($options as $option)
      if(isset($this->current_theme_options[$option])) $results[$option] = (bool)$this->current_theme_options[$option];

    // are all true, or all are false
    if(count(array_unique($results)) === 1) return array_shift($results);

    // mixed values
    return null;
  }



  /**
   * Get the default theme options (the ones set with the function below)
   *
   * @return array Default Theme Options
   *
   * @since 1.0
   */
  public function getDefaultOptions(){
    return $this->default_theme_options;
  }



  /**
   * Set the default theme options
   * 'theme_version' is ignored if given, and set automatically to the one specified in style.css
   *
   * @param array $options Theme options
   *
   * @since 1.0
   */
  public function setDefaultOptions($options){
    if(!$this->default_theme_options)
      $this->default_theme_options = $options;

    // required and unchangeable, always defaults to version string from style.css
    $this->default_theme_options['theme_version'] = $this->theme_version;
  }



  /**
   * Add extra theme options and set defaults, eg. from within modules or plugins
   * Important: only has effect before theme setup, but after the default options have been registered
   *
   * @param array $options Theme options
   *
   * @return bool true/false on success/fail
   *
   * @since 1.0
   */
  public function addDefaultOptions($options){
    if(isset($this->current_theme_options) || !isset($this->default_theme_options)) return false; // already initialized or defaults not yet set

    $this->default_theme_options = array_merge($this->default_theme_options, $options);
    return true;
  }



  /**
   * Get widget areas (sidebars)
   *
   * @return array Widget areas
   *
   * @since 1.0
   */
  public function widgetAreas(){
    return $this->widget_areas;
  }



  /**
   * Set up widget areas (sidebars).
   * Each argument represents one sidebar
   *
   * @param array Widget areas
   *
   * @since 1.0
   */
  public function setWidgetAreas(){
    $args = func_get_args();
    if(!$this->widget_areas) $this->widget_areas = array_values($args);
  }



  /**
   * Set up active ATOM widgets
   * Each argument represents one widget
   *
   * @param string Widget class name
   *
   * @since 1.0
   */
  public function setActiveWidgets(){
    $args = func_get_args();
    if(!$this->widgets) $this->widgets = array_values($args);
  }



  /**
   * Get up the splitter wiget state
   *
   * @return bool True if active & open, false otherwise
   *
   * @since 1.0
   */
  public function getWidgetSplitter(){
    return $this->widget_splitter;
  }



  /**
   * Set up the splitter wiget state
   *
   * @param bool True if active & open, false otherwise
   *
   * @since 1.0
   */
  public function setWidgetSplitter($state){
    $this->widget_splitter = $state;
  }



  /**
   * Set up custom menu locations
   *
   * @param array $menus if active & open, false otherwise
   *
   * @since 1.0
   */
  public function setMenus($menus){
    if(!$this->menus) $this->menus = $menus;
  }


  /**
   * Get layout types
   *
   * @return array layout types
   *
   * @since 1.0
   */
  public function layoutTypes(){
    return $this->layout_types;
  }



  /**
   * Set up layout types (eg. col-1, col-2-left etc)
   *
   * @param string layout types (each is one argument)
   *
   * @since 1.0
   */
  public function setLayoutTypes(){
    $args = func_get_args();
    if(!$this->layout_types) $this->layout_types = array_values($args);
  }



  /**
   * Register extra post formats besides "standard"
   *
   * @param string Post format(s), one argument for each
   *
   * @since 1.0
   */
  public function addPostFormats(){
    $args = func_get_args();
    if(!$this->post_formats) $this->post_formats = array_values($args);
  }



  /**
   * Run a function linked to a specific tag
   * Same as do_action(), just prepends the ATOM_ prefix to the tag
   *
   * @since 1.2
   *
   * @param string $tag tag name
   * @param string $args arguments
   */
  public static function action($tag = ''){
    $args = func_get_args();
    array_shift($args);
    array_unshift($args, "atom_{$tag}");
    call_user_func_array('do_action', $args);
  }



  /**
   * Replaces add_filter and add_action (same behaviour, just prepends the ATOM_ prefix to the tag)
   *
   * @since 1.2
   *
   * @param string $tag tag name
   * @param string $function_to_add function name
   * @param string $priority priority
   * @param string $accepted_args # of arguments accepted
   *
   * @return mixed Filtered value
   */
  public static function add($tag, $function_to_add, $priority = 10, $accepted_args = 1){
    return add_filter("atom_{$tag}", $function_to_add, $priority, $accepted_args);
  }



  /**
   * (Re)sets the theme settings
   * Unless manually triggered, this should only run once (after the theme is activated for the 1st time)
   *
   * @since 1.0
   */
  public function reset(){

    define('INSTALLING_ATOM', true);

    $this->uninstall($reset_only = true);

    // attempt to create a child theme in the wp-themes directory and activate it
    // @todo: auto-network-activate the theme on MU, if the parent theme is network-activated
    if(ATOM_EXTEND && !is_child_theme()){

      require_once(ABSPATH.'wp-admin/includes/file.php');
      if(!WP_Filesystem()){
        $this->addDebugMessage('Failed to initialize WPFS...', 1); // do not return, we still need to set up the settings
        
      }else{

        $parent = get_theme_data(TEMPLATEPATH.'/style.css');
        $name = ATOM.'-extend';
        $destination = trailingslashit($GLOBALS['wp_filesystem']->wp_themes_dir()).$name;

        $style = "/*\n"
                ."Theme Name: {$parent['Name']} - Extend\n"
                ."Theme URI: {$parent['URI']}\n"
                ."Description: Auto-generated child theme of {$parent['Name']}. Please leave this one activated for proper customizations to {$parent['Name']}.\n"
                ."Version: 1.0\n"
                ."Author: {$parent['Author']}\n"
                ."Author URI: {$parent['AuthorURI']}\n"
                ."Template: ".get_template()."\n"
                ."*/\n\n"
                ."/* You can safely edit this file, but keep the Template tag above unchanged! */\n";

        if(!$GLOBALS['wp_filesystem']->is_dir($destination))
          if($GLOBALS['wp_filesystem']->mkdir($destination, FS_CHMOD_DIR) && $GLOBALS['wp_filesystem']->put_contents($destination.'/style.css', $style, FS_CHMOD_FILE)){

            // copy screenshot and license.txt
            $GLOBALS['wp_filesystem']->copy(TEMPLATEPATH.'/screenshot.png', $destination.'/screenshot.png');
            $GLOBALS['wp_filesystem']->copy(TEMPLATEPATH.'/license.txt', $destination.'/license.txt');

            $this->addDebugMessage("Created {$name} child theme. Switching...");
            switch_theme(get_template(), $name);
            $new_atom = get_stylesheet();
            wp_redirect(admin_url("themes.php?page={$new_atom}"));
            die(); // stop execution of the current page
            
          }else{
            $this->addDebugMessage('Failed to create child theme.', 1);
          }
      }
    }

    // update the db with the default settings
    $this->setOptions($this->default_theme_options);

    // action hook, probably useless
    $this->action('setup_options');
  }




  /**
   * First theme install notification message
   *
   * @since 1.0
   */
  public function themeInstallNotification(){ ?>
    <div class="updated fade">
      <p><?php printf(_a('You can customize your %1$s theme from the <%2$s>theme settings</a> page.'), $this->theme_name, 'a href="'.admin_url('admin.php?page='.ATOM).'"'); ?></p>
    </div>
    <?php
  }



  /**
   * Get the relative date of a UNIX timestamp
   *
   * @since 1.0
   *
   * @param string $older_date Date in UNIX time format
   * @param string $newer_date Optional. Use a custom newer date instead of the current time returned by the server
   * @return string The relative date string
   */
  public static function getTimeSince($older_date, $newer_date = false){
    $chunks = array(
      'year'   => 60 * 60 * 24 * 365,  // 31,536,000 seconds
      'month'  => 60 * 60 * 24 * 30,   // 2,592,000 seconds
      'week'   => 60 * 60 * 24 * 7,    // 604,800 seconds
      'day'    => 60 * 60 * 24,        // 86,400 seconds
      'hour'   => 60 * 60,             // 3600 seconds
      'minute' => 60,                  // 60 seconds
      'second' => 1                    // 1 second
    );

    // site setting for mu + swc
    $gmt_offset = Atom::app()->get('mu_parent') ? get_site_option('gmt_offset') : get_option('gmt_offset');

    $newer_date = ($newer_date == false) ? (time() + (3600 * $gmt_offset)) : $newer_date;
    $since = $newer_date - $older_date;

    foreach($chunks as $key => $seconds)
      if(($count = floor($since / $seconds)) != 0) break;

    $messages = array(
      'year'   => _an('%s year ago', '%s years ago', $count),
      'month'  => _an('%s month ago', '%s months ago', $count),
      'week'   => _an('%s week ago', '%s weeks ago', $count),
      'day'    => _an('%s day ago', '%s days ago', $count),
      'hour'   => _an('%s hour ago', '%s hours ago', $count),
      'minute' => _an('%s minute ago', '%s minutes ago', $count),
      'second' => _an('%s second ago', '%s seconds ago', $count),
    );
    return sprintf($messages[$key], $count);
  }



  /**
   * Filters content based on specific parameters, and appends a "read more" link if needed.
   * Based on the "Advanced Excerpt" plugin by Bas van Doren - http://sparepencil.com/code/advanced-excerpt/
   *
   * @since 1.0
   *
   * @param string $content What to filter, defaults to get_the_content(); should be left empty if we're filtering post content
   * @param array $args Optional arguments (limit, allowed tags, enable/disable shortcodes, read more link)
   * @return string Filtered content
   */
  public static function getFilteredContent($text, $args = array()){

    // get the theme settings
    $args = wp_parse_args($args, array(
        'limit'        => 0,         // word limit, disabled by default
        'shortcodes'   => false,     // keep shortcodes?
        'more'         => false,     // more tag format, disabled by default
        'allowed_tags' => array(     // html tags to ignore
           'a',
           'abbr',
           'acronym',
           'address',
           'b',
           'big',
           'blockquote',
           'cite',
           'code',
           'dd',
           'del',
           'dfn',
           'div',
           'dl',
           'dt',
           'em',
           'h1',
           'h2',
           'h3',
           'h4',
           'h5',
           'h6',
           'i',
           'ins',
           'li',
           'ol',
           'p',
           'pre',
           'q',
           'small',
           'span',
           'strong',
           'sub',
           'sup',
           'tt',
           'ul',
        ),
      ));

    extract($args, EXTR_SKIP);

    if(!$shortcodes) $text = strip_shortcodes($text);

    // From the default wp_trim_excerpt():
    // Some kind of precaution against malformed CDATA in RSS feeds I suppose
    $text = str_replace(']]>', ']]&gt;', $text);

    // Strip HTML if allow-all is not set
    if(!in_array('ALL', $allowed_tags)){
      if(count($allowed_tags) > 0) $tag_string = '<'.implode('><', $allowed_tags).'>'; else $tag_string = '';
      $text = strip_tags($text, $tag_string);
    }

    // skip if text is already within limit
    if($limit == 0 || $limit >= count(preg_split('/[\s]+/', strip_tags($text)))) return $text;

    // split on whitespace and start counting (for real)
    $text_bits = preg_split('/([\s]+)/', $text, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
    $in_tag = false;
    $n_words = 0;
    $text = '';
    foreach($text_bits as $chunk){
      if(!$in_tag || strpos($chunk, '>') !== false) $in_tag = (strrpos($chunk, '>') < strrpos($chunk, '<'));

      // whitespace outside tags is word separator
      if(!$in_tag && '' == trim($chunk)) $n_words++;

      if($n_words >= $limit && !$in_tag) break;
      $text .= $chunk;
    }

    $text = trim(force_balance_tags($text));

    if($more){
      $more = " {$more}";
      if(($pos = strpos($text, '</p>', strlen($text) - 7)) !== false){
        // stay inside the last paragraph (if it's in the last 6 characters)
        $text = substr_replace($text, $more, $pos, 0);
      }else{

        // if <p> is an allowed tag, wrap read more link for consistency with excerpt markup
        if(in_array('ALL', $allowed_tags) || in_array('p', $allowed_tags)) $more = "<p>{$more}</p>";
        $text = $text.$more;
      }
    }
    return $text;
  }



  /**
   * Synchronize theme settings.
   *
   * Options are synced when:
   * - a new theme version is installed (comparing version recorded in the db versus the version from style.css)
   * - a new module that adds options is activated
   * - theme options from the db are invalid etc.
   *
   * @since 1.0
   */
  private function syncOptions(){

    // load the defaults if settings are not present (new theme install)
    if(!$this->options()){

      $this->reset();

      add_action('admin_notices', array(&$this, 'themeInstallNotification'));

      // update permalink structure later, after posts are loaded (some modules might change permalink structure ;)
      add_action('wp', create_function('', "flush_rewrite_rules();"));

      $this->addDebugMessage('New theme install. Default settings were installed');
      
    }else{

      // only go further if the theme version from the database differs from the one in the theme files;
      // not really required, because the desync check below should take care of it,
      // but it's here in case new theme versions attempt to force the update of a existing option value...
      $new_version = version_compare($this->current_theme_options['theme_version'], $this->theme_version, '!=');

      // ...or if option names present in the database are different than the default option names
      $options_desynced = array_diff_key($this->default_theme_options, $this->current_theme_options) !== array_diff_key($this->current_theme_options, $this->default_theme_options);

      if($new_version || $options_desynced){
        $old_version = $this->current_theme_options['theme_version']; // save old version info

        // check for new settings and load defaults
        foreach($this->default_theme_options as $option => $value)
          if(!array_key_exists($option, $this->current_theme_options))
            $this->current_theme_options[$option] = $value;

        // remove deprecated options -- maybe we should do this only on version change? -- @todo check this out because it seems to remove module options on version change...
        //foreach($this->current_theme_options as $option => $value)
        //  if(!array_key_exists($option, $this->default_theme_options)) unset($this->current_theme_options[$option]);

        // update theme version
        $this->current_theme_options['theme_version'] = $this->theme_version;

        // update db
        $this->setOptions($this->current_theme_options);

        // update permalink structure
        add_action('wp', create_function('', "flush_rewrite_rules();"));

        // if a new theme version wants to force a existing option value to be updated
        $this->action('sync_options', $old_version);

        $this->addDebugMessage("Theme updated {$old_version} => {$this->theme_version}. Settings were synchronized");

      }
    }
  }



  /**
   * Check if we're on a certain page / or output the current page slug
   *
   * @param string $page Page to check
   * @since 1.0
   */
  public function isPage($page){
    // internal page handled by a template
    if(get_query_var('pagename') === $page) return true;

    // not a internal page, normal page then?
    return is_page($page);
  }



  /**
   * Get a page's URL
   *
   * @param string $page Page to get
   * @since 1.0
   */
  function getPageURL($page, $only_internal = false) {
    if(!isset($this->page_urls[$page])){
      if((is_child_theme() && file_exists(STYLESHEETPATH.'/internal-'.$page.'.php')) || file_exists(TEMPLATEPATH.'/internal-'.$page.'.php')){
        $this->page_urls[$page] = ($GLOBALS['wp_rewrite']->using_permalinks()) ?  home_url('/').$page.'/' : add_query_arg(array('pagename' => $page), home_url('/'));

      }else{
        // internal page doesn't exist
        if($only_internal) return false;

        $page_obj = get_page_by_path($page);
        if(!empty($page_obj->ID)) $this->page_urls[$page] = get_page_link($page_obj->ID);
      }
    }

    return $this->page_urls[$page];
  }



  /**
   * Output the favicon meta
   *
   * @param string $override Optional, override favicon path...
   * @since 1.0
   */
  public function getFavIcon($override = ''){
    $favicon = $override ? $override : $this->options('favicon');
    if($favicon) return "<link rel=\"shortcut icon\" href=\"{$favicon}\" />\n";
  }



  /**
   * Force a custom title for the current page. "Paged" parts are detected automatically.
   * Obviously must be called before getDocumentTitle() below...
   *
   * @param string $title Title to set. If multiple arguments are given, they are combined as "parts" into a array
   * @since 1.7
   */
  public function setDocumentTitle($title){
    $args = func_get_args();
    $parts = array_values($args);
    $this->current_page_title = (count($parts) > 1) ? $parts : array_shift($parts);
  }



  /**
   * Formats and outputs the document title
   *
   * @since 1.0
   *
   * @param string $separator Title separator. eg. |, -, &laquo; etc...
   * @param bool $reverse Reverse title parts?
   * @param array $advanced_config Extra configuration options
   */
  public function getDocumentTitle($separator = '&raquo;', $reverse = false, $advanced_config = array()){

    // extra config, defaults -- @todo expand this, add more options...
    $advanced_config = wp_parse_args($advanced_config, array(
      'singular_post_parents'  => array(), // array of post types for which to append parent post titles
      'singular_object_labels' => array(), // array of post types for which to append object labels
    ));

    extract($this->getContextArgs('document_title', $advanced_config), EXTR_SKIP);

    $title = array();

    $title[] = get_bloginfo('name');
    $description = get_bloginfo('description');

    // allow developers so set a custom page title using the setDocumentTitle() method (useful theme-internal pages)
    if(isset($this->current_page_title)){
      if(is_array($this->current_page_title))
        foreach($this->current_page_title as $part) $title[] = $part;

      elseif(!empty($this->current_page_title))
        $title[] = $this->current_page_title;

    // home page / front page
    }elseif(is_front_page() && is_home() && !empty($description)){
      $title[] = $description;

    // home page or single post page
    }elseif(is_singular()){
      if($meta = get_post_meta($this->post->getID(), 'title', true)){
        $title[] = $meta;

      }else{

        if(in_array($this->post->getType(), (array)$singular_object_labels))
          $title[] = get_post_type_object($this->post->getType())->labels->name;

        if(in_array($this->post->getType(), (array)$singular_post_parents)){ // appends parent post titles, if any
          $parent = (int)$this->post->getParent();
          while($parent !== 0){
            $title[] = get_the_title($parent);
            $parent = (int)get_post_field('post_parent', $parent);
          }
        }

        // current post title
        $title[] = $this->post->getTitle();
      }

    // archives
    }elseif(is_archive()){
      // taxonomy archives
      if(is_category() || is_tag() || is_tax()){
        $term = $GLOBALS['wp_query']->get_queried_object();
        $title[] = $term->name;

      // author archives
      }elseif(is_author()){
        $title[] = get_the_author_meta('display_name', get_query_var('author'));

      // date archives
      }elseif(is_date()){
        // day
        if(is_day())
          $title[] = sprintf(_a('Archive for %s'), $this->post->getDate(apply_filters('doc_title_archive_day_format', 'F jS, Y')));

        // week
        elseif(get_query_var('w'))
          $title[] = sprintf(_a('Archive for week %1$s of %2$s'), $this->post->getDate('W'), $this->post->getDate('Y'));

        // month
        elseif(is_month())
          $title[] = sprintf(_a('Archive for %s'), single_month_title(' ', false));

        // year
        elseif(is_year())
          $title[] = sprintf(_a('Archive for year %s'), $this->post->getDate('Y'));

      // other archive types
      }else{
        $title[] = post_type_archive_title('', false);
      }

    // search
    }elseif(is_search()){
      $title[] = sprintf(_a('Search results for %s'), '&quot;'.get_search_query().'&quot;');

    // 404
    }elseif(is_404()){
      $title[] = _a('404 Not Found');

    }

    // paged?
    if((($page = $GLOBALS['wp_query']->get('paged')) || ($page = $GLOBALS['wp_query']->get('page'))) && $page > 1 && !is_404())
      $title[] = sprintf(_a('Page %s'), $page);

    // comment page?
    if(get_query_var('cpage'))
      $title[] = sprintf(_a('Comment Page %s'), get_query_var('cpage'));

    // reverse parts?  
    if($reverse) $title = array_reverse($title);

    // apply the wp_title filters so we're compatible with plugins
    return apply_filters('wp_title', implode(" {$separator} ", $title), $separator, $reverse);
  }



  /**
   * Generates and outputs the current page meta description field
   *
   * @since 1.0
   */
  public function getMetaDescription(){
    if(!$this->options('meta_description')) return;

    // blog description on the homepage
    if(is_home()){
      $description = get_bloginfo('description');

    // single pages?
    }elseif(is_singular()){

      // custom field, if present
      $description = get_metadata('post', $this->post->getID(), 'description', true);

      // if not, and we're on a static homepage use the blog description
      if(empty($description) && is_front_page()) $description = get_bloginfo('description');

      // otherwise use the post excerpt
      elseif(empty($description)) $description = get_post_field('post_excerpt', $this->post->getID());


    // archive pages?
    }elseif(is_archive()){

     // author bio on author pages
     if(is_author()) $description = get_the_author_meta('description', get_query_var('author'));

     // taxonomy term description on category/tags/etc...
     elseif (is_category() || is_tag() || is_tax()) $description = term_description('', get_query_var('taxonomy'));

    }

    if(!empty($description)){
      // remove html formatting
      $description = str_replace(array("\r", "\n", "\t"), '', esc_attr(strip_tags($description)));

      // output (and allow user to change the content trough a filter hook)
      return '<meta name="description" content="'.apply_filters('meta_description', $description).'" />'.PHP_EOL;
    }
  }



  /**
   * Output the site logo HTML
   *
   * @since 1.0
   * @todo Auto image-size
   *
   * @param string $image_path Image URL
   */
  public function getLogo($image_path = ''){

    if(!$image_path) $image_path = $this->options('logo');


    $title = get_bloginfo('name');

    // determine text size
    $title_length = strlen($title);
    if($title_length < 3) $font_size = 'xs';
    elseif($title_length < 6) $font_size = 's';
    elseif($title_length < 12) $font_size = 'm';
    elseif($title_length < 24) $font_size = 'l';
    else $font_size = 'xl';

    $image_size = ''; // @todo

    // <h1> only on the front/home page, for seo reasons
    $tag = (is_home() || is_front_page()) ? 'h1' : 'div';

    $output = '<'.$tag.' id="logo" class="size-'.$font_size.'">';

    if($image_path){ // logo image?
      $output .= '<a href="'.home_url('/').'"><img src="'.$image_path.'" title="'.$title.'" '.$image_size.' alt="'.$title.'" /></a>';

    }else{ // text?

      // we get a special treat if the logo is made out of 2 or 3 words
      $words = explode(' ', $title);
      if(!empty($words[1]) && empty($words[3])){
        $words[1] = '<span class="alt">'.$words[1].'</span>';

        // leave the space here and remove it trough css to avoid seo problems
        $title = implode(' ', $words);
      }
      $output .= '<a href="'.home_url('/').'">'.$title.'</a>';

    }

    $output .= '</'.$tag.'>';
    return apply_filters('atom_logo', $output, $title);
  }



  /**
   * wp_nav_menu wrapper
   * Check if a menu location exists
   *
   * @since 1.8
   *
   * @param string $location Menu location
   * @param string $user_classes Extra classes to add to the menu list
   * @param string $fallback Fallback menu
   * @return string menu HTML
   */
  public function menuExists($location){

    // location not set
    if(!isset($this->menus[$location])) return false;

    // check if the menu has items
    if(($location !== 'primary') && !has_nav_menu($location)) return false;

    // primary menu always exists because it has a fallback set by default
    return true;
  }



  /**
   * wp_nav_menu wrapper
   * @todo: (maybe) create our own walker and add menu entry template?
   *
   * @since 1.0
   *
   * @param string $location Menu location
   * @param string $user_classes Extra classes to add to the menu list
   * @param string $fallback Fallback menu
   * @return string menu HTML
   */
  public function getMenu($location, $user_classes = '', $fallback = ''){
    return wp_nav_menu($this->getContextArgs("{$location}_menu", array(
        'echo'           => false,
        'container'      => false,
        'menu_class'     => "menu {$user_classes} clear-block",
        'theme_location' => $location,
        'fallback_cb'    => $fallback ? array(&$this, $fallback) : '',
      )));
  }



  /**
   * Check if a theme option is enabled
   * $options can also be a prefix of a set of options, eg. 'media'
   *   (Useful if the theme has custom-made options that mix with default ones, or are from the same category)
   *
   * @since 1.0
   *
   * @param string $option The option name.
   * @return bool True if exists, false otherwise
   */
  public function isOptionEnabled($option){

    // check for a prefix first
    $keys = array_keys($this->default_theme_options);
    foreach($keys as $key)
  //    if (0 == substr_compare($key, $option.'_', 0, strlen($option.'_'))) return true;
      if(preg_match("/^".$option.'_'."/", $key)) return true; // might be faster?

    // try to match the exact name
    if(isset($this->default_theme_options[$option])) return true;
    return false;
  }



  /**
   * Uninstall the theme.
   * Removes theme settings and fires a hook that allows modules to remove their stuff too...
   *
   * @since 1.0
   *
   * @param bool $reset_only Optional, if true the action is skipped
   */
  public function uninstall($reset_only = false){
    delete_option(ATOM);
    delete_option(ATOM.'-atom-mods');
    if(!$reset_only) $this->action('uninstall');
    // @todo: remove the child theme?
  }



  /**
   * Return the javascript url for a file from the js directory
   *
   * @param string $name Name of the .js file
   * @since 1.4
   */
  public function jsURL($name){
    return $this->theme_url.'/js/'.$name.(!ATOM_DEV_MODE ? '.min' : '').'.js';
  }



  /**
   * check for a Atom request
   *
   * @since 1.3
   *
   * @param string $req
   * @param string $req
   *
   * @return bool
   */
  public static function request($req){
    return (get_query_var('atom') === $req);
  }



  /**
   * AJAX headers
   *
   * @since 1.3
   *
   * @param string $nonce
   */
  public static function ajaxHeader($nonce = '', $content_type = 'text/html'){
    defined("DOING_AJAX") or define("DOING_AJAX", true);
    @header("Content-Type: {$content_type}; charset=".get_option('blog_charset'));
    @header("X-Content-Type-Options: nosniff");

    if($nonce) check_ajax_referer("atom_{$nonce}", "_ajax_nonce");
  }



  /**
   * Check if we're in theme preview mode (Atom > Design)
   *
   * @since 1.0
   *
   * @return bool True or False
   */
  public static function previewMode(){
    return (isset($_GET['themepreview']) && current_user_can('edit_theme_options'));
  }



  /**
   * Generates page navigation links for any content type
   * based on WP PageNavi
   *
   * @since 1.0
   * @global $wp_query object
   * @global $wp_rewrite object
   *
   * @param array $args Optional arguments
   */
  public function getPageNavi($args = array()){

    // defaults
    $args = wp_parse_args($args, array(
      'type'                 => $this->options('post_navi'),
      'class'                => '',
      'pages_to_show'        => 5,       // numbers only
      'extended'             => false,   // numbers only
      'larger_page_to_show'  => 3,       // numbers only
      'larger_page_multiple' => 10,      // numbers only
      'status'               => false,   // numbers & prevnext types only
      'prev_next'            => true,    // numbers only, always true for prevnext type
      // 'all'                  => true, // @todo
      'query'                => $GLOBALS['wp_query'],
    ));

    extract($this->getContextArgs('pagenavi', $args), EXTR_SKIP);

    $prev_next = ($type === 'prevnext') ? true : $prev_next;
    $paged = max(1, absint($query->get('paged')));

    $total_pages = max(1, absint($query->max_num_pages));
    if($total_pages == 1) return false;

    $request = $query->request;
    $numposts = $query->found_posts;

    $pages_to_show_minus_1 = $pages_to_show - 1;
    $half_page_start = floor($pages_to_show_minus_1/2);
    $half_page_end = ceil($pages_to_show_minus_1/2);

    $start_page = $paged - $half_page_start;

    if($start_page <= 0) $start_page = 1;
    $end_page = $paged + $half_page_end;

    if(($end_page - $start_page) !== $pages_to_show_minus_1) $end_page = $start_page + $pages_to_show_minus_1;

    if($end_page > $total_pages){
      $start_page = $total_pages - $pages_to_show_minus_1;
      $end_page = $total_pages;
    }

    if ($start_page <= 0) $start_page = 1;

    $out = array();

    // add classes to prev/next so they can be styled
    add_filter('previous_posts_link_attributes', create_function('', 'return \'class="previous"\'; '));
    add_filter('next_posts_link_attributes', create_function('', 'return \'class="next"\'; '));

    if($type === 'single'){

      $out[] = get_next_posts_link(_a('Show Older Posts'));

    }else{

      if($status) $out[] = '<span class="pages">'.sprintf(_a('Page %1$s of %2$s'), $paged, $total_pages).'</span>';

      if($prev_next) $out[] = get_previous_posts_link(_a('&laquo; Previous'));

      // numbered page links
      if($type !== 'prevnext'){

        if($start_page >= 2 && $pages_to_show < $total_pages){
          $out[] = '<a class="first" href="'.esc_url(get_pagenum_link(1)).'">1</a>';
          $out[] = '<span class="dots">...</span>';
        }

        $larger_pages_array = array();
        if ($larger_page_multiple)
          for ($i = $larger_page_multiple; $i <= $total_pages; $i += $larger_page_multiple) $larger_pages_array[] = $i;

        if($extended){
          $larger_page_start = 0;
          foreach($larger_pages_array as $larger_page)
            if($larger_page < $start_page && $larger_page_start < $larger_page_to_show){
             $out[] = '<a class="ext page" href="'.esc_url(get_pagenum_link($larger_page)).'">'.$larger_page.'</a>';
             $larger_page_start++;
            }
        }

        foreach(range($start_page, $end_page) as $i)
          if ($i == $paged) $out[] = '<span class="current">'.$i.'</span>'; else $out[] = '<a class="page" href="'.esc_url(get_pagenum_link($i)).'">'.$i.'</a>';

        if($extended){
          $larger_page_end = 0;
          foreach ($larger_pages_array as $larger_page)
            if($larger_page > $end_page && $larger_page_end < $larger_page_to_show){
              $out[] = '<a class="ext page" href="'.esc_url(get_pagenum_link($larger_page)).'">'.$larger_page.'</a>';
              $larger_page_end++;
            }
        }

        if($end_page < $total_pages){
          $out[] = '<span class="dots">...</span>';
          $out[] = '<a class="last" href="'.esc_url(get_pagenum_link($total_pages)).'">'.$total_pages.'</a>';
        }

      }

      if($prev_next) $out[] = get_next_posts_link(_a('Next &raquo;'), $total_pages);

      // @todo
      // if($all) $out .= '<a class="view-all" href="'.add_query_arg('nopaging', 1, $this->getCurrentPageURL()).'">'._a('View All').'</a>';

    }

    if(!empty($out)) return "<!-- page navigation -->\n<div class=\"page-navi {$type} {$class} clear-block\">\n".implode("\n", $out)."\n</div>\n<!-- /page navigation -->";

    //*/
  }



  /**
   * Social Media links
   *
   * @since 1.0
   *
   * @param string $classes Optional CSS classes
   *
   * @todo: integrate this properly into templates
   */
  public function getSocialMediaLinks($classes = '', $nudge_dir = false, $nudge_amt = false){
    $nudge_dir = apply_filters('atom_social_media_links_nudge_dir', $nudge_dir);
    $nudge_amt = apply_filters('atom_social_media_links_nudge_amt', $nudge_amt);

    $nudge_dir = $nudge_dir ? ' data-dir="'.$nudge_dir.'"' : '';
    $nudge_amt = $nudge_amt ? ' data-amt="'.$nudge_amt.'"' : '';

    $output = '';
    if($k = $this->options('media_rss'))
     $output .= "<li class=\"rss\"><a title=\""._a("RSS Feeds")."\" href=\"{$k}\">RSS</a></li>\n";

    if($k = $this->options('media_twitter'))
     $output .= "<li class=\"twitter\"><a title=\""._a("Twitter updates")."\" href=\"{$k}\">Twitter</a></li>\n";

    if($k = $this->options('media_facebook'))
     $output .= "<li class=\"facebook\"><a title=\""._a("Facebook page")."\" href=\"{$k}\">Facebook</a></li>\n";

    if($k = $this->options('media_flickr'))
     $output .= "<li class=\"flickr\"><a  title=\""._a("Flick photostream")."\" href=\"{$k}\">Flickr</a></li>\n";

    if($k = $this->options('media_myspace'))
     $output .= "<li class=\"myspace\"><a title=\""._a("MySpace page")."\" href=\"{$k}\">MySpace</a></li>\n";

    // can add extra <li>'s here
    $output = apply_filters('atom_social_media_links', $output);

    if($output) return "<ul class=\"social-media nudge {$classes}\"{$nudge_dir}{$nudge_amt}>\n{$output}</ul>";
  }



  /**
   * Retrieve external theme styles (style-*.css files from the CSS folder)
   *
   * @since 1.0
   *
   * @return array A array containing relevant meta info for each file
   */
  public function getStyles(){
    $style_headers = array(
      'name'         => 'Style Name',
      'color'        => 'Color',
      'description'  => 'Description',
      'author'       => 'Author',
      'version'      => 'Version'
    );

    $styles = array();
    foreach(glob(TEMPLATEPATH."/css/style-*.css") as $filename)
      if($meta = get_file_data($filename, $style_headers)){
        $meta['id'] = substr(basename($filename, '.css'), 6);
        $styles[] = $meta;
      }

    return $styles;
  }



  /**
   * Retrieve external modules located in the theme's "mods" directory
   *
   * @since 1.8
   *
   * @param string $type Type of module, 'core' or 'user' (child theme)
   *
   * @return array A array containing each file meta info
   */
  public function getModules($type = false){

    // all types?
    if(!$type)
      return array_merge($this->getModules('core'), $this->getModules('user'));

    $from_where = ($type !== 'core' && is_child_theme()) ? STYLESHEETPATH.'/mods' : TEMPLATEPATH.'/mods';

    $modules = array();
    $module_headers = array(
      'name'        => 'Module Name',
      'description' => 'Description',
      'author'      => 'Author',
      'url'         => 'Author URI',
      'version'     => 'Version'
    );

    $modules_dir = @opendir($from_where);
    $module_files = array();
    if($modules_dir)
      while(($file = readdir($modules_dir)) !== false){
        if(substr($file, 0, 1) == '.') continue;
        if(is_dir($from_where.'/'.$file)){
          $module_dir = @opendir($from_where.'/'.$file);
          if($module_dir)
            while(($subfile = readdir($module_dir)) !== false){
              if(substr($subfile, 0, 1) == '.') continue;
              if(substr($subfile, -4) == '.php') $module_files[] = "{$file}/{$subfile}";
            }
        }
      }

    else
      return $modules;


    @closedir($modules_dir);
    @closedir($module_dir);

    if(empty($module_files)) return $modules;

    foreach($module_files as $file){
      if(!is_readable($from_where.'/'.$file)) continue;
      $data = get_file_data($from_where.'/'.$file, $module_headers);
      if(empty($data['name'])) continue;
      $data['type'] = $type;
      $modules[dirname($file)] = $data;
    }

    return $modules;
  }



  /**
   * Registers all theme hooks and runs typical theme setup routines
   *
   * @since 1.7
   */
  public function setup(){

    // make sure the 'ATOM' constant doesn't contain illegal characters
    //if(preg_replace('/[^A-Za-z0-9_]/', '', ATOM) !== ATOM) wp_die('Invalid characters');

    // old wp version?
    if(!atom_register_hooks()) return;

    // load modules
    $active_modules = get_option(ATOM.'-atom-mods');

    // enable all modules from the parent theme dir if the option doesn't exist (first use)
    if($active_modules === false){
      $active_modules = array_keys($this->getModules('core'));
      update_option(ATOM.'-atom-mods', $active_modules);
    }

    if(is_array($active_modules))
      foreach($active_modules as $module){
        $type = false;

        // check (possible) child theme first
        if(is_readable(STYLESHEETPATH.'/mods/'.$module.'/module.php')){
          require(STYLESHEETPATH.'/mods/'.$module.'/module.php');
          $type = is_child_theme() ? 'user' : 'core';

        // parent theme, only check if a child theme is active
        }elseif(is_child_theme() && is_readable(TEMPLATEPATH.'/mods/'.$module.'/module.php')){
          require(TEMPLATEPATH.'/mods/'.$module.'/module.php');
          $type = 'core';
        }

        $class = "AtomMod{$module}";
        if($type && class_exists($class)){
          $instance = new $class($module, $type);
          $instance->init();
        }elseif($type){
          $this->addDebugMessage("&lt;{$class}&gt; class not found. Mod not loaded");
        }else{
          $this->addDebugMessage("&lt;{$class}&gt; is missing files. Mod not loaded");
        }
      }

    // load and synchronize theme options
    $this->syncOptions();

    // editor-style.css
    add_editor_style('css/editor.css');


    if(!empty($this->supported_features))
      foreach($this->supported_features as $feature) add_theme_support($feature);

    // post formats
    if($this->post_formats)
      add_theme_support('post-formats', $this->post_formats);

    // post thumbnails
    if($this->options('post_thumbs')){

      // set post thumbnail size
      $post_thumb = ($this->options('post_thumb_size') == 'media') ? array(get_option('thumbnail_size_w'), get_option('thumbnail_size_h')) : explode('x', $this->options('post_thumb_size'));
      list($w, $h) = $post_thumb;
      set_post_thumbnail_size($w, $h, true); // same as add_image_size('post-thumbnail' ...);

      // extra sizes, these are registered a little later...
      if($this->options('featured_thumb_size')){
        list($w, $h) = explode('x', Atom::app()->options('featured_thumb_size'));
        add_image_size('featured-thumbnail', $w, $h, true);
      }

    }

    // nav menus
    if(!empty($this->menus)) register_nav_menus($this->menus);

    // adjust content width variable, probably useless...
    if(!isset($GLOBALS['content_width']) && $this->options('page_width') === 'fixed'){
      $primary = explode(";", $this->options('dimensions_fixed_'.$this->options('layout')));
      $primary = empty($primary[0]) ? 960 : (int)$primary[0];
      $GLOBALS['content_width'] = ($primary - 20);
    }

    // hooks
    if($this->options('remove_settings'))
      add_action('switch_theme', array(&$this, 'uninstall'));

    // set up administration pages, if we're in the dashboard
    if(is_admin()) Atom::admin();

    /*/ gzipped output -- needs more testing
    if($this->options('optimize') && !defined('DOING_AJAX') && extension_loaded("zlib") && (ini_get("output_handler") != "ob_gzhandler"))
      // && substr_count($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip') && stripos($_SERVER['REQUEST_URI'], 'wp-includes/js/tinymce') === false
      add_action('get_header', create_function('', '@ob_end_clean();@ini_set("zlib.output_compression", 1);')); // before output starts

    //*/

//    if(USE_THEMED_ADMIN_BAR)
//      if(!is_admin()){
//        remove_action('wp_footer', 'wp_admin_bar_render', 1000);
//        remove_action('admin_footer', 'wp_admin_bar_render', 1000);
//        add_action('wp_footer', 'atom_admin_bar', 1000);
//        add_action('admin_footer', 'atom_admin_bar', 1000);
//      }


    atom_user_functions($this->user_functions);

    $this->action('core');

    define('ATOM_INITIALIZED', true);

  }



  /**
   * Get the appropriate layout type for the current page
   *
   * @since 1.0
   * @global $post object
   *
   * @return string The layout type
   */
  public function getLayoutType(){
    global $post;

    if(is_404()){
      $layout = 'c1';
    }else{

      // the "layout" custom field - highest priority
      if(isset($post->ID)) $layout = get_post_meta($post->ID, 'layout', true);

      // custom page templates - lower priority
      if(empty($layout) && (is_single() || is_page()) && ($page_template = sanitize_html_class(str_replace(array('page-', '.php'), '', get_post_meta($post->ID, '_wp_page_template', true)))))
        if(in_array($page_template, $this->layout_types)) $layout = $page_template;

      // if no template is defined so far, revert to the global layout option from the theme settings - lowest priority
      if(empty($layout)) $layout = $this->options('layout');

    }

    if(!Atom::app()->previewMode()){
      $s1_active = ($layout !== 'c1') ? $this->isAreaActive('sidebar1') : false;
      $s2_active = ($layout !== 'c1' && $layout !== 'c2left' && $layout !== 'c2right') ? $this->isAreaActive('sidebar2') : false;

      // revert to a different layout if the current area is empty (or no widgets are visible)
      if(!$s1_active && ($layout !== 'c1')) $layout = 'c1';
      if(!$s2_active && ($layout === 'c3' || $layout === 'c3left')) $layout = $s1_active ? 'c2left' : 'c1';
      if(!$s2_active && ($layout === 'c3' || $layout === 'c3right')) $layout = $s1_active ? 'c2right' : 'c1';

    }

    return $layout;
  }



  /**
   * Get the status of a widgetized area (replaces wp's is_active_sidebar)
   * This function also verifies if the widgets inside the sidebar are visible to the current user or not (splitters are ignored)
   * Note: If we're in preview mode areas are always considered to be active, but the returned widget count may be 0 (boolean false).
   * (we use type equivalence checking to avoid confusions)
   *
   * @since 1.0
   *
   * @global $wp_registered_widgets Stored registered widgets.
   * @global $post Current post object
   *
   * @param string $index Area (sidebar) ID
   * @return int|bool false or the visible widget count, based on widget visibility settings and current user status
   */
  public function isAreaActive($index){
    global $wp_registered_widgets, $post;

    // always return true if the layout options are not enabled. obviously, the css designer wants to handle this
    if(!$this->isOptionEnabled('layout')) return true;

    // -- same as getLayoutType() --
    if(is_404()){
      $layout = 'c1'; // 404 pages have 1 column layout
    }else{
      // the "layout" custom field - highest priority
      if(isset($post->ID)) $layout = get_post_meta($post->ID, 'layout', true);

      // custom page templates - lower priority
      if(empty($layout) && (is_single() || is_page()) && ($page_template = sanitize_html_class(str_replace(array('page-', '.php'), '', get_post_meta($post->ID, '_wp_page_template', true)))))
        if(in_array($page_template, $this->layout_types)) $layout = $page_template;

      // if no template is defined so far, revert to the global layout option from the theme settings - lowest priority
      if(empty($layout)) $layout = $this->options('layout');
    }
    // -- /same as getLayoutType() --

    $index = (is_int($index)) ? "sidebar{$index}" : sanitize_html_class($index);
    $sidebars_widgets = wp_get_sidebars_widgets();

    $visible_widgets = 0;

    // only check widget settings if we have widgets in this sidebar
    if(!empty($sidebars_widgets[$index]))
      foreach($sidebars_widgets[$index] as $i => $w)
        if(isset($wp_registered_widgets[$w])){
          $number = $wp_registered_widgets[$w]['params'][0]['number'];


          $callback = AtomWidget::getObject($w);
          if(!$callback) continue;

          $options = get_option($callback->option_name);

          // count only visible widgets that are not "splitters"
          // @important atom_visibility_check() can also return array(), which means that the widget is there but it's settings are missing (like fallback widgets)
          if((strpos($w, 'atom-splitter') === false) && atom_visibility_check($options[$number]) !== false) $visible_widgets++;
        }


    // always show active if we're in preview mode (eg. theme setting site preview), regardless of the contents
    if(Atom::app()->previewMode()) return $visible_widgets;

    // check free column(s) for sidebar(s)
    if($index === 'sidebar1' && $layout === 'c1') return false;
    if($index === 'sidebar2' && in_array($layout, array('c1', 'c2left', 'c2right'))) return false;

    // get sidebar contents
    $first_check = false;
    if(!isset($this->widget_areas[$index]['output'])){
      ob_start();
      dynamic_sidebar($index);
      $this->widget_areas[$index]['output'] = ob_get_clean();
      $first_check = true;
    }

    // filter cannot be applied to the global variable because the column splitter can make irreversible changes
    $area_contents = apply_filters('atom_area_check', $this->widget_areas[$index]['output'], $index);

    if(empty($area_contents) && $first_check) $this->addDebugMessage("No active widgets in &lt;{$index}&gt;. Area disabled.");
    if((!empty($sidebars_widgets[$index]) && ($visible_widgets > 0)) && !empty($area_contents)) return $visible_widgets;
    return false;
  }



  /**
   * Set supported theme features
   *
   * @since 1.8
   *
   * @param string $feature Feature (can accept multiple arguments)
   */
  public function setSupportedFeatures(){
    $args = func_get_args();
    if(!$this->supported_features) $this->supported_features = array_values($args);
  }



  /**
   * Capture the output of a widget area (sidebar); uses output buffering to allow content filtering.
   * Certain design types (like "Arclite") might need this to correct widget HTML.
   * This function also checks if the number of widget splitters present in the sidebars are even, and adds the closing splitter tags if necessary.
   *
   * @since 1.3
   *
   * @param string $area Sidebar ID
   * @param bool $echo Echo result, true by default
   *
   * @return string|bool HTML output/true, or false if sidebar is empty
   */
  public function getWidgets($area){

    // get sidebar contents (this shouldn't run because cache should be set by is_active_area above which is called early)
    if(!isset($this->widget_areas[$area]['output'])){
      ob_start();
      dynamic_sidebar($area);
      $this->widget_areas[$area]['output'] = ob_get_clean();
    }

    $this->widget_areas[$area]['output'] = apply_filters('atom_widget_area', $this->widget_areas[$area]['output'], $area);

    return empty($this->widget_areas[$area]['output']) ? false : $this->widget_areas[$area]['output'];
  }



  /**
   * Get the output of a widget instance
   *
   * @since 1.3
   * @global array $wp_registered_widgets
   * @global array $wp_registered_sidebars
   *
   * @param string $widget_id The widget instance ID
   * @param string $area Use this sidebar parameters to render the widget (default is 'arbitrary')
   * @param bool|string $remove_title Display or hide the title (eg. remove 'h2', 'h3' or false to keep the title)
   *
   * @return string Widget HTML output
   */
  public function getWidget($widget_id, $area = 'arbitrary', $remove_title = 'h3'){
    global $wp_registered_widgets, $wp_registered_sidebars;

    $widget_contents = wp_cache_get("arbitrary_{$widget_id}");
    if($widget_contents === false){

      // does the instance exist?
      $callback = AtomWidget::getCallback($widget_id);

      if(!$callback)
        return $this->addDebugMessage("Requested widget instance doesn't exist: {$widget_id}");

      ob_start();  // catch the echo output, so we can control where it appears in the text

      $params = array_merge(array(array_merge($wp_registered_sidebars[$area], array('widget_id' => $widget_id, 'widget_name' => $wp_registered_widgets[$widget_id]['name']))), (array)$wp_registered_widgets[$widget_id]['params']);

      // align classes?
      //if($align) $params[0]['before_widget'] = str_replace('block', 'block align'.$align, $params[0]['before_widget']);

      // Substitute HTML id and class attributes into before_widget
      $classname_ = '';
      foreach((array)$wp_registered_widgets[$widget_id]['classname'] as $cn)
        if(is_string($cn)) $classname_ .= '_'.$cn; elseif(is_object($cn)) $classname_ .= '_'.get_class($cn);
      $classname_ = ltrim($classname_, '_');
      $params[0]['before_widget'] = sprintf($params[0]['before_widget'], $widget_id, $classname_);
      $params = apply_filters('dynamic_sidebar_params', $params);

      if(is_callable($callback)) call_user_func_array($callback, $params);

      // remove h3?
      $widget_contents = $remove_title ? preg_replace('#<'.$remove_title.' class="title">(.*?)</'.$remove_title.'>#', '', ob_get_clean()) : ob_get_clean();

      wp_cache_set("arbitrary_{$area}", $widget_contents);
    }

    return apply_filters('atom_widget', $widget_contents, $widget_id); // probably useless filter
  }



  /**
   * Check if a comment search is being made
   *
   * @since 1.3
   *
   * @return string The search query
   */
  public static function commentSearch(){
    if(isset($_POST['comment-filter']) && Atom::app()->options('comment_filter')) return esc_attr($_POST['comment-filter']);
  }



  /**
   * Get the current page URL
   *
   * @since 1.0
   *
   * @return string the page URL.
   */
  public static function getCurrentPageURL() {
    $request = esc_url($_SERVER["REQUEST_URI"]);

    // wp-themes fake request url fix :)
    if(strpos($_SERVER["SERVER_NAME"], 'wp-themes.com') !== false) $request = str_replace($request, '/wordpress/', '/');

    // ssl?
    $pageURL = (is_ssl() ? 'https' : 'http').'://';
    if($_SERVER["SERVER_PORT"] != "80") $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$request; else $pageURL .= $_SERVER["SERVER_NAME"].$request;

    // check if the site uses "www" or not
    if(strpos(home_url(), '://www.') === false) $pageURL = str_replace('://www.', '://', $pageURL);
    if(strpos(home_url(), '://www.') !== false && strpos($pageURL, '://www.') === false) $pageURL = str_replace('://', '://www.', $pageURL);

    return $pageURL;
  }



  /**
  * Create pagination links for the comments on the current post.
  *
  * @see paginate_links()
  *
  * @param string $classes Optional classes
  * @param string|array $args Optional args. See paginate_links.
  */
  public function getCommentNavi($classes = '', $args = array()){

    // no pagination if it's disabled in the options, or when searching comments
    if(!get_option('page_comments') || $this->commentSearch()) return;

    $current_page = get_query_var('cpage');

    $links = paginate_links(wp_parse_args($args, array(
      'base'         => $GLOBALS['wp_rewrite']->using_permalinks() ? user_trailingslashit(trailingslashit(get_permalink()).'comment-page-%#%', 'commentpaged') : add_query_arg('cpage', '%#%'),
      'format'       => '',
      'total'        => $this->post->countCommentPages(),
      'current'      => $current_page ? $current_page : 1,
      'add_fragment' => '#comments'
    )));

    if($links) return "<div class=\"page-navi {$classes}\">\n{$links}\n</div>\n";
  }



  /**
  * To be used as as redirect_to input field in the comment form, as get_comment_link() is unreliable
  * because we replaced the default comment walker with one that takes nested comments into account when building pagination...
  *
  * @since 1.7
  */
  public function getCommentPostRedirectURL(){

    $url = get_permalink($this->post->getID());

    if(get_option('page_comments') && get_option('comments_per_page')){
      $cpage = (int)get_query_var('cpage');

      if($cpage && (int)$GLOBALS['wp_query']->max_num_comment_pages !== $cpage)
        $url = ($GLOBALS['wp_rewrite']->using_permalinks()) ? user_trailingslashit(trailingslashit($url).'comment-page-'.$cpage, 'comment') : add_query_arg('cpage', $cpage, $url);
    }

    return $url;
  }



  /**
  * Renders a ATOM-specific template, like "teaser", "comment", "about-the-author", "meta" etc.
  *
  * @see http://codex.wordpress.org/Template_Hierarchy
  * A similar template hierarchy system is implemented here
  *
  * @param string $_name Template name
  *
  * @since 1.7
  */
  public function template($_name, $_query = null){

    // @todo: improve
    if(strpos($_name, 'teaser') !== false){

      // reset current post
      if(is_null($_query))
        the_post();
      elseif($_query !== false)
        $_query->the_post();

      $this->setCurrentPost(false); // will use the global set by the_post()
    }else{
      $this->resetCurrentPost();
    }

    // 3rd party comments template? eg. intense debate
    // then load it, and forget about meta...
    if($_name === 'meta' && ($custom_template = apply_filters('comments_template', ''))){
      if(file_exists($custom_template)) require($custom_template);
      return;
    }

    $_templates = apply_filters("atom_{$_name}_template", array(
      $_name.'-'.$this->post->getID().'.php',
      $_name.'-'.$this->post->getType().'-'.$this->post->getFormat().'.php',
      $_name.'-'.$this->post->getType().'.php',
      $_name.'-'.$this->post->getFormat().'.php',
      $_name.'.php',
    ));

    $_location = false;
    foreach($_templates as $template)
      if(file_exists(STYLESHEETPATH.'/'.$template)){
        $_location = STYLESHEETPATH.'/'.$template;
        break;
      }elseif(file_exists(TEMPLATEPATH.'/'.$template)){
        $_location = TEMPLATEPATH.'/'. $template;
        break;
      }

    if(!$_location) return $this->addDebugMessage('Template file not found: "'.$_name.'". Skipping...', 1);

    $this->action("before_{$_name}");

    // a reference to the Atom instance that can be used in the templates
    $app = &$this;
    require $_location;

    if(!in_array($_name, array('comment', 'ping'))) $this->action("after_{$_name}");

  }



  /**
   * Renders a simple block template (really basic templating system for widgets). Replaces {VAR} with $parameters['var'];
   * original was from: Fabien Potencier's "Design patterns revisited with PHP 5.3" (page 45), but this version is a little faster
   *
   * @param string $string
   * @param array $parameters
   *
   * @return string
   */
  public function getBlockTemplate($string, $parameters = array()){

    // replace {KEYWORDS} with variable values
    foreach($parameters as $find => $replace){
      $finds[] = '{'.$find.'}';
      $replaces[] = $replace;
    }

    return str_replace($finds, $replaces, $string);
  }



  /**
   * Create nonce
   *
   * @since 1.3
   *
   * @param string $req
   */

  public function getNonce($req){
    return wp_create_nonce("atom_{$req}");
  }




  /**
   * Return a list of sites for the current network (replaces old get_blog_list())
   * based on http://core.trac.wordpress.org/ticket/14511
   *
   * @since 1.3
   * @global $wpdb
   *
   * @param array|string $args Optional. Override default arguments.

   * @return array site list and values
   */
  public function getSites($args = array()){
    global $wpdb;

    $defaults = array(
      'exclude_id'        => '',             // excludes these sites from the results, comma-delimted
      'blogname_like'     => '',             // domain or path is like this value
      'reg_date_since'    => '',             // sites registered since (accepts pretty much any valid date like tomorrow, today, 5/12/2009, etc.)
      'reg_date_before'   => '',             // sites registered before
      'exclude_user_id'   => '',             // don't include sites owned by these users, comma-delimited
      'exclude_archived'  => false,          // exclude archived sites
      'exclude_spam'      => false,          // exclude spammy sites
      'exclude_mature'    => false,          // exclude blogs marked as mature
      'public_only'       => true,           // Include only blogs marked as public
      'sort_column'       => 'last_updated', // or registered, last_updated, site_id
      'order'             => 'ASC',          // or desc
      'limit_results'     => false,          // return this many results
      'start'             => 0,              // return results starting with this item
    );

    // array_merge
    $r = wp_parse_args($args, $defaults);
    extract($r, EXTR_SKIP);

    $query = "SELECT {$wpdb->blogs}.blog_id, {$wpdb->blogs}.domain, {$wpdb->blogs}.path, {$wpdb->blogs}.registered, {$wpdb->blogs}.last_updated, {$wpdb->blogs}.public, {$wpdb->blogs}.archived, {$wpdb->blogs}.mature, {$wpdb->registration_log}.email FROM {$wpdb->blogs}, {$wpdb->registration_log} WHERE site_id = '{$wpdb->siteid}' AND {$wpdb->blogs}.blog_id = {$wpdb->registration_log}.blog_id ";

    if(!empty($exclude_id))
      $query .= " AND {$wpdb->blogs}.blog_id NOT IN ('".implode("','", explode(',', $exclude_id))."') ";

    if(!empty($blogname_like))
      $query .= " AND ({$wpdb->blogs}.domain LIKE '%{$blogname_like}%' OR {$wpdb->blogs}.path LIKE '%{$blogname_like}%') ";

    if(!empty($reg_date_since))
      $query .= " AND unix_timestamp({$wpdb->registration_log}.date_registered) > '".strtotime($reg_date_since)."' ";

    if(!empty($reg_date_before))
      $query .= " AND unix_timestamp({$wpdb->registration_log}.date_registered) < '".strtotime($reg_date_before)."' ";

    if(!empty($exclude_user_id)){
      $the_users = explode(',', $exclude_user_id);
      $the_emails = array();
      foreach((array)$the_users as $user_id){
        $the_user = get_userdata($user_id);
        $the_emails[] = $the_user->user_email;
       }
      $list = implode("','", $the_emails);
      $query .= " AND {$wpdb->registration_log}.email NOT IN ('{$list}') ";
    }

    if($public_only) $query .= " AND {$wpdb->blogs}.public = '1'";
    if($exclude_archived) $query .= " AND {$wpdb->blogs}.archived = '0'";
    if($exclude_spam) $query .= " AND {$wpdb->blogs}.spam = '0'";
    if($exclude_mature) $query .= " AND {$wpdb->blogs}.mature = '0'";

    if($sort_column == 'id')
      $query .= " ORDER BY {$wpdb->blogs}.blog_id ";
    elseif($sort_column == 'last_updated')
      $query .= " ORDER BY last_updated ";
    elseif($sort_column == 'registered')
      $query .= " ORDER BY {$wpdb->blogs}.registered ";


    $order = ('DESC' == $order) ? 'DESC' : 'ASC';
    $query .= $order;

    $limit = '';
    if($limit_results){
      if($start !== 0) $limit = $start.", ";
      $query .= ' LIMIT '.$limit.$limit_results;
    }

    $query = $wpdb->prepare($query);

    // check cache
    $key = md5($query);
    $cache = wp_cache_get('get_sites', 'atom');
    if(!isset($cache[$key])){
      $entries = $wpdb->get_results($query, ARRAY_A);
      $cache[$key] = $entries;
      wp_cache_set('get_sites', $cache, 'atom');
    }else{
      $entries = $cache[$key];
    }

    return empty($entries) ? array() : $entries;
  }




  /**
   * Get the user avatar based on his email address
   *
   * @since 1.0
   *
   * @param string $email Valid Email Address
   * @param int $size Optional. Image size
   * @param string $default Default image
   * @param string $alt Alternate text
   * @return string Avatar image (HTML)
   */
  public function getAvatar($email, $size = 48, $default = '', $alt = false){

    // if today is April 1st show a pony :)
    if(date('m-d') == '04-01') return
      '<img class="avatar" onclick="cornify_add();return false;" src="http://unicornify.appspot.com/avatar/'.md5($email).'?s='.$size.'" alt="One Trick Pony" title="One Trick Pony" width="'.$size.'" height="'.$size.'" /><script src="http://www.cornify.com/js/cornify.js"></script>';

    // if not, display the user's gravatar
    return get_avatar($email, $size, $default, $alt);
  }




  /**
   * Number of posts/comments user has written.
   * Can count custom post types
   *
   * @since 1.3
   * @uses $wpdb WordPress database object for queries.
   *
   * @param int $user_id (optional) Count only posts/comments of a user
   * @param int $what_to_count Post types or comments, Default is "post"
   *
   * @return int count
   */
  public static function getCount($user_id = null, $what_to_count = 'post') {
    global $wpdb;
    if(strtoupper($user_id) == 'ALL') $user_id = null;

    $where = $what_to_count == 'comment' ? "WHERE comment_approved = 1" : get_posts_by_author_sql($what_to_count, TRUE, $user_id);
    if(!empty($user_id) && $what_to_count == 'comment') $where .= " AND user_id = {$user_id}";

    $from = "FROM ".(($what_to_count == 'comment') ? $wpdb->comments : $wpdb->posts);

    $query = $wpdb->prepare("SELECT COUNT(*) {$from} {$where}");

    // check cache
    $key = md5($query);
    $cache = wp_cache_get('get_count', 'atom');
    if(!isset($cache[$key])){
      $count = $wpdb->get_var($query);
      $cache[$key] = $count;
      wp_cache_set('get_count', $cache, 'atom');
    }else{
      $count = $cache[$key];
    }

    return apply_filters("atom_user_{$what_to_count}_count", (int)$count, $user_id);
  }



  /**
   * Display or retrieve the HTML dropdown list of terms or posts.
   * Replaces wp_dropdown_categories() and wp_dropdown_pages.
   * Almost same behaviour, the only difference is the "extra_attributes" argument (to allow the use of form dependency rules),
   * and more flexibility with custom post types/taxonomies
   *
   * @since 1.4
   *
   * @param array $what Post type or taxonomy
   * @param array $args Arguments
   *
   * @return string HTML
   */
  public function getDropdown($what = 'category', $args = array()){

    $defaults = array(
      'show_option_all'    => '',
      'show_option_none'   => '',
      'show_last_update'   => 0,           // useless option that throws a notice if not present; deprecated maybe?
      'option_none_value'  => -1,
      'orderby'            => 'id',
      'order'              => 'ASC',
      'show_count'         => 0,           // tax only
      'hide_empty'         => 1,           // tax only
      'hide_if_empty'      => false,
      'child_of'           => 0,           // tax only
      'post_parent'        => '',          // posts only
      'exclude'            => '',
      'selected'           => 0,
      'hierarchical'       => 1,
      'numberposts'        => -1,          // posts only
      'name'               => 'category',
      'id'                 => '',
      'class'              => '',
      'depth'              => 0,
      'tab_index'          => 0,
      'extra_attributes'   => '',          // like dependency rules
      'pad_counts'         => true,        // tax only, hierarchical must be true
    );

    if(array_key_exists($what, get_taxonomies())){
      $defaults['taxonomy'] = $what;
      $_is_tax = true;
    }else{
      $defaults['post_type'] = $what;
      $_is_tax = false;
    }

    // current category selected by default ($args overrides it)
    if($_is_tax) $defaults['selected'] = (is_category()) ? get_query_var('cat') : 0;

    $r = wp_parse_args($args, $defaults);

    extract($r);
    unset($r['name'], $r['id'], $r['class']); // conflicts with get_posts(), possible others too

    $tab_index_attribute = ((int)$tab_index > 0) ? " tabindex=\"{$tab_index}\"" : '';
    $entries = $_is_tax ? get_terms($taxonomy, $r) : get_posts($r);

    $name = esc_attr($name);
    $class = $class ? ' class="'.esc_attr($class).'"' : '';
    $id = $id ? ' id="'.esc_attr($id).'"' : '';

    // no entries, return if hide_if_empty is enabled
    if(empty($entries) && $hide_if_empty) return false;

    $output = "<select name=\"{$name}\" {$id} {$class} {$extra_attributes} {$tab_index_attribute}>\n";
    if(empty($entries) && !empty($show_option_none)){
      $show_option_none = apply_filters('list_cats', $show_option_none);
      $output .= "\t<option value=\"".esc_attr($option_none_value)."\" selected=\"selected\">{$show_option_none}</option>\n";
    }

    if(!empty($entries)){
      if($show_option_all){
        $show_option_all = apply_filters('list_cats', $show_option_all);
        $selected = ('0' === strval($r['selected'])) ? ' selected="selected"' : '';
        $output .= "\t<option value='0'{$selected}>{$show_option_all}</option>\n";
      }
      if($show_option_none){
        $show_option_none = apply_filters('list_cats', $show_option_none);
        $selected = ('-1' === strval($r['selected'])) ? ' selected="selected"' : '';
        $output .= "\t<option value='-1'{$selected}>{$show_option_none}</option>\n";
      }
      $depth = $hierarchical ? $r['depth'] : -1; // // walk the full depth or flat
      $output .= $_is_tax ? walk_category_dropdown_tree($entries, $depth, $r) : walk_page_dropdown_tree($entries, $depth, $r);
    }

    $output .= "</select>\n";
    $output = apply_filters($_is_tax ? 'wp_dropdown_pages' : 'wp_dropdown_cats', $output);

    return $output;
  }




  /**
   * Default navigation, only displayed if no custom menu is set as the primary navigation.
   * Contents are the home link and a list of pages (and sub-pages if there are any).
   * This function replaces wp_page_menu because of the markup differences between it and wp_nav_menu.
   *
   * @since 1.3
   *
   * @param array $args Arguments
   */
  public function getPageMenu($args = array()){

    $defaults = array(
      'container'           => 'div',
      'container_class'     => '',
      'container_id'        => '',
      'menu_class'          => 'menu',
      'menu_id'             => '',

      // these two are ignored by wp_page_menu; @todo: find a way to use them on the generated menu, regex maybe?
      'before'              => '',
      'after'               => '',

      'link_before'         => '',
      'link_after'          => '',
      'depth'               => 0,
      'walker'              => '',
      'slug'                => 'menu-pages', // extra
      'include_home'        => true,
      'exclude'             => '',
      'post_type'           => 'page',       // @todo: test support

      'sort_column'         => 'menu_order, post_title',
    );

    $args = wp_parse_args($args, $defaults);
    $args = apply_filters('wp_nav_menu_args', $args);

    $nav_menu = $items = '';

    $show_container = false;
    if($args['container']){
      $allowed_tags = apply_filters('wp_nav_menu_container_allowedtags', array('div', 'nav'));
      if(in_array($args['container'], $allowed_tags)){
        $show_container = true;
        $class = $args['container_class'] ? ' class="'.$args['container_class'].'"' : ' class="menu-'.$args['slug'].'-container"';
        $id = $args['container_id'] ? ' id="'.$args['container_id'].'"' : '';
        $nav_menu .= '<'.$args['container'].$id.$class. '>';
      }
    }

    // add 'home' menu item
    if($args['include_home'])
      $items .= '<li class="menu-home '.((is_front_page() && !is_paged()) ? 'active' : '').'"><a href="'.home_url('/').'" title="'._a('Home Page').'">'.$args['link_before']._a("Home").$args['link_after'].'</a></li>';

    // get page list
    $page_list_args = (array)$args;

    // if the front page is a page, add it to the exclude list for get_posts() below
    if(get_option('show_on_front') === 'page'){
      $page_list_args['exclude'] = explode(',', $args['exclude']);
      $page_list_args['exclude'][] = get_option('page_on_front');
      $page_list_args['exclude'] = implode(',', $page_list_args['exclude']);
    }

    $page_list_args['walker'] = ''; // use page walker here to avoid conflicts with nav menu walkers
    $pages = get_pages($page_list_args);

    if(!empty($pages)){
      global $wp_query;
      $current_page = (($args['post_type'] == get_query_var('post_type')) || is_attachment() || is_page() || $wp_query->is_posts_page) ? $wp_query->get_queried_object_id() : false;
      $items .= apply_filters('wp_list_pages', walk_page_tree($pages, $args['depth'], $current_page, $page_list_args), $page_list_args);
    }

    // attributes
    if(!empty($args['menu_id'])) $slug = $args['menu_id']; else $slug = 'menu-'.$args['slug'];

    $attributes = ' id="'.$slug.'"';
    $attributes .= $args['menu_class'] ? ' class="'.$args['menu_class'].'"' : '';

    $nav_menu .= '<ul'.$attributes.'>';
    $nav_menu .= $items;
    $nav_menu .= '</ul>';

    if($show_container) $nav_menu .= '</'.$args['container'].'>';
    $nav_menu = apply_filters('wp_page_menu', $nav_menu, $args);

    return $nav_menu;
  }


  /**
   * Category navigation, not used by default (maybe some child themes will use it)
   * Contents are the home link and a list of categories/sub-categories
   * @todo: NEEDS UPDATE!
   *
   * @since 1.2
   */
  public function getCategoryMenu($args = array()){
    $defaults = array(
      'container'           => 'div',
      'container_class'     => '',
      'container_id'        => '',
      'menu_class'          => 'menu',
      'menu_id'             => '',
      'before'              => '',    // these two are ignored by wp_page_menu; @todo: find a way to use them on the generated menu, regex maybe?
      'after'               => '',
      'link_before'         => '',
      'link_after'          => '',
      'depth'               => 0,
      'walker'              => '',
      'slug'                => 'menu-categories', // extra
      'include_home'        => true,
    );

    $args = wp_parse_args($args, $defaults);
    $args = apply_filters('wp_nav_menu_args', $args);
    $args = (object)$args;

    $nav_menu = $items = '';

    $show_container = false;
    if($args->container){
      $allowed_tags = apply_filters('wp_nav_menu_container_allowedtags', array('div', 'nav'));
      if(in_array($args->container, $allowed_tags)){
        $show_container = true;
        $class = $args->container_class ? ' class="'.$args->container_class.'"' : ' class="menu-'.$args->slug.'-container"';
        $id = $args->container_id ? ' id="'.$args->container_id.'"' : '';
        $nav_menu .= '<'.$args->container.$id.$class. '>';
      }
    }

    // add 'home' menu item
    if($args->include_home)
      $items .= '<li class="menu-home '.((is_front_page() && !is_paged()) ? 'active' : '').'"><a href="'.home_url('/').'" title="'._a('Home Page').'">'.$args->link_before._a("Home").$args->link_after.'</a></li>';

    // pass arguments to wp_list_pages (most of them are ignored)
    $category_list_args = (array)$args;

    // other extra arguments
    $category_list_args['echo'] = false;
    $category_list_args['title_li'] = '';
    $category_list_args['show_option_none'] = '';
    $category_list_args['slug'] = '';
    $category_list_args['walker'] = new AtomWalkerTerms();

    // get category list
    $items .= str_replace(array("\r", "\n", "\t"), '', wp_list_categories($category_list_args));

    // attributes
    if(!empty($args->menu_id)) $slug = $args->menu_id; else $slug = 'menu-'.$args->slug;

    $attributes = ' id="'.$slug.'"';
    $attributes .= $args->menu_class ? ' class="'.$args->menu_class.'"' : '';

    $nav_menu .= '<ul'.$attributes.'>';
    $nav_menu .= $items;
    $nav_menu .= '</ul>';

    if($show_container) $nav_menu .= '</'.$args->container.'>';
    //$nav_menu = apply_filters('wp_category_menu', $nav_menu, $args);

    return $nav_menu;
  }



  /**
   * Displays control links, like 'post-edit', 'post-print', 'comment-reply' etc.
   *
   * @since 1.6
   *
   * @param string $args Comma separated arguments...
   */
  public function getControls(){
    $args = func_get_args();
    $args = array_values($args);

    $links = array();
    foreach($args as $arg){
      list($object, $control) = explode('-', $arg);
      $control = apply_filters("atom_{$object}_{$control}_control", $this->$object->getControl($control));
      if($control){
        $links[$arg] = '<a href="'.(isset($control['target']) ? $control['target'] : '#').'" class="'.$arg.'"';
        if(isset($control['data']))
          foreach($control['data'] as $key => $value) $links[$arg] .= " data-{$key}=\"{$value}\"";

        if(isset($control['id']))
          $links[$arg] .=' id="'.$control['id'].'"';

        $links[$arg] .= '>'.$control['label'].'</a>';
      }
    }

    if(!empty($links)) return "<div class=\"controls\">\n".implode("\n", $links)."</div>\n";
  }



  /**
   * Get user arguments for a specific context
   *
   * @since 1.7
   *
   * @param string $context Context. eg. 'pagenavi'
   * @param array $current_args Current arguments (can pass multiple parameters, they will all be merged)
   *
   * @return array New arguments
   */
  public function getContextArgs($context){

    $args = func_get_args();
    $args = array_values($args);

    if(isset($this->context_config[$context]))
      $args[] = $this->context_config[$context];

    array_shift($args); // drop the $context argument

    $current_args = array();

    foreach($args as $entry)
      if(!empty($entry))
        $current_args = (array)$entry + $current_args;

    return $current_args;
  }



  /**
   * Set user arguments for a specific context
   *
   * @since 1.7
   *
   * @param string $context Context
   * @param options $args Options
   *
   * @return array arguments
   */
  public function setContextArgs($context, $args){
    $this->context_config[$context] = $args;
  }



  /**
   * Add user arguments for a specific context
   *
   * @since 1.7
   *
   * @param string $context Context
   * @param options $args Options to add
   *
   * @return array arguments
   */
  public function addContextArgs($context, $args){
    $current_args = isset($this->context_config[$context]) ? $this->context_config[$context] : array();
    $this->context_config[$context] = $args + $current_args;
  }



  /**
   * Queues a debug message
   *
   * @since 1.3
   *
   * @param string $classes Optional, extra CSS classes to add to the container
   *
   * @return bool
   */
  public function addDebugMessage($message, $code = 2){
    if(!$this->options('debug') || !current_user_can('edit_theme_options')) return false;

    if(!is_wp_error($this->debug_messages)) $this->debug_messages = new WP_Error();
    $this->debug_messages->add($code, $message);

    return false; // required because in some cases we use this function as a return value for empty widgets etc.
  }


  public static function end(){
    atom_footer();
  }

}
