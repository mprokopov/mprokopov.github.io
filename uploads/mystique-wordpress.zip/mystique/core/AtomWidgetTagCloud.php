<?php

/**
 * Atom Tag Cloud Widget
 *
 * Tag Cloud from a list of taxonomy terms
 *
 * @since 1.0
 */
 
 
 
class AtomWidgetTagCloud extends AtomWidget{

  public function AtomWidgetTagCloud(){

    $this->WP_Widget('atom-tag-cloud', _a('Tag Cloud'), array('classname' => 'tag-cloud', 'description' => _a("Your most used tags in cloud format")));

    // default settings
    $this->setDefaults(array(
      'title'          => _a("Tags"),
      'taxonomy'       => 'post_tag',         
      'number'         => 36,
      'smallest'       => 10,
      'largest'        => 22,
      'gradient_start' => 'cccccc',
      'gradient_end'   => '333333',
    ));
  }

  // calculate the tag color based on tag importance, start & end gradient colors (props to konforce from StackOverflow)
  public static function getTagColor($weight, $mincolor, $maxcolor){
    $weight = $weight/100;

    $mincolor = hexdec($mincolor);
    $maxcolor = hexdec($maxcolor);

    $r1 = ($mincolor >> 16) & 0xff;
    $g1 = ($mincolor >> 8) & 0xff;
    $b1 = $mincolor & 0xff;

    $r2 = ($maxcolor >> 16) & 0xff;
    $g2 = ($maxcolor >> 8) & 0xff;
    $b2 = $maxcolor & 0xff;

    $r = $r1 + ($r2 - $r1) * $weight;
    $g = $g1 + ($g2 - $g1) * $weight;
    $b = $b1 + ($b2 - $b1) * $weight;

    return sprintf("%06x", (($r << 16) | ($g << 8) | $b));
  }

  // almost the same as WP's function, only added color styles & removed irrelevant arguments
  public static function generateTagCloud($tags, $args = ''){
    $defaults = array(      
      'smallest'                   => 8,
      'largest'                    => 22,
      'number'                     => 45,
      'gradient_start'             => false,
      'gradient_end'               => false,
      'order'                      => 'ASC',
      'topic_count_text_callback'  => 'default_topic_count_text',
      'topic_count_scale_callback' => 'default_topic_count_scale'
    );

    if(!isset($args['topic_count_text_callback']) && isset($args['single_text']) && isset($args['multiple_text'])):
      $body = 'return sprintf(_n('.var_export($args['single_text'], true).', '.var_export($args['multiple_text'], true).', $count), number_format_i18n($count));';
      $args['topic_count_text_callback'] = create_function('$count', $body);
    endif;

    $args = wp_parse_args($args, $defaults);
    extract($args);
    if(empty($tags)) return;

    $tags_sorted = apply_filters('tag_cloud_sort', $tags, $args);
    if($tags_sorted != $tags) { // the tags have been sorted by a plugin
      $tags = $tags_sorted;
      unset($tags_sorted);
    } else {
      if($order === 'RAND'){
        shuffle($tags);
      } else {
      // SQL cannot save you; this is a second (potentially different) sort on a subset of data.
        uasort($tags, create_function('$a, $b', 'return strnatcasecmp($a->name, $b->name);'));
        if($order === 'DESC') $tags = array_reverse($tags, true);
      }
    }

    if($number > 0) $tags = array_slice($tags, 0, $number);

    $counts = array();
    $real_counts = array(); // For the alt tag
    foreach((array) $tags as $key => $tag){
      $real_counts[$key] = $tag->count;
      $counts[$key] = $topic_count_scale_callback($tag->count);
    }

    $min_count = min($counts);
    $spread = max($counts) - $min_count;
    if($spread <= 0) $spread = 1;
    $font_spread = $largest - $smallest;
    if($font_spread < 0) $font_spread = 1;
    $font_step = $font_spread / $spread;

    $a = array();
    foreach($tags as $key => $tag){
      $count = $counts[$key];
      $real_count = $real_counts[$key];
      if($gradient_start && $gradient_end){
        if($largest == $smallest) $tag_weight = $largest; else $tag_weight = ($smallest+(($count-$min_count)*$font_step));
        $diff = $largest-$smallest;
        if($diff <= 0) $diff = 1;
        $color_weight = round(99*($tag_weight-$smallest)/($diff)+1);
        $tag_color = self::getTagColor($color_weight, $gradient_start, $gradient_end);
      }

      $tag_link = ('#' !== $tag->link) ? esc_url($tag->link) : '#';
      //$tag_id = isset($tags[$key]->id) ? $tags[$key]->id : $key;
      $size = ($smallest+(($count-$min_count)*$font_step));
      $name = $tags[$key]->name;
      if($size > 15) $name = "<strong>{$name}</strong>"; // bold if size > 15pt

      $a[] = "<a href=\"{$tag_link}\" class=\"tag-{$tags[$key]->slug}\" title=\"".esc_attr($topic_count_text_callback($real_count))."\" style=\"font-size:".sprintf("%01.1f", $size)."pt;".(isset($tag_color) ? "color:#{$tag_color};" : null)."\">{$name}</a>";
    }

    return apply_filters('wp_generate_tag_cloud', join("\n", $a), $tags, $args);
  }

  public static function tagCloud($args = ''){
    $defaults = array(
      'smallest'    => 8,
      'largest'     => 22,
      'number'      => 45,
      'order'       => 'ASC', // ASC/DESC/RAND -- @todo: maybe add a option for this?
      'exclude'     => '',
      'include'     => '',
      'taxonomy'    => 'post_tag',
    );

    $args = wp_parse_args($args, $defaults);
    $tags = get_terms($args['taxonomy'], array_merge($args, array('orderby' => 'count', 'order' => 'DESC'))); // Always query top tags
    if(empty($tags)) return;

    foreach($tags as $key => $tag):
      $link = get_term_link((int)$tag->term_id, $args['taxonomy']);
      if(is_wp_error($link)) return false;
      $tags[$key]->link = $link;
      $tags[$key]->id = $tag->term_id;
    endforeach;

    $output = self::generateTagCloud($tags, $args); // Here's where those top tags get sorted according to $args
    $output = apply_filters('wp_tag_cloud', $output, $args);
    return $output;
  }


  private function getCurrentTaxonomy($instance){
    if(!empty($instance['taxonomy']) && taxonomy_exists($instance['taxonomy'])) return $instance['taxonomy'];
    return 'post_tag';
  }

  public function widget($args, $instance){
    extract($args);

    // don't show the widget on our internal "tags" page
    if(Atom::app()->isPage('tags')) return;

    $instance = wp_parse_args($instance, $this->getDefaults());
    $current_taxonomy = $this->getCurrentTaxonomy($instance);
    $number = empty($instance['number']) ? 45 : $instance['number'];
    $smallest = empty($instance['smallest']) ? 8 : $instance['smallest'];
    $largest = empty($instance['largest']) ? 22 : $instance['largest'];
    $gradient_start = esc_attr($instance['gradient_start']);
    $gradient_end = esc_attr($instance['gradient_end']);
    $title = apply_filters('widget_title', $instance['title'], $instance, $this->id_base);

    $maybe_tags_link = ($current_taxonomy === 'post_tag') && ($tags_page = Atom::app()->getPageURL('tags', true)) ? '<a class="extra" href="'.$tags_page.'">('._a('Show All').')</a>' : '';


    echo $before_widget;
    if($title) echo $before_title.$title.$maybe_tags_link.$after_title;
    echo '<div class="box tagcloud">';
    echo $this->tagCloud(apply_filters('widget_tag_cloud_args', array(
      'taxonomy'       => $current_taxonomy,
      'number'         => $number,
      'smallest'       => $smallest,
      'largest'        => $largest,
      'gradient_start' => $gradient_start,
      'gradient_end'   => $gradient_end
     )));
    echo "</div>\n";
    echo $after_widget;
  }

  public function update($new_instance, $old_instance) {
    $instance['title']          = esc_attr($new_instance['title']);
    $instance['taxonomy']       = esc_attr($new_instance['taxonomy']);
    $instance['number']         = min(max((int)$new_instance['number'], 5), 1000);
    $instance['smallest']       = min(max((int)$new_instance['smallest'], 1), 100);
    $instance['largest']        = min(max((int)$new_instance['largest'], 1), 100);
    $instance['gradient_start'] = esc_attr($new_instance['gradient_start']);
    $instance['gradient_end']   = esc_attr($new_instance['gradient_end']);
    return $instance;
  }

  public function form($instance){
    $instance = wp_parse_args($instance, $this->getDefaults());
    $current_taxonomy = $this->getCurrentTaxonomy($instance);

    ?>
    <div <?php $this->formClass(); ?>>
      <p>
        <label for="<?php echo $this->get_field_id('title'); ?>"><?php _ae('Title:') ?></label>
        <input type="text" class="wide" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php if(isset($instance['title'])) echo esc_attr($instance['title']); ?>" />
      </p>

      <p>
        <label for="<?php echo $this->get_field_id('taxonomy'); ?>"><?php _ae('Taxonomy:') ?></label>
        <select class="wide" id="<?php echo $this->get_field_id('taxonomy'); ?>" name="<?php echo $this->get_field_name('taxonomy'); ?>">
         <?php foreach (get_object_taxonomies('post') as $taxonomy):
           $tax = get_taxonomy($taxonomy);
           if(!$tax->show_tagcloud || empty($tax->labels->name)) continue; ?>
         <option value="<?php echo esc_attr($taxonomy) ?>" <?php selected($taxonomy, $current_taxonomy) ?>><?php echo $tax->labels->name; ?></option>
         <?php endforeach; ?>
        </select>
      </p>

      <p>
        <label for="<?php echo $this->get_field_id('number'); ?>"><?php _ae('Max. number of tags to show:') ?></label>
        <input type="text" size="4" id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" value="<?php if(isset($instance['number'])) echo esc_attr($instance['number']); ?>" />
      </p>

      <p class="clear-block">
        <div class="alignleft">
          <label for="<?php echo $this->get_field_id('smallest'); ?>"><?php _ae('Smallest:') ?></label>
          <input type="text" size="4" id="<?php echo $this->get_field_id('smallest'); ?>" name="<?php echo $this->get_field_name('smallest'); ?>" value="<?php if(isset($instance['smallest'])) echo esc_attr($instance['smallest']); ?>" /> <small>pt</small>
        </div>
        <div class="color-selector alignright" id="<?php echo $this->get_field_id('gradient_start'); ?>">
          <div class="preview" style="background-color: #<?php echo esc_attr($instance['gradient_start']); ?>">
            <input name="<?php echo $this->get_field_name('gradient_start'); ?>" type="hidden" value="<?php echo esc_attr($instance['gradient_start']); ?>" />
          </div>
        </div>
      </p>

      <p class="clear-block">
        <div class="alignleft">
          <label for="<?php echo $this->get_field_id('largest'); ?>"><?php _ae('Largest:') ?></label>
          <input type="text" size="4" id="<?php echo $this->get_field_id('largest'); ?>" name="<?php echo $this->get_field_name('largest'); ?>" value="<?php if(isset($instance['largest'])) echo esc_attr($instance['largest']); ?>" /> <small>pt</small>
        </div>
        <div class="color-selector alignright" id="<?php echo $this->get_field_id('gradient_end'); ?>">
          <div class="preview" style="background-color: #<?php echo esc_attr($instance['gradient_end']); ?>">
            <input name="<?php echo $this->get_field_name('gradient_end'); ?>" type="hidden" value="<?php echo esc_attr($instance['gradient_end']); ?>" />
          </div>
        </div>
      </p>
      <script type="text/javascript">
        /*<![CDATA[*/
        jQuery(document).ready(function ($) {
          // color picker
          $('#<?php echo $this->get_field_id('gradient_start'); ?>, #<?php echo $this->get_field_id('gradient_end'); ?>').ColorPicker({
            onShow: function (colpkr) {
              jQuery(colpkr).css({ opacity: 0, marginTop: -10 }).show().animate({ opacity: 1, marginTop: 0 }, 160);
              jQuery(this).ColorPickerSetColor(jQuery(this).find('input').val());
              return false;
            },
            onHide: function (colpkr) {
              jQuery(colpkr).fadeOut(160);
              return false;
            },
            onChange: function (hsb, hex, rgb, el) {
              jQuery(el).find(".preview").css('background-color', '#'+hex);
              $input = jQuery(el).find('input');
              var target;
              $input.val(hex);
            }
          });
        });
        /*]]>*/
      </script>
      </div>
    <?php
  }

}