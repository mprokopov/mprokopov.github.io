<?php
/**
 * Module Name: Social-Media Icons
 * Description: Adds social media links and icons above the navigation area; Designed for the Mystique theme only. Ideas from <a href="http://marknhewitt.co.uk/my-web-portfolio/mystique-theme-edits/extra-nav-icons-for-the-mystique-theme/" target="_blank">Mark N Hewitt</a> & <a href="http://polpoinodroidi.com/">Frasten</a>.
 * Version: 1.6
 * Author: digitalnature
 * Author URI: http://digitalnature.eu
 */


// class name must follow this pattern (AtomMod + directory name)
class AtomModSocialMediaIcons extends AtomMod{

  // the folder name which stores user-uploaded icons (inside the child theme dir)
  const USER_ICON_DIR = 'social-media-icons';

  private
    $defaults,
    $icon_size,
    $sprite_path,
    $sprite_url;


  public function init(){

    $this->defaults = array(
      'rss'      => array(
                      'label' => _a('RSS Feeds'),
                      'uri'   => get_bloginfo('rss_url'),
                    ),

      'twitter'  => array(
                      'label' => _a('My Twitter'),
                      'uri'   => 'http://twitter.com/stewiegriffin/',
                     ),
    );

    // register extra theme options
    Atom::app()->addDefaultOptions(array('media_icons' => $this->defaults));

    // we're saving the sprite in /wp-content/uploads/
    $upload_dir = wp_upload_dir();

    $this->sprite_path = $upload_dir['basedir'].'/'.ATOM.'_media_icons.png';
    $this->sprite_url = $upload_dir['baseurl'].'/'.ATOM.'_media_icons.png';

    $this->icon_size = apply_filters('atom_media_icon_size', 64); // 64x64

    // hooks
    Atom::add('social_media_links', array(&$this, 'output'), 100);

    // there's very little css, not worth loading a new stylesheet so we add it inline
    Atom::add('inline_css', array(&$this, 'css'), 100);

    if(is_admin()){

      Atom::app()->addContextArgs('settings_update_errors', array(
        20 => _a('Failed to create sprite image with the selected icons. Make sure your upload directory is writable'),
      ));

      // insert a tab
      Atom::admin()->addTab('media', _a('Social-Media Icons'), array(&$this, 'form'), 32);

      Atom::add('save_options', array(&$this, 'save'));
      Atom::add('admin_js', array(&$this, 'js'));
      Atom::add('admin_jquery_init', array(&$this, 'jquery_init'));

      // ajax hooks
      add_action('wp_ajax_update_media_icon_cache', array(&$this, 'updateIconDataCache'));
    }
  }



  public function save($options){

    $icons_to_process = $this->getActiveIcons(); // same as array_keys($options['media_icons'])

    if(empty($icons_to_process)) return;

    if(!$this->generateSprite($icons_to_process, $this->sprite_path) && !is_readable($this->sprite_path)){
      $options['media_icons'] = array();
      Atom::app()->setOptions($options);
      Atom::admin()->setError(20);
    }

    // smush it installed? try to reduce the sprite size then... -- @todo: check this out because it fails on certain hosts
    //if(function_exists('wp_smushit')){
    //  list($probably_smushed_sprite, $messages) = wp_smushit($this->sprite_path);
    //  $this->sprite_path = $probably_smushed_sprite;
    //}

  }

  public function js(){
    wp_enqueue_script('jquery-ui-sortable');
  }



  public function jquery_init(){ ?>

    $('#social-media-icons').each(function(){
      var block = $(this),
          props = $('.properties', block);

      $('.icons', block).sortable({
        connectWith: '.icons',
        stop: function(event, ui){
          $(ui.item).trigger('click');

          if($(ui.item).parents('.inactive-icons').length > 0){

            // save input values
            $('input', $(ui.item)).each(function(){
              var property = /\[([^\]]*)\]$/.exec($(this).attr('name'))[1]; // last [...] from the input name
              $('img', $(ui.item)).data(property, $(this).val());
            });

            $('input', $(ui.item)).remove();
            return;
          }

          // check if new icons are being dropped, and append hidden fields
          if($('input', $(ui.item)).length < 1){
            var icon = $(ui.item).data('icon'),
                label = $('img', ui.item).data('label'),
                uri = $('img', ui.item).data('uri');

            $(ui.item).append('<input type="hidden" name="media_icons[' + icon +'][label]" value="' + label + '" />');
            $(ui.item).append('<input type="hidden" name="media_icons[' + icon +'][uri]" value="' + uri + '" />');
            $('#media_label').val(label);
            $('#media_uri').val(uri);

          };
        }
      }).disableSelection();

      $('.icons li', block).click(function(event){
        var icon = $(this).data('icon');

        // make sure we update the hidden fields
        $('input', props).trigger('blur');

        $('li', block).removeClass('selected');
        $(this).addClass('selected');

        if($(this).parents('.active-icons').length > 0){
          $('input', props).removeAttr('disabled');
          $('input, label', props).removeClass('disabled');

          $('input', this).each(function(){
            var property = /\[([^\]]*)\]$/.exec($(this).attr('name'))[1]; // last [...] from the input name
            $('#media_' + property).val($(this).val());
          })

        }else{

          $('input', props).attr('disabled', 'disabled').val('');
          $('input, label', props).addClass('disabled');
        }
      });

      $('input', props).bind('change blur', function(event){
        var current_value = $(this).val(),
            property = $(this).attr('id').replace('media_', '');
            icon = block.find('.active-icons li.selected').data('icon');

        $('input[name="media_icons[' + icon + '][' + property + ']"]').val(current_value);

        // only update cache when the user actually changes the field
        if(event.type !== 'blur'){
          $.ajax({
            type: 'GET',
            url: 'admin-ajax.php',
            data: {
              action: 'update_media_icon_cache',
              data: {'icon': icon, 'field': property, 'value': current_value} ,
              _ajax_nonce: '<?php echo Atom::admin()->getNonce(); ?>'
            }
          });
        }

      });

      $('.icons li:first', block).trigger('click');

    });

    <?php
  }



  // caches filled input field values
  public function updateIconDataCache(){
    check_ajax_referer('theme-settings');

    if(isset($_GET['data']) && is_array($_GET['data'])){

    if(($cache = get_transient('media_icon_cache')) === false) $cache = array();
      delete_transient('media_icon_cache');

      $data = $_GET['data'];
      foreach($data as &$entry)
        $entry = esc_attr(strip_tags($entry));

      extract($data);

      $cache[$icon][$field] = $value;
      set_transient('media_icon_cache', $cache, 60*60*24*90); // 90 days
    }

    exit;
  }



  // get the active icon list
  private function getActiveIcons(){
    $active_icons = Atom::app()->options('media_icons');
    $active_icons = is_array($active_icons) ? array_keys($active_icons) : array();

    return $active_icons;
  }


  // get a list of all icons
  private function getIconList(){
    $active_icons = $this->getActiveIcons();

    $all_icons = array();
    foreach(glob($this->dir.'/icons/*.png') as $filename)
      $all_icons[] = basename($filename, '.png');

    if(is_child_theme() && is_dir(STYLESHEETPATH.'/'.self::USER_ICON_DIR))
      foreach(glob(STYLESHEETPATH.'/'.self::USER_ICON_DIR.'/*.png') as $filename)
        $all_icons[] = basename($filename, '.png');

    return array_diff($all_icons, $active_icons);
  }



  // get a field like label/URI for the given icon
  private function getIconData($icon, $field){

    // looks inside the options first (only active icons store the fields here)
    $options = Atom::app()->options('media_icons');
    if(isset($options[$icon][$field])) return $options[$icon][$field];

    // not here, icon is inactive, so try the cache
    if(($cache = get_transient('media_icon_cache')) !== false)
      if(isset($cache[$icon][$field])) return $cache[$icon][$field];

    // nothing, this field has not been set yet...
    return '';
  }


  // locates images and generates the icon <image> tag
  private function getIconImage($icon){

    // module directory first
    if(is_readable($this->dir.'/icons/'.$icon.'.png'))
      $url = $this->url.'/icons/'.$icon.'.png';

    // child theme dir
    elseif((is_child_theme() && is_dir(STYLESHEETPATH.'/'.self::USER_ICON_DIR)))
      $url = Atom::app()->get('child_theme_url').'/'.self::USER_ICON_DIR.'/'.$icon.'.png';

    $label = $this->getIconData($icon, 'label');
    $uri = $this->getIconData($icon, 'uri');

    $label = $label ? 'data-label="'.$label.'"' : '';
    $uri = $uri ? 'data-uri="'.$uri.'"': '';

    return '<img src="'.$url.'" alt="'.$icon.'" width="'.$this->icon_size.'" height="'.$this->icon_size.'" '.$label.' '.$uri.' />';
  }



  // theme settings page
  public function form(){ ?>
    <style type="text/css">

      #social-media-icons ul{
        padding: 5px;
      }

      #social-media-icons li{
        float:left;
        width: 66px;
        height: 66px;
        margin: 2px;
        padding: 2px;
        cursor: move;
        border: 2px solid transparent;
        border-radius: 10px;
        text-align:center;
      }

      #social-media-icons li.selected{
        background: #fff;
        border-color: #ddd;
      }

    </style>
    <div class="notice">
      <?php printf(_a('Drag and drop icons below to enable or disable them.')); ?>

    </div>
    <div class="metabox-holder flow clear-block" id="social-media-icons">

      <input type="hidden" name="media_icons" value="0" />

      <div class="clear-block">
        <div class="block alignleft">
          <div class="postbox">
            <h3><span><?php _ae('Active icons'); ?></span></h3>
            <ul class="inside active-icons icons clear-block">
              <?php foreach($this->getActiveIcons() as $icon): ?>
              <li data-icon="<?php echo $icon; ?>">

                <?php echo $this->getIconImage($icon); ?>

                <input type="hidden" name="media_icons[<?php echo $icon; ?>][label]" value="<?php echo $this->getIconData($icon, 'label'); ?>" />
                <input type="hidden" name="media_icons[<?php echo $icon; ?>][uri]" value="<?php echo $this->getIconData($icon, 'uri'); ?>" />
              </li>
              <?php endforeach; ?>
            </ul>
          </div>
        </div>

        <div class="block alignright properties">

          <div class="entry">
            <p><label for="media_label"><?php _ae('Label'); ?></label></p>
            <input id="media_label" size="40" type="text" value="" />
          </div>

          <div class="entry">
            <p><label for="media_uri"><?php _ae('Target URI'); ?></label></p>
            <input id="media_uri" size="40" type="text" value="" />
          </div>

        </div>
      </div>

      <div class="postbox wide">
        <h3><span><?php _ae('Inactive icons'); ?></span></h3>
        <div class="inside">
          <ul class="inactive-icons icons clear-block">
            <?php foreach($this->getIconList() as $icon): ?>
            <li data-icon="<?php echo $icon; ?>">
              <?php echo $this->getIconImage($icon); ?>
            </li>
            <?php endforeach; ?>
          </ul>

          <?php if(current_user_can('edit_themes')): ?>
          <p>
            <?php
             if(is_child_theme())
               printf(_a('You can also include your own icons within this list, by copying them in %s'),
                 sprintf('<strong><em>%s</em></strong>', basename(WP_CONTENT_DIR).'/themes/'.basename(STYLESHEETPATH).'/'.self::USER_ICON_DIR.'/')
               );
             else
               _ae('Activate a child theme to add your own icons in this list.');
            ?>
          </p>
          <?php endif; ?>

        </div>

      </div>

    </div>
    <?php
  }



  // the output
  public function output($links){

    $links = array();
    $blog = home_url();
    $icons = $this->getActiveIcons();

    foreach($icons as $icon){

      // fields
      $label = $this->getIconData($icon, 'label');
      $uri = $this->getIconData($icon, 'uri');

      // open in new page if link is external
      $target = (strpos($uri, $blog) !== 0) ? ' target="_blank"' : '';

      $links[] = '<li class="'.$icon.'"><a title="'.$label.'" href="'.$uri.'"'.$target.'>'.$label.'</a></li>';
    }

    // reverse links because Mystique has the icons right-floated
    return implode("\n", array_reverse($links))."\n";
  }



  // css styles
  public function css($css){

    // check if these are the default settings, because the sprite doesn't exist in this case and we have to use our default image
    $image = (Atom::app()->options('media_icons') !== $this->defaults) ? $this->sprite_url : $this->url.'/defaults.png';

    $rules = array('.social-media a{background: transparent url("'.$image.'") no-repeat center top !important;}');
    $icons = $this->getActiveIcons();
    $y = 0;

    foreach($icons as $icon){
      $rules[] = '.social-media .'.sanitize_html_class($icon).' a{background-position: center -'.$y.'px !important;}';
      $y = $y + ($this->icon_size - 1);
    }

    return $css.implode("\n", $rules)."\n";
  }



  // generate a sprite-type image with the icons, so we don't have to load each icon separately
  private function generateSprite($icons, $output){

    // check if we have permission to write to this directory
    if(!is_writable(dirname($output))) return false;

    $images = array();
    $height = count($icons) * $this->icon_size;

    $sprite = @imagecreatetruecolor($this->icon_size, $height);
    if(!$sprite) return false;

    // Set the background as transparent
    $transparent = imagecolorallocatealpha($sprite, 0, 0, 0, 127);
    if(!imagefill($sprite, 0, 0, $transparent)) return false;
    if(!imagesavealpha($sprite, true)) return false;

    $y = 0;
    foreach($icons as $icon){

      // look in module directory first
      $file = "{$this->dir}/icons/{$icon}.png";

      // not there, look in child theme folder
      if(is_child_theme() && !is_readable($file)){
        $file = STYLESHEETPATH.'/'.self::USER_ICON_DIR.'/'.$icon.'.png';

        // fail, user has deleted it?
        if(!is_readable($file)) return false;
      }

      $image = @imagecreatefrompng($file);
      if(!$image) return false;

      if(!imagecopyresampled($sprite, $image, 0, $y, 0, 0, $this->icon_size, $this->icon_size, $this->icon_size, $this->icon_size)) return false;
      imagedestroy($image);
      $y = $y + ($this->icon_size - 1);
    }

    if(!imagepng($sprite, $output)) return false;
    imagedestroy($sprite);

    return true;
  }

}
