<?php
/**
 * Module Name: Advertisment Blocks
 * Description: Allows you to insert context-dependent ads into your pages
 * Version: 1.0
 * Author: digitalnature
 * Author URI: http://digitalnature.eu
 */


// @todo: http://digitalnature.eu/topic/suggestions-for-ads-settings-page/
// - add disable/enable switch to ads
// - add header ad location
// - ad rotation, maybe?



// class name must follow this pattern (AtomMod + directory name)
class AtomModAdBlocks extends AtomMod{

  private $queue, $ads;

  // available public variables from parent class:
  //
  // $this->url  - this module's url path
  // $this->dir  - this module's directory

  public function init(){

     // register extra theme options
    Atom::app()->addDefaultOptions(array('advertisments' => array()));

    if(is_admin()){
      // insert a tab, 40 is the priority (somewhere before 'CSS')
      Atom::admin()->addTab('ad_blocks', _a('Ads'), array(&$this, 'form'), 38);

      Atom::add('admin_jquery_init', array(&$this, 'js'));
      add_action('wp_ajax_create_ad', array(&$this, 'createAd'));
    }

    add_action('template_redirect', array(&$this, 'queueAds'));
  }

  public function queueAds(){
    global $current_user, $post;

    $this->ads = Atom::app()->options('advertisments');
    if(!is_array($this->ads) || empty($this->ads)) return; // no ads have been set up

    $this->queue = array();
    foreach($this->ads as $ad){

      $active = false;
      $ad['n'] = empty($ad['n']) ? 1 : min(max((int)$ad['n'], 1), get_option('posts_per_page'));

      // page
      $active = call_user_func("is_{$ad['page']}");

      // user: all/visitor
      if(is_numeric($ad['to'])) $active = !$active || ($active && $ad['to'] && is_user_logged_in()) ? false : $active;

      // user: role
      else $active = $active && in_array($ad['to'], $current_user->roles);

      // comment status, on single pages
      if(!empty($ad['when']) && is_single()) $active = $active && ($ad['when'] == $post->comment_status);

      if($active) $this->queue[$ad['place']][] = $ad;
    }

    foreach($this->queue as $place => $ad)
      Atom::add($place, array(&$this, 'output'));
  }


  public function output($place){

    // a hacky way of getting do_action's $tag argument, but it saves us a lot of lines of code;
    // the ordinary way would be to create methods for each tag...
    $place = debug_backtrace();
    $place = substr($place[2]['args'][0], strlen('atom_'));

    if(!isset($this->queue[$place])) return;

    foreach($this->queue[$place] as $key => $ad){

      // teaser
      if(in_array($place, array('before_teaser', 'after_teaser')) && ($ad['n'] !== $GLOBALS['wp_query']->current_post + 1)) continue;

      // comments
      if(($place === 'before_comment') && ($ad['n'] !== Atom::app()->comment->getNumber())) continue;

      // all
      echo $ad['html'];
      unset($this->queue[$place][$key]);

    }
  }


  // tab entry in theme settings
  public function form($settings){
    ?>
    <!-- tab: ads -->
    <div class="clear-block">

      <div class="notice">
        <?php _ae('This section helps you create advertisment blocks in non-widgetized areas. For widgetized areas such as sidebars, simply use a text widget to display your ads.'); ?>
      </div>
      <p>
        <input class="button-secondary create-ad" type="submit" value="<?php _ae('Create New Ad'); ?>" />
      </p>
      <br />
      <input type="hidden" name="advertisments" value="0" />
      <div id="ad-blocks">
        <?php
          if(is_array(Atom::app()->options('advertisments')))
            foreach(Atom::app()->options('advertisments') as $key => $ad) $this->advertismentForm($key, $ad);
        ?>
      </div>

    </div>
    <!-- /tab: ads -->
    <?php
  }

  private function advertismentForm($id, $ad = array()){

    // defaults
    $ad = wp_parse_args($ad, array(
      // defaults (note that keys can change depending on context)
      'page'   => 'home',
      'place'  => 'after_teaser',
      'n'      => 1,
      'to'     => 1,
      'html'   => "<div class=\"ad-block aligncenter\">\n  <a href=\"http://google.com\"><img src=\"http://dummyimage.com/468x60/000/fff\" alt=\"Test Ad\" /></a>\n</div>",
      'when'   => 0, // anytime...
    ));

    // makre sure the ad position doesn't exceed the # if items it's relative to
    $ad['n'] = ($ad['place'] !== 'before_comment') ? min(max((int)$ad['n'], 1), get_option('posts_per_page')) : min(max((int)$ad['n'], 1), get_option('comments_per_page'));

    $contexts = apply_filters('atom_ad_contexts', array(
      'pages' => array(
        'home'            => _a('Blog Homepage'),
        'single'          => _a('Single Post Pages'),
        'category'        => _a('Category Archives'),
        'tag'             => _a('Tag Archives'),
        'author'          => _a('Author Archives'),
        'date'            => _a('Date-based Archives'),
        'search'          => _a('Search Results'),        
      ),

      'places' => array(
        'single' => array(
          'before_main'     => _a("After Header"),
          'before_primary'  => _a("Before Main"),
          'after_primary'   => _a("After Main"),
          'before_comment'  => _a("Before Comment"),
         ),

        'generic' => array(
          'before_main'     => _a("After Header"),
          'before_primary'  => _a("Before Main"),
          'after_primary'   => _a("After Main"),
          'before_teaser'   => _a("Before Post Teaser"),
          'after_teaser'    => _a("After Post Teaser"),
        ),
      ),

    ));

    $wp_roles = new WP_Roles();
   ?>

   <div class="ad-block" id="ad_<?php echo $id; ?>">
     <div class="clear-block">
       <p class="alignleft">
          <label for="ad_<?php echo $id; ?>_page"><?php _ae("Show on:"); ?></label>
          <select followAdRules rel="page" id="ad_<?php echo $id; ?>_page" name="advertisments[<?php echo $id; ?>][page]">
            <?php foreach($contexts['pages'] as $page => $label): ?>
            <option value="<?php echo $page; ?>" <?php selected($page, $ad['page']) ?>><?php echo $label; ?></option>
            <?php endforeach; ?>
          </select>

          <select followAdRules rules="CONFLICTS WITH page BEING single" rel="generic" name="advertisments[<?php echo $id; ?>][place]">
            <?php foreach($contexts['places']['generic'] as $place => $label): ?>
            <option value="<?php echo $place; ?>" <?php selected($place, $ad['place']) ?>><?php echo $label; ?></option>
            <?php endforeach; ?>
          </select>

          <select followAdRules rules="DEPENDS ON page BEING single" rel="single" name="advertisments[<?php echo $id; ?>][place]">
            <?php foreach($contexts['places']['single'] as $place => $label): ?>
            <option value="<?php echo $place; ?>" <?php selected($place, $ad['place']) ?>><?php echo $label; ?></option>
            <?php endforeach; ?>
          </select>

          <label for="ad_<?php echo $id; ?>_n">#</label>
          <input rel="n" id="ad_<?php echo $id; ?>_n" type="text" size="2" value="<?php echo (int)$ad['n']; ?>" followAdRules rules="DEPENDS ON generic BEING before_teaser OR generic BEING after_teaser OR single BEING before_comment" name="advertisments[<?php echo $id; ?>][n]" />

          <label for="ad_<?php echo $id; ?>_time"><?php _ae("When:"); ?></label>
          <select followAdRules rules="DEPENDS ON page BEING single" rel="when" id="ad_<?php echo $id; ?>_time" name="advertisments[<?php echo $id; ?>][when]">
            <option value="0" <?php selected(empty($ad['when'])) ?>><?php _ae("Anytime"); ?></option>
            <option value="closed" <?php selected('closed', $ad['when']) ?>><?php _ae("Comments are closed") ?></option>
            <option value="open" <?php selected('open', $ad['when']) ?>><?php _ae("Comments are open") ?></option>
          </select>

          <label for="ad_<?php echo $id; ?>_to"><?php _ae("To:"); ?></label>
          <select followAdRules rel="to" id="ad_<?php echo $id; ?>_to" name="advertisments[<?php echo $id; ?>][to]">
            <option value="0" <?php selected(empty($ad['to'])) ?>><?php _ae("Anyone") ?></option>
            <option value="1" <?php selected(1, $ad['to']) ?>><?php _ae("Visitor only") ?></option>
            <?php foreach($wp_roles->get_names() as $role => $label): ?>
            <option value="<?php echo $role; ?>"  <?php selected($role, $ad['to']) ?>><?php echo translate_user_role($label); ?></option>
            <?php endforeach; ?>
          </select>
        </p>

        <p class="alignright">
          <input class="button-secondary alignright remove-ad" type="button" value="<?php _ae('Remove'); ?>" followAdRules />
        </p>

      </div>

      <div>
        <textarea mode="text/html" rows="4" class="code editor widefat" id="ad_html_<?php echo $id; ?>" name="advertisments[<?php echo $id; ?>][html]"><?php echo $ad['html']; ?></textarea>
      </div>

      <script type="text/javascript">
       /*<![CDATA[*/
       jQuery(document).ready(function($){
         $('#ad_<?php echo $id; ?> [followAdRules]').setupDependencies({disable_only:false, clear_inactive:false, identify_by:'rel'});

         $("#ad_<?php echo $id; ?> .remove-ad").click(function(){
           $("#ad_<?php echo $id; ?>").animate({
             opacity: 'hide',
             height: 'hide',
             marginTop: 'hide',
             marginBottom: 'hide',
             paddingTop: 'hide',
             paddingBottom: 'hide'
           }, 333, function(){ $(this).remove(); });
         });
       });
       /*]]>*/
      </script>
   </div>
   <?php
  }

  public function createAd(){
    check_ajax_referer('theme-settings-ads');
    $this->advertismentForm(strip_tags($_GET['key']));
    die();
  }

  public function js(){ ?>

      $('#theme-settings .create-ad').click(function(event){
        event.preventDefault();

        var id = 'a' + (new Date()).getTime();

        $.ajax({
          url: '<?php echo admin_url('admin-ajax.php'); ?>',
          type: 'GET',
          context: this,
          data: ({
            action: 'create_ad',
            key: id,
            _ajax_nonce: '<?php echo wp_create_nonce('theme-settings-ads'); ?>'
          }),
          beforeSend: function() {
            $(this).attr('disabled', 'disabled');
            $(this).parent().addClass('loading');
          },

          success: function(data){
            $(this).removeAttr('disabled');
            $(this).parent().removeClass('loading');
            var block = $(data);
            block.filter('#ad_' + id).hide();
            $('#ad-blocks').prepend(block);
            $('#ad_' + id).animate({
                      opacity: 'show',
                      height: 'show',
                      marginTop: 'show',
                      marginBottom: 'show',
                      paddingTop: 'show',
                      paddingBottom: 'show'
                     }, 333);


            // codemirror
            $('#ad_' + id + ' .editor').each(function(){
              CodeMirror.fromTextArea(document.getElementById($(this).attr('id')), {
                lineNumbers: true,
                matchBrackets: true,
                mode: $(this).attr('mode')
              });

            });
          }
        });
      });
    <?php
  }


}
