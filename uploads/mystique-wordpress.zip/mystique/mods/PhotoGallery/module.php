<?php
/**
 * Module Name: Photo Gallery
 * Description: Image gallery showcase
 * Version: 1.0
 * Author: digitalnature
 * Author URI: http://digitalnature.eu
 */




// class name must follow this pattern (AtomMod + directory name)
class AtomModPhotoGallery extends AtomMod{

  private
    $effects;

  public
    $options;

  // available public variables from parent class:
  //
  // $this->url  - this module's url path
  // $this->dir  - this module's directory

  public function init(){

    $this->effects = array(
       'Fade'             => _a('Fade'),
       'SlideH'           => _a('Slide Horizontally'),
       'SlideV'           => _a('Slide Vertically'),
       'RandomTiles'      => _a('Random Tiles'),
       'HorizontalTiles'  => _a('Horizontal Tiles'),
       'DiagonalTiles'    => _a('Diagonal Tiles'),
       'Spiral'           => _a('Spiral'),
       'RandomStripes'    => _a('Random Stripes'),
       'StripeWave'       => _a('Stripe Wave'),
       'Curtain'          => _a('Curtain'),
       'Interweave'       => _a('Interweave'),
    );

    // register extra theme options
    Atom::app()->addDefaultOptions(array(
      'gallery_dimensions'       => array(960, 320),
      'gallery_source'           => 'marked',
      'gallery_source_nextgen'   => 0,
      'gallery_link'             => 'post',
      'gallery_effects'          => array_keys($this->effects),
      'gallery_count'            => 6,
      'gallery_delay'            => 15,
      'gallery_timeframe'        => 60,
      'gallery_caption'          => true,
      'gallery_caption_content'  => 'post_filtered',
      'gallery_navigation'       => true,
      'gallery_pager'            => true,
      'gallery_visibility'       => array(
         'page-home'          => 1,
         'user-visitor'       => 1,
         'role-administrator' => 1,
         'role-editor'        => 1,
         'role-author'        => 1,
         'role-contributor'   => 1,
         'role-subscriber'    => 1,
      ),

      // internal, no option fields for these
      'gallery_allowed_tags'     => array('a', 'abbr', 'acronym', 'b', 'cite', 'code', 'del', 'dfn', 'em', 'i', 'ins', 'q', 'strong', 'sub', 'sup'),
      'gallery_description_size' => 60,
      'gallery_caption_position' => array('left', 'right', 'bottom'),
      'gallery_location'         => 'before_main',
    ));

    if(is_admin())
      // insert a tab, 35 is the priority (somewhere between content options and ads)
      Atom::admin()->addTab('gallery', _a('Photo Gallery'), array(&$this, 'form'), 35);

    add_action('wp', array(&$this, 'preSetup'));
  }


  // initialize options and set up gallery image size
  public function preSetup(){
    // allow override
    $this->options = Atom::app()->getContextArgs('photo_gallery', $this->getOptions('gallery'));

    list($w, $h) = $this->options['gallery_dimensions'];
    add_image_size('photo_gallery', $w, $h, true);
    Atom::add($this->options['gallery_location'], array(&$this, 'output'));
  }

  // tab entry in theme settings
  public function form(){
    global $nggdb;
    $wp_page_types = array(
      'home'     => _a('Blog Homepage'),
      'search'   => _a('Search Results'),
      'author'   => _a('Author Archives'),
      'date'     => _a('Date-based Archives'),
      'tag'      => _a('Tag Archives'),
      'category' => _a('Category Archives'),
    );

    $this->options = Atom::app()->options();

    list($width, $height) = $this->options['gallery_dimensions'];

    ?>
    <!-- tab: gallery -->
    <div class="clear-block">

      <div class="clear-block">

       <div class="block alignleft">
         <h3 class="title"><?php _ae('Content source'); ?></h3>

         <div class="entry">
         <label for="gallery_source_marked">
           <input type="radio" value="marked" id="gallery_source_marked" name="gallery_source" <?php checked($this->options['gallery_source'], 'marked'); ?> followRules />
           <?php printf(_a('%s that I mark as featured'), '<a href="'.admin_url('upload.php').'">'._a('Media items').'</a>'); ?>
         </label>
         </div>
         <div class="entry">

         <label for="gallery_source_atom" class="disabled" title="<?php _ae('Plugin not installed'); ?>">
           <input id="gallery_source_atom" name="gallery_source" type="radio" value="atom" disabled="disabled" />
           <?php _ae('Atom gallery'); ?>
           <select name="gallery_source_atom" disabled="disabled">
             <option value="0"><?php _ae('-- All galleries --'); ?></option>
           </select>
         </label>

         </div>
         <div class="entry">

         <label for="gallery_source_nextgen" <?php if(!isset($nggdb)): ?> class="disabled" title="<?php _ae('Plugin not installed'); ?>" <?php endif;?>>
           <input id="gallery_source_nextgen" name="gallery_source" type="radio" value="nextgen" <?php checked($this->options['gallery_source'], 'nextgen'); ?> <?php if(!isset($nggdb)): ?> disabled="disabled" <?php else: ?> followRules <?php endif;?>/>
           <?php _ae('NextGEN gallery'); ?>
           <select name="gallery_source_nextgen" <?php if(!isset($nggdb)): ?> disabled="disabled"  <?php else: ?> followRules rules="DEPENDS ON gallery_source BEING nextgen"<?php endif;?>>
             <option value="0"><?php _ae('-- All galleries --'); ?></option>
             <?php if(isset($nggdb)): ?>
             <?php foreach($nggdb->find_all_galleries('name', 'ASC', true) as $gallery): ?>
             <option value="<?php echo $gallery->gid; ?>" <?php selected($gallery->gid, $this->options['gallery_source_nextgen']); ?>><?php printf('%1$s (%2$s)', $gallery->name, $gallery->counter); ?></option>
             <?php endforeach; ?>
             <?php endif; ?>
           </select>
         </label>
         </div>

         <h3 class="title"><?php _ae("Options"); ?></h3>

         <div class="entry">
          <label for="gallery_dimensions"><?php _ae('Dimensions:') ?></label>
          <input id="gallery_dimensions" name="gallery_dimensions[]" type="text" value="<?php echo (int)$width; ?>" size="4" /> x
          <input id="gallery_dimensions" name="gallery_dimensions[]" type="text" value="<?php echo (int)$height; ?>" size="4" />
          <?php _ae('pixels'); ?>
          <label><small><?php _ae('(Images of this size must already exist)'); ?></small></label>
         </div>

         <div class="entry">
          <label for="gallery_count"><?php _ae('Number of items to show:') ?></label>
          <input id="gallery_count" name="gallery_count" type="text" value="<?php echo (int)$this->options['gallery_count']; ?>" size="3" />
         </div>

         <div class="entry">
          <?php $input = '<input id="gallery_timeframe" name="gallery_timeframe" type="text" value="'.(int)$this->options['gallery_timeframe'].'" size="4" />'; ?>
          <label for="gallery_timeframe"><?php printf(_a('Exclude items older than %s day(s)'), $input); ?></label>
         </div>

         <div class="entry">
          <?php $input = '<input id="gallery_delay" name="gallery_delay" type="text" value="'.(int)$this->options['gallery_delay'].'" size="3" />'; ?>
          <label for="gallery_delay"><?php printf(_a('Auto-Cycle every %s second(s)'), $input); ?></label>
          <label><small><?php _ae("(0 to disable auto-play)"); ?></small></label>
         </div>

         <div class="entry">
          <label for="gallery_link"><?php _ae('Slides link to:') ?></label>
          <select id="gallery_link" name="gallery_link">
           <option value="image" <?php selected($this->options['gallery_link'], 'image'); ?>><?php _ae('Original image'); ?></option>
           <option value="attachment" <?php selected($this->options['gallery_link'], 'attachment'); ?>><?php _ae('Post URL'); ?></option>
           <option value="post" <?php selected($this->options['gallery_link'], 'post'); ?>><?php _ae('Attached (parent) post URL, if any'); ?></option>
           <option value="" <?php selected($this->options['gallery_link'], ''); ?>><?php _ae('Nothing'); ?></option>
          </select>
         </div>

         <h3 class="title"><?php _ae("Show"); ?></h3>
         <div class="entry">
          <input type="hidden" name="gallery_caption" value="0" />
          <input id="gallery_caption" name="gallery_caption" type="checkbox" followRules <?php checked($this->options['gallery_caption']); ?> value="1" />
          <label for="gallery_caption"><?php _ae('Captions:') ?></label>
          <select id="gallery_caption_content" followRules rules="DEPENDS ON gallery_caption" name="gallery_caption_content">
           <option value="image" <?php selected($this->options['gallery_caption_content'], 'image'); ?>><?php _ae("Image title and description"); ?></option>
           <option value="post_filtered" <?php selected($this->options['gallery_caption_content'], 'post_filtered'); ?>><?php _ae("Filtered content from the attached post, if any"); ?></option>
           <option value="post_excerpt" <?php selected($this->options['gallery_caption_content'], 'post_excerpt'); ?>><?php _ae("Excerpt from the attached post, if any"); ?></option>
          </select>
         </div>

         <div class="entry">
          <label for="gallery_navigation">
          <input type="hidden" name="gallery_navigation" value="0" />
          <input type="checkbox" id="gallery_navigation" name="gallery_navigation" <?php checked($this->options['gallery_navigation']); ?> value="1" />
   	    <?php _ae('Previous/Next links (on mouse over)'); ?></label>
         </div>

         <div class="entry">
          <label for="gallery_pager">
          <input type="hidden" name="gallery_pager" value="0" />
          <input type="checkbox" id="gallery_pager" name="gallery_pager" <?php checked($this->options['gallery_pager']); ?> value="1" />
   	    <?php _ae('Pager (on mouse over)'); ?></label>
         </div>

        <h3 class="title"><?php _ae("Effects"); ?></h3>
        <input type="hidden" name="gallery_effects" value="0" />
        <?php foreach($this->effects as $key => $label): ?>
         <div class="entry">
           <label for="gallery_effects_<?php echo $key; ?>">
             <input id="gallery_effects_<?php echo $key; ?>" name="gallery_effects[]" type="checkbox" value="<?php echo $key; ?>" <?php checked(true, in_array($key, (array)$this->options['gallery_effects'])); ?> />
             <?php echo $label; ?>
           </label>
         </div>
        <?php endforeach; ?>

       </div>

       <div class="block alignright">

        <h3 class="title"><?php _ae("Visible on:"); ?></h3>

        <?php
         foreach($wp_page_types as $key => $label): ?>
         <div class="entry">
          <input type="hidden" name="gallery_visibility[page-<?php echo $key; ?>]" value="0" />
          <input type="checkbox" value="1" <?php checked(!empty($this->options["gallery_visibility"]["page-{$key}"])); ?> id="gallery_visibility[page-<?php echo $key; ?>]" name="gallery_visibility[page-<?php echo $key; ?>]" />
          <label for="gallery_visibility[page-<?php echo $key; ?>]"><?php echo $label; ?></label>
         </div>

        <?php endforeach; ?>

        <?php foreach(get_post_types(array('public' => true)) as $post_type):
          $object = get_post_type_object($post_type);
          if(empty($object->labels->name) || $post_type == 'page') continue; // we handle pages separately ?>
         <div class="entry">
          <input type="hidden" name="gallery_visibility[page-singular-<?php echo $post_type; ?>]" value="0" />
          <input type="checkbox" value="1" <?php checked(!empty($this->options["gallery_visibility"]["page-singular-{$post_type}"])); ?> id="gallery_visibility[page-singular-<?php echo $post_type; ?>]" name="gallery_visibility[page-singular-<?php echo $post_type; ?>]" />
          <label for="gallery_visibility[page-singular-<?php echo $post_type; ?>]"><?php printf(_a('Single: %s'), $object->labels->name); ?></label>
         </div>
        <?php endforeach; ?>

        <?php foreach(get_taxonomies(array('public' => true, '_builtin' => false)) as $taxonomy):
          $object = get_taxonomy($taxonomy);
          if(empty($object->labels->name)) continue; ?>
         <div class="entry">
          <input type="hidden" name="gallery_visibility[page-tax-<?php echo $taxonomy; ?>]" value="0" />
          <input type="checkbox" value="1" <?php checked(!empty($this->options["gallery_visibility"]["page-tax-{$taxonomy}"])); ?> id="gallery_visibility[page-tax-<?php echo $taxonomy; ?>]" name="gallery_visibility[page-tax-<?php echo $taxonomy; ?>]" />
          <label for="gallery_visibility[page-tax-<?php echo $taxonomy; ?>]"><?php printf(_a('Tax Archive: %s'), $object->labels->name); ?></label>
         </div>
        <?php endforeach; ?>

        <?php
          $pages = get_pages();
          if($pages):
            echo '<div class="entry">';
            foreach($pages as $page): ?>
             <div class="entry">
              <input type="hidden" name="gallery_visibility[page-<?php echo $page->ID; ?>]" value="0">
              <input type="checkbox" <?php checked(!empty($this->options["gallery_visibility"]["page-{$page->ID}"])) ?> id="gallery_visibility[page-<?php echo $page->ID; ?>]" name="gallery_visibility[page-<?php echo $page->ID; ?>]" value="1" />
              <label for="gallery_visibility[page-<?php echo $page->ID; ?>]">
              <?php printf(_a("Page: %s"), '<a href="'.get_permalink($page).'" target="_blank"><strong title="'.$page->post_title.'">'.((strlen($page->post_title) > 16) ? substr($page->post_title, 0, 16)."..." : $page->post_title).'</strong></a>'); ?>
              </label>
             </div>
            <?php endforeach;
            echo '</div>';
          endif;
        ?>

        <h3 class="title"><?php _ae("To:"); ?></h3>

      <div class="entry">
        <input type="hidden" name="gallery_visibility[user-visitor]" value="0" />
        <input type="checkbox" value="1" <?php checked(!empty($this->options["gallery_visibility"]['user-visitor'])); ?> id="gallery_visibility[user-visitor]" name="gallery_visibility[user-visitor]" />
        <label for="gallery_visibility[user-visitor]"><?php _ae("Unregistered user (Visitor)"); ?></label>
      </div>

      <?php
       $wp_roles = new WP_Roles();
       $names = $wp_roles->get_names();
       foreach($names as $role => $label):
        ?>
       <div class="entry">
         <input type="hidden" name="gallery_visibility[role-<?php echo $role; ?>]" value="0" />
         <input type="checkbox" value="1" <?php checked(!empty($this->options["gallery_visibility"]["role-{$role}"])); ?> id="gallery_visibility[role-<?php echo $role; ?>]" name="gallery_visibility[role-<?php echo $role; ?>]" />
         <label for="gallery_visibility[role-<?php echo $role; ?>]"><?php echo translate_user_role($label); ?></label>
       </div>
       <?php endforeach; ?>

       </div>
      </div>

    </div>
    <!-- /tab: gallery -->
    <?php
  }


  private function getFeaturedPhotos(){

    $app = &Atom::app();

    // photo sizes to retrieve
    list($gallery_width, $gallery_height) = $this->options['gallery_dimensions'];

    // get featured media records and randomize them
    $media_ids = wp_parse_id_list(get_option('featured_media'));
    shuffle($media_ids);

    $day_limit = (int)$this->options['gallery_timeframe'];
    $valid_photos = array();
    $count = 1;

    // process each image
    foreach($media_ids as $media_id){

      // make sure it exists
      $image = wp_get_attachment_image_src($media_id, array($gallery_width, $gallery_height));
      if(!$image) continue;

      // make sure it has the dimensions we're looking for -- @todo: auto-regenerate?
      list($src, $width, $height) = $image;
      if(($width != $gallery_width) || ($height != $gallery_height)) continue;

      // attempt to get the attached post
      $media = &get_post($media_id);
      if(!$media) continue;
      $attachment = new AtomObjectPost($media);
      $post_parent = $media->post_parent;

      $link = $desc = $title = '';

      // alt image attribute
      $alt = trim(strip_tags(get_post_meta($media_id, '_wp_attachment_image_alt', true)));

      if($this->options['gallery_caption']){
        $title = $attachment->getTitle();
        $desc = $attachment->getContent($this->options['gallery_description_size'], array('allowed_tags' => $this->options['gallery_allowed_tags']));

        $content_mode = $this->options['gallery_caption_content'];
        if($post_parent && in_array($content_mode, array('post_filtered', 'post_excerpt'))){
          $post = new AtomObjectPost($post_parent);
          $title = $post->getTitle();
          $desc = is_numeric($content_mode) ? $post->getContent($this->options['gallery_description_size'], array('allowed_tags' => $this->options['gallery_allowed_tags'])) : $post->getContent('e');
        }

        if(empty($alt)) $alt = $title;
        if(empty($alt)) $alt = $attachment->getContent('e');
      }

      // determine link URL
      if($this->options['gallery_link'] === 'image'){
        list($link, $full_width, $full_height) = wp_get_attachment_image_src($media_id, 'full');

      }elseif($post_parent && $this->options['gallery_link'] === 'attachment'){
        $link = $attachment->getURL();

      }elseif($post_parent && $this->options['gallery_link'] === 'post'){
        $post = new AtomObjectPost($post_parent);
        $link = $post->getURL();
      }

      // date must be within the timeframe set in the options
      if($day_limit && (strtotime($media->post_date) < strtotime("-{$day_limit} days"))) continue;

      // image is valid, add it to the list
      $valid_photos[] = array(
        'src'    => $src,
        'link'   => $link,
        'alt'    => $alt,
        'title'  => $title,
        'desc'   => $desc,
      );

      // stop if jquery is disabled (one photo only), or if the current photo count exceeds the number limit from the options
      if(!$app->options('jquery') || ($count++ == $this->options['gallery_count'])) break;

    }

    // reset post data
    $app->resetCurrentPost();

    return $valid_photos;
  }



  private function getNGGPhotos(){
    global $nggdb;

    // photo sizes to retrieve
    list($gallery_width, $gallery_height) = $this->options['gallery_dimensions'];

    $gallery_id = (int)$this->options['gallery_source_nextgen'];
    $day_limit = (int)$this->options['gallery_timeframe'];
    $valid_photos = array();

    if(isset($nggdb)){

      $images = $gallery_id ? $nggdb->get_gallery($gallery_id) : $nggdb->get_random_images(100);
      $count = 1;

      foreach($images as $image){

        // check dimensions
        $valid_width = isset($image->meta_data['width']) && ($image->meta_data['width'] == $gallery_width);
        $valid_height = isset($image->meta_data['height']) && ($image->meta_data['height'] == $gallery_height);
        if(!$valid_width || !$valid_height) continue;

        // is it older than we want?
        if($day_limit && (strtotime($image->imagedate) < strtotime("-{$day_limit} days"))) continue;
        // @note: we could use sql - WHERE imagedate + INTERVAL 30 DAY < NOW() but get_random_images doesn't support the $exclude arg :(

        $valid_photos[] = array(
          'src'    => $image->imageURL,
          'link'   => $image->pageid ? get_page_link($image->pageid) : '',
          'alt'    => $image->alttext,
          'title'  => $image->title,
          'desc'   => convert_smilies(Atom::getFilteredContent($image->description, array(
                        'allowed_tags' => $this->options['gallery_allowed_tags'],
                        'limit' => $this->options['gallery_description_size']
                      ))),
        );

        // stop if jquery is disabled (one photo only), or if the current photo count exceeds the number limit from the options
        if(!Atom::app()->options('jquery') || ($count++ == $this->options['gallery_count'])) break;

      }
    }

    return $valid_photos;
  }



  private function getAtomPhotos(){

    // photo sizes to retrieve
    list($gallery_width, $gallery_height) = $this->options['gallery_dimensions'];

    $valid_photos = array();

    // @todo

    return $valid_photos;
  }



  public function output(){

    if(!atom_strict_visibility_check($this->options['gallery_visibility'])) return;

    $effects = (is_array($this->options['gallery_effects']) && !empty($this->options['gallery_effects'])) ? $this->options['gallery_effects'] : array('fade');

    // remove any effects that might not exist (ie. some fx could be removed upon version change)
    $effects = array_intersect($effects, array_keys($this->effects));

    shuffle($effects);

    $caption_push = $this->options['gallery_caption_position'];
    shuffle($caption_push);

    list($gallery_width, $gallery_height) = $this->options['gallery_dimensions'];

    // featured media
    if($this->options['gallery_source'] === 'marked')
      $photos = $this->getFeaturedPhotos($this->options);

    // nextgen gallery
    elseif($this->options['gallery_source'] === 'nextgen')
      $photos = $this->getNGGPhotos($this->options);

    // atom gallery
    else
      $photos = $this->getAtomPhotos($this->options);

    $output = array();

    // process each image
    foreach($photos as $index => $photo){
      $content = '<img src="'.$photo['src'].'" alt="'.$photo['alt'].'" width="'.$gallery_width.'" height="'.$gallery_height.'" />';

      if($photo['link'])
        $content = '<a href="'.$photo['link'].'">'.$content.'</a>';

      if($this->options['gallery_caption']){
        $photo['title'] = $photo['title'] ? "<h3>{$photo['title']}</h3>" : '';
        if($photo['desc'] || $photo['title']){

          if(empty($position_history))
            $position_history = $caption_push;

          $position = array_pop($position_history);

          $content .= '<div class="caption push-'.$position.'"><div class="content">'.$photo['title'].$photo['desc'].'</div></div>';
        }
      }

      // used up all effects? reset then...
      if(empty($effect_history)) $effect_history = $effects;

      // select a random effect and remove it from the history of effects so we don't choose it again in the next loop
      $effect = array_pop($effect_history);

      $output[] = '<div class="slide '.(($index === 0) ? 'first' : '').'" data-fx="'.$effect.'" data-delay="'.(int)$this->options['gallery_delay'].'">'.$content.'</div>';

    }

    if(empty($output))
      return Atom::app()->addDebugMessage("Photo gallery: No relevant images found ({$this->options['gallery_source']})");

    $controls = array();
    if($this->options['gallery_navigation']) $controls[] = 'arrows';
    if($this->options['gallery_pager']) $controls[] = 'pager';

    $count = count($photos);
    $attributes = array(
       'style'          => "width:{$gallery_width}px;height:{$gallery_height}px;",
       'class'          => ($count > 1) ? "iSlider count-{$count}" : "single",
       'data-controls'  => implode(',', $controls),
    );

    foreach($attributes as $key => &$value)
      $value = ($value) ? "{$key}=\"{$value}\"" : '';

    ?>
    <!-- gallery -->
    <div id="gallery" <?php echo implode(' ', $attributes); ?>>
      <?php echo implode("\n", $output); ?>
      <?php Atom::action('after_photo_gallery'); ?>
    </div>
    <!-- /gallery -->

    <?php
  }

}
