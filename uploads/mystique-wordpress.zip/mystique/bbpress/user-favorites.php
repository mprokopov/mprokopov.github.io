<?php bbp_set_query_name('bbp_user_profile_favorites'); ?>

<div class="divider"></div>
<h2 class="title"><?php _ae('Favorite Forum Topics'); ?></h2>
<div class="entry-content">
  <?php
    if(bbp_get_user_favorites()):
      bbp_get_template_part('bbpress/loop', 'topics');
      
    else : ?>
     <p><?php bbp_is_user_home() ? _ae('You currently have no favorite topics.') : _ae('This user has no favorite topics.'); ?></p>

    <?php endif; ?>
</div>

<?php bbp_reset_query_name(); ?>
