
<?php bbp_set_query_name('bbp_user_profile_topics_created'); ?>


<div class="divider"></div>
<h2 class="title"><?php _ae('Forum Topics Created'); ?></h2>
<div class="entry-content">
  <?php
   if(bbp_get_user_topics_started()):     
     bbp_get_template_part('bbpress/loop', 'topics');     

    else: ?>
     <p><?php bbp_is_user_home() ? _ae('You have not created any topics.') : _ae('This user has not created any topics.'); ?></p>

  <?php endif; ?>
</div>


<?php bbp_reset_query_name(); ?>
