<?php /* ATOM/digitalnature */

   // This template styles the meta sections on singular type pages: comments, pings, related posts and author bio.
   // The template replaces the comments.php file found in generic themes. This is because we handle more than just comments here.
   // For custom post types, a meta-post_type.php template overrides this one.

  ?>

<?php

 // don't show this section if we're on a page with comments disabled and without any comments or pings in it
 // (we're assuming the site admin doesn't want this section on such pages)
 if(post_password_required() || (!comments_open() && is_page() && $app->post->getCommentCount() < 1)) return;

 ?>
 <div class="tabs meta hide-if-no-js" id="meta" data-fx="fade">

   <ul class="navi clear-block">
     <li class="active">
       <a href="#comments">
         <?php
           $app->commentSearch()
            ? printf(_a('Searching for %1$s (%2$s)'), sprintf('<em>%s</em>', $app->commentSearch()), $app->post->getCommentCount())
            : printf(_a('Comments (%s)'), $app->post->getCommentCount()); ?>
       </a>
     </li>

     <?php if($app->post->getPingCount() > 0): ?>
     <li><a href="#pings"><?php printf(_a('Pings (%s)'), $app->post->getPingCount()); ?></a></li>
     <?php endif; ?>

     <?php if($app->options('single_related')): ?>
     <li><a href="#related-posts"><?php _ae('Related Posts'); ?></a></li>
     <?php endif; ?>

     <?php if($app->options('single_author')): ?>
     <li><a href="#about-the-author"><?php printf(_a('About %s'), $app->post->author->getName()); ?></a></li>
     <?php endif; ?>

   </ul>

   <div class="sections">

     <ul class="section clear-block" id="comments">

       <?php if(get_option('comment_order') == 'desc'): ?>
       <li class="new">
         <?php $app->template('commentform'); ?>
       </li>
       <?php endif; ?>

       <?php $app->post->comments(); ?>

       <?php if(get_option('comment_order') != 'desc'): ?>
       <li class="new">
         <?php $app->template('commentform'); ?>
       </li>
       <?php endif; ?>

       <li class="clear-block">

          <?php if(($app->post->getCommentCount() > 10) && $app->options('comment_filter')): // show filter only if it's enabled and if we have more than 10 comments ?>
          <div class="clear-block">

            <div class="comment-filter alignright">
             <form action="<?php echo get_permalink(); ?>" method="post" id="commentfilterform">
               <input type="text" class="comment-filter clearField" name="comment-filter" data-default="<?php _ae('Filter'); ?>" value="<?php echo $app->commentSearch(); ?>" size="20" />
             </form>
            </div>

          </div>
          <?php endif; ?>

          <div class="clear-block">
           <?php $app->commentNavi($class = 'alignleft'); ?>
           <a class="rss-block alignright" rel="rss" href="<?php echo get_post_comments_feed_link(); ?>"><?php _ae('Comment Feed for this Post'); ?></a>
          </div>
       </li>

       <?php // $app->template('comments'); // @todo (use comment iterator instead) ?>

     </ul>


     <?php if($app->post->getPingCount() > 0): ?>
     <ul class="section hidden clear-block" id="pings">
       <?php $app->post->comments($type = 'ping'); ?>
     </ul>
     <?php endif; ?>

     <?php if($app->options('single_related')): ?>
     <div class="section hidden clear-block" id="related-posts">
       <?php $app->template('related-posts'); ?>
     </div>
     <?php endif; ?>

     <?php if($app->options('single_author')): ?>
     <div class="section hidden clear-block" id="about-the-author">
       <?php $app->template('about-the-author'); ?>
     </div>
     <?php endif; ?>

   </div>
 </div>