<?php /* ATOM/digitalnature */

   // The template for the "page" post type. It acts for pages just like single.php does for posts
   // pagename.php, page-slug.php or page-id.php can override it.

  get_header();
?>

  <!-- main content: primary + sidebar(s) -->
  <div id="mask-3" class="clear-block">
   <div id="mask-2">
    <div id="mask-1">
             
      <!-- primary content -->
      <div id="primary-content">
       <div class="blocks clear-block">
           
        <?php $app->action('before_primary'); ?>
          
        <?php if(have_posts()): ?>
          <div class="posts clear-block">
          <?php while(have_posts()): ?>
            <?php the_post(); ?>

            <?php $app->action('before_post'); ?>

            <!-- post -->
            <div id="post-<?php the_ID(); ?>" <?php post_class('primary'); ?>>

              <?php if(!$app->post->getMeta('hide_title')): ?>
              <h1 class="title"><?php the_title(); ?></h1>
              <?php endif; ?>

              <div class="clear-block">
                <?php the_content(); ?>
              </div>

              <?php $app->post->paginate(); ?>

              <?php $app->controls('post-edit'); ?>
            </div>
            <!-- /post -->
            <?php $app->action('after_post'); ?>

          <?php endwhile; ?>
          </div>

          <?php $app->template('meta'); ?>

        <?php else: ?>
          <h1 class="title error"><?php _ae('Oops, nothing here :('); ?></h1>
        <?php endif; ?>

        <?php $app->action('after_primary'); ?>

       </div>
      </div>
      <!-- /primary content -->

      <?php get_sidebar(); ?>
    </div>
   </div>
  </div>
  <!-- /main content -->

<?php get_footer(); ?>
