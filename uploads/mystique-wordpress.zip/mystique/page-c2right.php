<?php /* ATOM/digitalnature

 Template Name: 2 columns page (right sidebar)
 */
 
 include(TEMPLATEPATH . '/page.php');
 // exactly the same as page.php (only file name is needed for the check)
?>
