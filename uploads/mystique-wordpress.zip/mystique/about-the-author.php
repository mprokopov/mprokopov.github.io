<?php /* ATOM/digitalnature */

   // "About the Author" template, optional meta tab



 ?>

 <div class="clear-block">
   <div class="avatar alignleft">
     <a href="<?php $app->post->author->PostsURL(); ?>" title="<?php $app->post->author->Name(); ?>">
       <?php $app->post->author->Avatar($size = 160); ?>
     </a>
   </div>

   <h5>
     <?php printf(_a('About %s'), $app->post->author->getName()); ?>
     (<a href="<?php $app->post->author->PostsURL(); ?>"><?php printf(_an('%s post', '%s posts', $app->post->author->getPostCount()), $app->post->author->getPostCount()); ?></a>)
   </h5>

   <?php if($app->post->author->getDescription($fallback = $app->post->getMeta('author', true))): ?>
   <div class="author-description">
     <?php $app->post->author->Description(); ?>
   </div>

   <?php else: ?>
   <p><?php _ae('Nothing here :('); ?></p>
   <?php endif; ?>

 </div>

 <a class="rss-block alignright" rel="rss" href="<?php $app->post->author->FeedURL(); ?>"><?php printf(_a("%s's RSS Feed"), $app->post->author->getName()); ?></a>
