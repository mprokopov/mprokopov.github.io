<?php /* ATOM/digitalnature */

   // General Archive template.
   // There are quite a few templates that can override this one: http://codex.wordpress.org/Template_Hierarchy

 get_header();
?>

<!-- main content: primary + sidebar(s) -->
<div id="mask-3" class="clear-block">
  <div id="mask-2">
    <div id="mask-1">

      <!-- primary content -->
      <div id="primary-content">
        <div class="blocks clear-block">

          <?php do_action('bbp_template_notices'); ?>

          <h1 class="title"><?php printf(_a('Topic Tag: %s'), sprintf('<span>%s<span>', bbp_get_topic_tag_name())); ?></h1>

          <?php
           $app->action('before_primary');
           bbp_breadcrumb();
           bbp_topic_tag_description();
           do_action('bbp_template_before_topic_tag_edit');
           bbp_get_template_part('bbpress/form', 'topic-tag');
           do_action('bbp_template_after_topic_tag_edit');
           $app->action('after_primary');           
          ?>

        </div>
      </div>
      <!-- /primary content -->

      <?php get_sidebar(); ?>
    </div>
  </div>
</div>
<!-- /main content -->

<?php get_footer(); ?>




<?php

/**
 * Topic Tag Edit
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<?php get_header(); ?>

		<div id="container">
			<div id="content" role="main">

				<?php do_action( 'bbp_template_notices' ); ?>

				<div id="topic-tag" class="bbp-topic-tag">
					<h1 class="entry-title"><?php printf( __( 'Topic Tag: %s', 'bbpress' ), '<span>' . bbp_get_topic_tag_name() . '</span>' ); ?></h1>

					<div class="entry-content">



					</div>
				</div><!-- #topic-tag -->
			</div><!-- #content -->
		</div><!-- #container -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>
