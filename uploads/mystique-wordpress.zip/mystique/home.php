<?php /* ATOM/digitalnature */

   // The home or blog page template.
   // By default, we're listing the newest posts here.

 get_header();
?>
  
  <!-- main content (masks): primary + sidebar(s) -->
  <div id="mask-3" class="clear-block">
   <div id="mask-2">
    <div id="mask-1">

      <!-- primary content -->
      <div id="primary-content">
       <div class="blocks clear-block">

        <?php $app->action('before_primary'); ?>

        <?php if(have_posts()): ?>
          <div class="posts clear-block">
            <?php while(have_posts()) $app->template('teaser'); ?>
          </div>
          <?php $app->pageNavi(); ?>

        <?php else: ?>
          <h1 class="title error"><?php _ae('Oops, nothing here :('); ?></h1>
        <?php endif; ?>

        <?php $app->action('after_primary'); ?>

       </div>
      </div>
      <!-- /primary content -->

      <?php get_sidebar(); ?>

    </div>
   </div>

  </div>
  <!-- /main content -->

<?php get_footer(); ?>
