<?php /* ATOM/digitalnature */

 //  Singular template, usually used to display a single post.
 //  For custom post types, a template named single-post_type.php will have priority over this one.

 get_header();
?>

<!-- main content: primary + sidebar(s) -->
<div id="mask-3" class="clear-block">
  <div id="mask-2">
    <div id="mask-1">

      <!-- primary content -->
      <div id="primary-content">
        <div class="blocks clear-block">

        <?php $app->action('before_primary'); ?>

        <?php do_action('bbp_template_notices'); ?>

          <div class="posts clear-block">

            <?php

              while(have_posts()):
                the_post();
                if(bbp_user_can_view_forum()): ?>

                <div id="forum-<?php bbp_forum_id(); ?>" class="bbp-forum-content">
                  <h1 class="title"><?php bbp_forum_title(); ?></h1>
                  <div class="entry-content">

                    <?php

                     bbp_breadcrumb();
                     if(post_password_required()):
                       echo get_the_password_form();

                     else:
                       bbp_single_forum_description();

                       if(bbp_get_forum_subforum_count() && bbp_has_forums())
                         bbp_get_template_part('bbpress/loop', 'forums');

                       if(!bbp_is_forum_category() && bbp_has_topics()):                         
                         bbp_get_template_part('bbpress/loop', 'topics');                         
                         bbp_get_template_part('bbpress/form', 'topic');

                       elseif(!bbp_is_forum_category()):
                         _ae('There are no topics in this forum.');
                         bbp_get_template_part('bbpress/form', 'topic');
                       endif;

                     endif;
                    ?>

                  </div>
                </div>
               <?php else: // Forum exists, user no access

                 _ae('You do not have permission to view this forum.');

               endif;
              endwhile;
            ?>

          </div>

          <?php $app->action('after_primary'); ?>

        </div>
      </div>
      <!-- /primary content -->

      <?php get_sidebar(); ?>

    </div>
  </div>
</div>
<!-- /main content -->

<?php get_footer(); ?>

