<?php /* ATOM/digitalnature */

   // This template renders a single comment.
   // Comments are handled within the meta.php template

?>

<!-- comment entry -->
<li class="entry">
  <div id="comment-<?php comment_ID(); ?>" <?php comment_class('clear-block'); ?>>
    <?php $app->comment->avatar($size = 48); ?>

    <div class="comment-head">
      <div class="ext clear-block">
        <div class="alignleft">
        <?php
          printf(_a('%1$s written by %2$s %3$s'),
                 '<a class="comment-id" href="#comment-'.get_comment_ID().'">#'.$app->comment->getNumber().'</a>',
                 $app->comment->getAuthorAsLink(),
                 '<span class="d">'.$app->comment->getDate().'</span>');
        ?>
        </div>

        <?php $app->comment->karma('alignright'); ?>
      </div>
    </div>

    <?php if(!$app->comment->isBuried()): ?>
    <div class="comment-body" id="comment-body-<?php comment_ID(); ?>">
       <div class="comment-content clear-block" id="comment-content-<?php comment_ID(); ?>">

         <?php if(!$app->comment->isApproved()): ?>
         <p class="error">
           <em><?php if($app->comment->belongsToCurrentUser()) _ae('Your comment is awaiting moderation.'); else _ae('This comment is awaiting moderation.'); ?></em>
         </p>
         <?php endif; ?>

         <div class="comment-text">
           <?php comment_text(); ?>
         </div>

         <a id="comment-reply-<?php comment_ID(); ?>"></a>
       </div>

       <?php $app->controls('comment-edit', 'comment-delete', 'comment-spam', 'comment-approve', 'comment-reply', 'comment-quote'); ?>

    </div>
    <?php endif; ?>
  </div>
<?php // </li> is added by WP  ?>