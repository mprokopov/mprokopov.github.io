<?php /* ATOM/digitalnature */

   // The search form, doh.
   // Only used by the search widget.

?>

<!-- search form -->
<div class="search-form" role="search">
  <form method="get" class="search-form clear-block" action="<?php echo home_url(); ?>/">
    <div class="fadeThis"><a href="#" class="submit"><?php _ae('Search Website'); ?></a></div>
    <fieldset>
       <input type="text" name="s" data-default="<?php _ae('Search Website'); ?>" class="text alignleft clearField suggestTerms" value="" />
       <input type="hidden" value="submit" />
    </fieldset>
 </form>
</div>
<!-- /search form -->