<?php /* ATOM/digitalnature */

 //  The footer template, shown on every page of the website.

?>

   </div>
 </div>
 <!-- /main -->

 <?php $app->action('after_main'); ?>

 <?php if($app->MenuExists('footer')): ?>
 <div class="nav nav-footer page-content">
    <?php $app->Menu($location = 'footer', $class = 'slide-up'); ?>
 </div>
 <?php endif; ?>

 <!-- footer -->
 <div class="shadow-left page-content">
   <div class="shadow-right">

     <div id="footer">

       <?php if(($count = $app->isAreaActive('footer1')) > 0): // make sure there are visible widgets ?>
       <ul class="blocks count-<?php echo $count; ?> clear-block">
         <?php $app->Widgets('footer1'); ?>
       </ul>
       <?php endif; ?>

       <div id="copyright">
         <?php echo do_shortcode($app->options('footer_content'));  ?>
         <?php wp_footer(); ?>         
       </div>       
     </div>

   </div>
 </div>
 <!-- /footer -->

 <a class="go-top" href="#page"><?php _ae('Go to Top'); ?></a>

 </div>
 <!-- /page-ext -->


 <!-- <?php echo do_shortcode('[load]'); ?> -->

 </div>
 <!-- page -->

 <?php Atom::end(); // dynamic js is now included at the very end of the document, to make it easier for the ajaxify module  ?>

</body>
</html>
