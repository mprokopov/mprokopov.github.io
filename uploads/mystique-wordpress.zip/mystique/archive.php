<?php /* ATOM/digitalnature */

   // General Archive template.
   // There are quite a few templates that can override this one: http://codex.wordpress.org/Template_Hierarchy

 get_header();
?>                 

  <!-- main content: primary + sidebar(s) -->
  <div id="mask-3" class="clear-block">
   <div id="mask-2">
    <div id="mask-1">

      <!-- primary content -->
      <div id="primary-content">
       <div class="blocks clear-block">

        <?php if(is_category()): ?>
          <h1 class="title archive-category"><?php echo single_cat_title(); ?></h1>
          <?php if($desc = category_description()): ?>
          <div class="large"><p><em><?php echo $desc; ?></em></p></div>
          <div class="divider"></div>
          <?php endif; ?>

        <?php elseif(is_tag()): ?>
          <h1 class="title"><?php printf(_a('Posts tagged %s'), '<span class="alt">'.single_cat_title('', false).'</span>'); ?></h1>
        <?php elseif(is_day()): ?>
          <h1 class="title"><?php printf(_a('Archive for %s'), '<span class="alt">'.get_the_date().'</span>'); ?></h1>
        <?php elseif(is_month()): ?>
          <h1 class="title"><?php printf(_a('Archive for %s'), '<span class="alt">'.get_the_time('F, Y').'</span>'); ?></h1>
        <?php elseif(is_year()): ?>
          <h1 class="title"><?php printf(_a('Archive for year %s'), '<span class="alt">'.get_the_time('Y').'</span>'); ?></h1>
        <?php else: ?>
          <h1 class="title"><?php _ae('Blog Archives'); ?></h1>
        <?php endif; ?>    

        <?php $app->action('before_primary'); ?>

        <?php if(have_posts()): ?>
          <div class="posts clear-block">
            <?php while(have_posts()) $app->template('teaser'); ?>
          </div>

          <?php $app->pageNavi(); ?>

        <?php else: ?>

         <?php if(is_category()): ?>
          <h1 class="title"> <?php printf(_a("There aren't any posts in the %s category yet :("), single_cat_title('',false)); ?></h1>
         <?php elseif(is_date()): ?>
          <h1 class="title"> <?php _ae("There aren't any posts within this date :("); ?> </h1>
         <?php else: ?>
          <h1 class="title"><?php _ae('Nothing here :('); ?></h1>
         <?php endif; ?>

        <?php endif; ?>

        <?php $app->action('after_primary'); ?>

       </div>
      </div>
      <!-- /primary content -->

      <?php get_sidebar(); ?>
    </div>
   </div>
  </div>
  <!-- /main content -->

<?php get_footer(); ?>
