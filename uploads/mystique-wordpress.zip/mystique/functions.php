<?php

/**
 * Theme Setup.
 *
 * You can override any of the settings below from a child theme,
 * by simply calling these functions inside the child theme's functions.php file
 *
 * @package ATOM
 * @subpackage Template
 */



// theme unique ID, used as theme option name, text domain for translations, and possibly other identifiers
// make sure there are no spaces in it if you're setting your own ID inside a child theme
defined('ATOM') or define('ATOM', get_stylesheet());

// enable development mode? (loads local & uncompressed js, disables w3c validation in debug mode)
// for testing purposes only; always set this to false on a live site
defined('ATOM_DEV_MODE') or define('ATOM_DEV_MODE', (isset($_SERVER['SERVER_ADDR']) && strpos($_SERVER['SERVER_ADDR'], '127.0.0.1') !== false));

// attempt to automatically create and activate a child theme on 1st install or reset;
// if succesfull the user-functions field is enabled in the theme settings;
defined('ATOM_EXTEND') or define('ATOM_EXTEND', true);

// required WordPress version to run this theme (3.1 is the minimum for Atom-based themes)
// the check is made during the 'after_setup_theme' hook, so everything executed before this action
// should be backwards compatible as much as possible to avoid breaking the website
defined('ATOM_REQ_WP_VERSION') or define('ATOM_REQ_WP_VERSION', 3.1);

// log post views (just like wp-post-views) ?
// on a very large site this can cause server load issues since the database is updated on each page view...
defined('ATOM_LOG_VIEWS') or define('ATOM_LOG_VIEWS', true);

// compress and concatenate js with Google's Closure Compiler?
// seems to fail on certain setups...
defined('ATOM_CONCATENATE_JS') or define('ATOM_CONCATENATE_JS', false);



// the core; if you're reconfiguring Atom from a child theme, this line must be present as well
require_once TEMPLATEPATH.'/core/Atom.php';



// default (initial) theme options; not to be confused with the actual theme options stored in the database;
// by removing a key you are disabling that option from the Administration pages too
Atom::app()->setDefaultOptions(array(
  'layout'                       => 'c2right',
  'page_width'                   => 'fixed',
  'page_width_max'               => 1200,
  'dimensions_fixed_c2left'      => '320',
  'dimensions_fixed_c2right'     => '640',
  'dimensions_fixed_c3'          => '240;720',
  'dimensions_fixed_c3left'      => '240;480',
  'dimensions_fixed_c3right'     => '480;720',
  'dimensions_fluid_c2left'      => '30',
  'dimensions_fluid_c2right'     => '70',
  'dimensions_fluid_c3'          => '25;75',
  'dimensions_fluid_c3left'      => '25;50',
  'dimensions_fluid_c3right'     => '50;75',
  'color_scheme'                 => 'green',
  'favicon'                      => Atom::app()->get('theme_url').'/favicon.ico',
  'logo'                         => '',
  'background_image'             => '',
  'background_color'             => '000000',
  'background_image_selector'    => '#page',    // internal (only change if you alter the selector name in the html templates / css)
  'background_color_selector'    => 'body',     // internal, same...
  'footer_content'               => '<p> [credit] | [link rss] </p>',
  'media_rss'                    => get_bloginfo('rss2_url'),
  'media_twitter'                => 'http://twitter.com/stewiegriffin/',
  'post_title'                   => true,
  'post_date'                    => true,
  'post_date_mode'               => 'relative',
  'post_category'                => true,
  'post_tags'                    => true,
  'post_author'                  => true,
  'post_comments'                => true,
  'post_content'                 => true,
  'post_content_mode'            => 'f',
  'post_thumbs'                  => true,
  'post_thumbs_mode'             => 'left',
  'post_thumb_size'              => '90x90',
  'post_thumb_auto'              => true,
  'post_navi'                    => 'single',
  'single_links'                 => true,
  'single_meta'                  => true,
  'single_share'                 => true,
  'single_author'                => false,
  'single_related'               => true,
  'comment_filter'               => false,
  'comment_karma'                => true,
  'comment_bury_limit'           => -5,
  'widget_icon_size'             => '42x38', // internal, each theme should define its own size
  'css'                          => '',
  'jquery'                       => true,
  'effects'                      => true,
  'optimize'                     => false,
  'generate_thumbs'              => true,
  'lightbox'                     => true,
  'debug'                        => false,
  'meta_description'             => true,
  'remove_settings'              => false
));

// widget areas (sidebars)
Atom::app()->setWidgetAreas(

  array(
    'name'            => _a('Primary Sidebar'),
    'id'              => 'sidebar1',
    'description'     => _a('This is the default sidebar, active on 2 or 3 column layouts. If no widgets are visible, the page will fall back to a single column layout.'),
    'before_widget'   => '<li class="block"><div class="block-content block-%2$s clear-block" id="instance-%1$s">',
    'after_widget'    => '</div></li>',
    'before_title'    => '<div class="title"><h3>',
    'after_title'     => '</h3><div class="bl"></div><div class="br"></div></div><div class="i"></div>',

    // optional (and theme-internal):
    // if the sidebar is empty, default widgets can be added in it during theme install.
    //
    // notes (only for ATOM widgets):
    // - the settings can be left out, and the widget will use the defaults
    // - atom-tabs will be configured automatically to use all widgets set in the 'arbitrary' area below (if any)
    //'default_widgets' => array()
  ),

  array(
    'name'            => _a('Secondary Sidebar'),
    'id'              => 'sidebar2',
    'description'     => _a('This sidebar is active only on a 3 column setup, if at least one of its widgets is visible to the current user.'),
    'before_widget'   => '<li class="block"><div class="block-content block-%2$s clear-block" id="instance-%1$s">',
    'after_widget'    => '</div></li>',
    'before_title'    => '<div class="title"><h3>',
    'after_title'     => '</h3><div class="bl"></div><div class="br"></div></div><div class="i"></div>'
   ),

  array(
    'name'            => _a('Footer'),
    'id'              => 'footer1',
    'description'     => _a('Active only if at least one of its widgets is visible to the current user. You can add between 1 and 6 widgets here (3 or 4 are optimal). They will adjust their size based on the widget count.'),
    'before_widget'   => '<li class="block block-%2$s" id="instance-%1$s"><div class="block-content clear-block">',
    'after_widget'    => '</div></li>',
    'before_title'    => '<h4 class="title">',
    'after_title'     => '</h4>'
  ),

  array(
    'name'            => _a('Arbitrary Widgets'),
    'id'              => 'arbitrary',
    'description'     => sprintf(_a('Widgets from this area can be grouped into tabs, or added into posts/pages using the %1$s or %2$s shortcodes.'), '[widget ID]', '[widget Name]'),
    'before_widget'   => '<div class="block"><div class="block-content block-%2$s clear-block" id="instance-%1$s">',
    'after_widget'    => '</div></div>',
    'before_title'    => '<h3 class="title"><span>',
    'after_title'     => '</span></h3>',
  )
);

// Atom widgets to activate
Atom::app()->setActiveWidgets(
  'Archives',
  'Blogs',
  'Calendar',
  'RecentComments',
  'Links',
  'Login',
  'Menu',
  'Pages',
  'Posts',
  'Search',
  'Splitter',
  'Tabs',
  'TagCloud',
  'Terms',
  'Text',
  'TopCommenters',
  'Twitter',
  'Users'
);

// menu locations
Atom::app()->setMenus(array(
  'top'       => _a('Page Top'),
  'primary'   => _a('Below Header (Main)'),
  'footer'    => _a('Above Footer')
));

// available layout types -- @todo: finish this
Atom::app()->setLayoutTypes('c1', 'c2left', 'c2right', 'c3', 'c3left', 'c3right');

// set supported theme features ('post-formats' are not required if you're defining them below)
Atom::app()->setSupportedFeatures('post-thumbnails', 'automatic-feed-links', 'bbpress');

// other post formats besides "standard"; the theme should handle them trough CSS and/or templates
Atom::app()->addPostFormats('aside', 'gallery');




/*** Mystique-specific settings / hooks ***/

// append arrow pointers inside primary menu items
Atom::app()->addContextArgs('primary_menu', array('link_after' => '<span class="p"></span>'));

// reset settings from the database if version is older than 3.0, because none of the older settings are relevant in 3+
Atom::add('sync_options', 'mystique_remove_old_version_options');
function mystique_remove_old_version_options($old_version){
  if(version_compare($old_version, '3.0', '<')) Atom::app()->reset();
}
