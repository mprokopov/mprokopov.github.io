<?php /* ATOM/digitalnature */

  // Author Archive template.
  // author-nicename.php or author-id.php can override this one.

  get_header();
?>

  <!-- main content: primary + sidebar(s) -->
  <div id="mask-3" class="clear-block">
   <div id="mask-2">
    <div id="mask-1">

      <!-- primary content -->
      <div id="primary-content">
       <div class="blocks clear-block">

        <?php $app->action("before_primary"); ?>

        <div class="clear-block">

          <div class="alignleft">
            <?php $app->author->Avatar($size = 192); ?>
          </div>

          <h1 class="title"><?php $app->author->Name(); ?></h1>

          <div class="summary">
            <?php if($app->author->getKarma()): ?>
            <h4><?php printf(_a("%s karma"), $app->author->getKarma()); ?></h4>
            <?php endif; ?>
            <p><?php printf(_a('(%1$s comments, %2$s posts)'), $app->getCount($app->author->getID(), 'comment'), $app->getCount($app->author->getID(), 'post')); ?></p>
          </div>


          <?php if($app->author->getDescription()): ?>
          <div class="author-description large">
            <?php $app->author->Description(); ?>
          </div>

          <?php else: ?>
          <p class="large"><em><?php _ae("This user hasn't shared any profile information"); ?></em></p>
          <?php endif; ?>


          <?php if(($app->author->get('user_url')) && ($app->author->get('user_url')!== 'http://')): ?>
          <p class="im www">
            <?php _ae('Home page:'); ?> <a href="<?php echo $app->author->get('user_url'); ?>"><?php echo $app->author->get('user_url'); ?></a>
          </p>
          <?php endif; ?>

          <?php if($app->author->get('yim')): ?>
          <p class="im yahoo">
            Yahoo Messenger: <a href="ymsgr:sendIM?<?php echo $app->author->get('yim'); ?>"><?php echo $app->author->get('yim'); ?></a>
          </p>
          <?php endif; ?>

          <?php if($app->author->get('jabber')): ?>
          <p class="im gtalk">
            Jabber/GTalk: <a href="gtalk:chat?jid=<?php echo $app->author->get('jabber'); ?>"><?php echo $app->author->get('jabber'); ?></a>
          </p>
          <?php endif; ?>

          <?php if($app->author->get('aim')): ?>
          <p class="im aim">
            AIM: <a href="aim:goIM?screenname=<?php echo $app->author->get('aim'); ?>"><?php echo $app->author->get('aim'); ?></a>
          </p>
          <?php endif; ?>

        </div>

        <div class="divider"></div>

        <?php if(have_posts()): ?>
          <h5 class="title"><?php printf(_a('Posts by %s'), $app->author->getName()); ?></h5>

          <div class="posts clear-block">
            <?php while(have_posts()) $app->template('teaser'); ?>
          </div>

          <?php $app->pageNavi(); ?>

          <a class="rss-block alignright" rel="rss" href="<?php $app->author->FeedURL(); ?>"><?php printf(_a("%s's RSS Feed"), $app->author->getName()); ?></a>

        <?php else: ?>
          <p><?php printf(_a("%s hasn't written any posts yet"), $app->author->getName()); ?></p>
        <?php endif; ?>

        <?php $app->action("after_primary"); ?>

       </div>
      </div>
      <!-- /primary content -->

      <?php get_sidebar(); ?>
    </div>
   </div>
  </div>
  <!-- /main content -->

<?php get_footer(); ?>
