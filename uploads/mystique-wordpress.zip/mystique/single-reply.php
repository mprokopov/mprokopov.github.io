<?php /* ATOM/digitalnature */

 //  Singular template, usually used to display a single post.
 //  For custom post types, a template named single-post_type.php will have priority over this one.

 get_header();
?>

<!-- main content: primary + sidebar(s) -->
<div id="mask-3" class="clear-block">
  <div id="mask-2">
    <div id="mask-1">

      <!-- primary content -->
      <div id="primary-content">
        <div class="blocks clear-block">

        <?php $app->action('before_primary'); ?>

        <?php do_action('bbp_template_notices'); ?>

          <div class="posts clear-block">

            <?php
              while(have_posts()):
                the_post(); ?>

                <div id="bbp-reply-wrapper-<?php bbp_reply_id(); ?>" class="bbp-reply-wrapper">
                  <h1 class="title"><?php bbp_reply_title(); ?></h1>

                  <?php bbp_breadcrumb(); ?>

                  <div class="entry-content">

                    <table class="bbp-replies" id="topic-<?php bbp_topic_id(); ?>-replies">
                      <thead>
                        <tr>
                          <th class="bbp-reply-author"><?php  _ae('Author'); ?></th>
                          <th class="bbp-reply-content"><?php _ae('Replies'); ?></th>
                        </tr>
                      </thead>

                      <tfoot>
                        <tr>
                          <td colspan="2"><?php bbp_topic_admin_links(); ?></td>
                        </tr>
                      </tfoot>

                      <tbody>
                        <tr class="bbp-reply-header">
                          <td class="bbp-reply-author">
                            <?php bbp_reply_author_display_name(); ?>
                          </td>
                          <td class="bbp-reply-content">
                            <a href="<?php bbp_reply_url(); ?>" title="<?php bbp_reply_title(); ?>">#</a>
                            <?php printf(_a( 'Posted on %1$s at %2$s'), get_the_date(), esc_attr(get_the_time())); ?>
                            <span><?php bbp_reply_admin_links(); ?></span>
                          </td>
                        </tr>

                        <tr id="reply-<?php bbp_reply_id(); ?>" <?php bbp_reply_class(); ?>>
                          <td class="bbp-reply-author"><?php bbp_reply_author_link(array('type' => 'avatar')); ?></td>
                          <td class="bbp-reply-content"><?php bbp_reply_content(); ?> </td>
                        </tr>
                      </tbody>
                    </table>

                  </div>
                </div>

              <?php endwhile; ?>

          </div>

          <?php $app->action('after_primary'); ?>

        </div>
      </div>
      <!-- /primary content -->

      <?php get_sidebar(); ?>

    </div>
  </div>
</div>
<!-- /main content -->

<?php get_footer(); ?>
