<?php /* ATOM/digitalnature */

   // General Archive template.
   // There are quite a few templates that can override this one: http://codex.wordpress.org/Template_Hierarchy

 get_header();
?>

<!-- main content: primary + sidebar(s) -->
<div id="mask-3" class="clear-block">
  <div id="mask-2">
    <div id="mask-1">

      <!-- primary content -->
      <div id="primary-content">
        <div class="blocks clear-block">

          <?php do_action('bbp_template_notices'); ?>

          <h1 class="title"><?php bbp_forum_archive_title(); ?></h1>

          <?php

            $app->action('before_primary');
            bbp_breadcrumb();
            do_action('bbp_template_before_forums_index');

            if(bbp_has_forums())
              bbp_get_template_part('bbpress/loop', 'forums');

            else
              _ae('There are no forums here yet :(');


            do_action('bbp_template_after_forums_index');
            $app->action('after_primary');
          ?>

        </div>
      </div>
      <!-- /primary content -->

      <?php get_sidebar(); ?>
    </div>
  </div>
</div>
<!-- /main content -->

<?php get_footer(); ?>
