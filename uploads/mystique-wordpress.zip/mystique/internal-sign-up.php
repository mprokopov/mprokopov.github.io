<?php
/*
  Mystique/digitalnature

  This file demonstrates the usage of internal pages, with an user sign-up page.

  It can also be done within page templates applied to pages, but it might be a better idea to not store such type of pages
  in the database like posts...

*/
?>


<?php

  // since this page doesn't reside in the db, we manually set a title for it; this is requried
  $app->setDocumentTitle('Sign-up');

  // check if user registration is allowed
  if(!get_option('users_can_register')) wp_die(_a('User registration is currently not allowed.'));

  // check if the form was submitted, and create the user if data was posted
  if($app->request('sign-up')){

    $errors = new WP_Error();
    
    $sanitized_user_login = sanitize_user($_POST['user']);
    $user_email = apply_filters('user_registration_email', $_POST['email']);


    if($sanitized_user_login == ''){
      $errors->add('empty_username', _a('You left the user name field empty.'));

    }elseif(!validate_username($_POST['user'])){
      $errors->add('invalid_username', _a('Invalid user name, illegal characters.'));
      $sanitized_user_login = '';

    }elseif(username_exists($sanitized_user_login)){
      $errors->add('username_exists', _a('User name already registered, choose another.'));
    }

    // Check the e-mail address
    if($user_email == ''){
      $errors->add('empty_email', _a('You left the e-mail field empty.'));

    }elseif(!is_email($user_email)){
      $errors->add('invalid_email', _a('Invalid e-mail address.'));
      $user_email = '';

    }elseif(email_exists($user_email)){
      $errors->add('email_exists', _a('This email is already registered, please choose another one.'));
    }

    do_action('register_post', $sanitized_user_login, $user_email, $errors);
    $errors = apply_filters('registration_errors', $errors, $sanitized_user_login, $user_email);

    if($errors->get_error_code())
       wp_die('<h1>'._a('Registration Failed.').' <a href="#" onclick="window.history.back();">'._a('Go back and try again?').'</a></h1><ul><li>'.str_replace('<strong>ERROR</strong>:', '', implode('</li><li>', $errors->get_error_messages())).'</li></ul>');

    $user_pass = wp_generate_password( 12, false);
    $created_user = wp_create_user( $sanitized_user_login, $user_pass, $user_email );

    if(!$created_user){
      // single error message
      $errors->add('registerfail', sprintf(_a('Registration failed, please contact the <a href="mailto:%s">webmaster</a>'), get_option('admin_email')));
      wp_die($errors->get_error_messages());
    }

    update_user_option($created_user, 'default_password_nag', true, true); // set up the Password change nag.
    wp_new_user_notification($created_user, $user_pass);
  }

  get_header();
?>

  <!-- main content: primary + sidebar(s) -->
  <div id="mask-3" class="clear-block">
   <div id="mask-2">
    <div id="mask-1">
             
      <!-- primary content -->
      <div id="primary-content">
       <div class="blocks clear-block">

        <?php $app->action('before_primary'); ?>
         <h1 class="title"><?php printf(_a('Sign-up on %s'), sprintf('<span class="alt">%s</span>', get_bloginfo('name'))); ?></h1>

         <?php if(empty($created_user)): ?>
         <form action="<?php $app->pageURL('sign-up'); ?>" method="POST">

           <p>
             <label for="user"><?php _ae('Desired user name'); ?></label>
             <input id="user" name="user" size="30" type="text" class="big" />
           </p>

           <p>
             <label for="email"><?php _ae('E-mail address'); ?></label>
             <input id="email" name="email" size="30" type="text" class="big" />
           </p>

           <?php do_action('register_form'); // for compat with plugins, like captchas ?>

           <p>
             <input type="hidden" name="atom" value="sign-up" />
             <input type="submit" value="<?php _ae('Sign up'); ?>" />
           </p>
         </form>

         <?php else: ?>
         <p class="success">
           <?php _ae('Thank you. Your password has been e-mailed to you.'); ?>
         </p>
         <?php endif ;?>

        <?php $app->action('after_primary'); ?>

       </div>
      </div>
      <!-- /primary content -->

      <?php get_sidebar(); ?>
    </div>
   </div>
  </div>
  <!-- /main content -->

<?php get_footer(); ?>
