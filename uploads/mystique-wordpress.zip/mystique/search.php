<?php /* ATOM/digitalnature */

   // The Search template, shown when a search is performed on the site.
   // Uses the teaser template to render the results

 get_header();
?>

  <!-- main content: primary + sidebar(s) -->
  <div id="mask-3" class="clear-block">
   <div id="mask-2">
    <div id="mask-1">

      <!-- primary content -->
      <div id="primary-content">
       <div class="blocks clear-block">

        <?php $app->action("before_primary"); ?>

        <?php if(have_posts()): ?>

          <h1 class="title">
            <?php
              printf(_a('Search results for %1$s (%2$s)'),
                sprintf('<span class="alt">%s</span>', get_search_query()),
                $GLOBALS['wp_query']->found_posts
              );
            ?>
          </h1>

          <?php if($app->options('post_navi') !== 'single'): ?>
            <div class="clear-block">
              <?php $app->pageNavi(array('class' => 'alignright')); ?>
            </div>
          <?php endif; ?>

          <div class="divider"></div>

          <div class="posts clear-block">
            <?php while(have_posts()) $app->template('teaser'); ?>
          </div>

          <?php $app->pageNavi(); ?>

        <?php else: ?>
          <h1 class="title"><?php _ae("Nothing found :("); ?></h1>
          <p class="large"><em><?php _ae("Try a different search..."); ?></em></p>
        <?php endif; ?>

        <?php $app->action("after_primary"); ?>

       </div>
      </div>
      <!-- /primary content -->

      <?php get_sidebar(); ?>

    </div>
   </div>
  </div>
  <!-- /main content -->

<?php get_footer(); ?>
