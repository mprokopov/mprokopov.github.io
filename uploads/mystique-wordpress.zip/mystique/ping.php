<?php /* ATOM/digitalnature */

   // Renders ping/trackback comment types.
   // Pings are handled within the meta.php template.
   // The "screenshot" class will enable a link preview on mouse over

?>

<!-- ping/trackback entry -->
<li>
  <a class="screenshot" id="ping-<?php comment_ID(); ?>" href="<?php comment_author_url();?>" rel="nofollow"><?php comment_author(); ?></a>

<?php // </li> is added by WP ?>