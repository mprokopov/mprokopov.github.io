

Project page:
http://digitalnature.eu/projects/mystique

Licensed under GPL
http://www.opensource.org/licenses/gpl-license.php



CREDITS:

- digitalnature - http://digitalnature.eu (design and coding)
- WordPress - http://wordpress.org
- jQuery - http://jquery.com
- Fancybox by Janis Skarnelis - http://fancybox.net
- clearfield by Stijn Van Minnebruggen - http://www.donotfold.be
- jQuery Color picker plugin by eyecon.ro
- Justin Tadlock - http://justintadlock.com/archives/2009/05/09/using-shortcodes-to-show-members-only-content
- CodeMirror javascript library - http://marijn.haverbeke.nl/codemirror
- IP2Country by Omry Yadan - http://firestats.cc/wiki/ip2c
- IP2C database by Webhosting.info
- wp_pagenavi plugin - http://wordpress.org/extend/plugins/wp-pagenavi



REQUIREMENTS:

- PHP 5.2+
- Wordpress 3.2+



CHANGE LOG:

25, 8,2011,  3.1       - added bbPress support (basic)
                       - added "Tags" internal page
                       - disabled script concatenation, you can enable it by defining the ATOM_CONCATENATE_JS as true from your child theme
                       - widget / login: changed the register link to point to the "Sign-up" internal page
                       - new module: Translate
                       - removed en_US.po, and added a pot template
                       - improved language listing in the settings
                       - widget / twitter: corrected tweet date format
                       - fixed problem with sub-categories
                       - added Russian Translation, tx Philip
                       - mod / photo gallery: image links will now open inside the lightbox if the option is enabled
                       - mod / photo gallery: added location argument (theme action in which to show the gallery, default is 'before_main')

20, 8,2011,  3.0.9     - fixed localization issues with strings defined before the after_setup_theme hook
                       - translations can now be also dropped in the child theme "lang" folder (they will have higher priority)
                       - mod / featured gallery: completed (and renamed to "Photo gallery")

19, 8,2011,  3.0.8.1   - moved cached js in <head> so it doesn't break arbitrary javascript added by plugins

19, 8,2011,  3.0.8     - added Bengali translation, tx Shaikat77
                       - removed head.js, and made so scripts are compressed and concatenated
                         with Google's Closure Compiler service
                       - widget / twitter: changed cache option from select to input
                       - some SE optimizations (made the 'index' rel attribute point to relevant pages on archives,
                         single CPTs, custom blog page)
                       - fixed issue from 3.0.7 with clearFieldCheck (unfilled input fields not clearing on submit)
                       - fixed a CSS issue with splitters
                       - fixed small issue in theme settings / content options (media thumbnail size wasn't being displayed)
                       - added template argument to post->getTerms()
                       - fixed localization issue with role names and module variables set inside their init() method
                       - mod / social media icons: removed support for the WP SmushIt plugin

14, 8,2011,  3.0.7     - mod / social media icons: added persistent cache for label/uri fields
                       - fixed ugly bug introduced in 3.0.6 in get/add/setContextArgs()
                       - replaced non-standard rel attributes with html5 data attributes

14, 8,2011,  3.0.6     - reduced design image sizes by 3-4% and removed some images that weren't used
                       - fixed another bug in the [query] shortcode (template argument wasn't working correctly)
                       - updated French translation, tx Pierre
                       - added new module: Social-Media Icons (will replace old media links); @todo: add default labels/URLs
                       - fixed a graphic glitch in the search template

12, 8,2011,  3.0.5     - added French, Italian & Spanish translations, tx to Jonathan, Marco & Antonio
                       - added an internal page sample: user sign-up
                       - fixed pings not showing
                       - fixed a bug in the [query] shortcode
                       - tabs can be now activated by the location hash
                       - moved wp_footer() inside the #footer element because some plugins add HTML in it,
                         and it wasn't getting styled...
                       - made so "Home"-named custom menu items are styled with the home icon, like default menus
                       - widget / recent comments: fixed a bug with the comment date
                       - widget / posts: fixed wrong order-by-views
                       - widget / tabs: added "cat-ID" class for the Posts widget (category ID)
                       - mod / featured gallery: removed the "Tile Wave" gallery effect, not cool enough
                       - decreased spacing between menu entries
                       - temporarily disabled search query highlighting until I find a way to accurately handle any HTML

 8, 8,2011,  3.0.4     - added German and Dutch translations, tx to DotTobi, Blackstarwolf and Raymon
                       - added grey & red color schemes
                       - added error handler for the Design settings; if your site has errors you'll be notified on that page :)
                       - updates to the image uploader (GIFs are now allowed, but you should really avoid this format)
                       - fixed a notice in the [widget] shortcode
                       - fixed a bug in the [subs] shortcode
                       - removed 404 styles, it's now a normal page
                       - tabs are now sorted correctly in the front-end

 7, 8,2011,  3.0.3     - fixed a couple of small issues reported by theme users
                       - child theme style.css is now included after the parent styles

 5, 8,2011,  3.0.2     - fixed nasty bug in functions.php that caused full option reset
                         on any version change (should have been just < 3.0)

20, 5,2011,  3.0       - code rewrite, using Atom's codebase (beware - 2.x theme settings are reset)

...

3, 10.2009: First release (1.0)
