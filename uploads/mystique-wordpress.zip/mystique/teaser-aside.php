<?php /* ATOM/digitalnature */

   // Aside post teaser template.
   // see teaser.php for more details...

  ?>

  <!-- post format:aside -->
  <div id="post-<?php the_ID(); ?>" <?php post_class('clear-block'); ?>>

    <?php if($app->options('post_date')): ?>
      <p><strong><?php $app->post->date(); ?></strong></p>
    <?php endif; ?>

    <?php the_content(); ?>
    <?php $app->controls('post-edit'); ?>
  </div>
  <!-- /post -->
