<?php /* ATOM/digitalnature */

 //  Singular template, usually used to display a single post.
 //  For custom post types, a template named single-post_type.php will have priority over this one.

 get_header();
?>

<!-- main content: primary + sidebar(s) -->
<div id="mask-3" class="clear-block">
  <div id="mask-2">
    <div id="mask-1">

      <!-- primary content -->
      <div id="primary-content">
        <div class="blocks clear-block">

          <?php $app->action('before_primary'); ?>

          <?php while(have_posts()) the_post(); ?>

          <h1 class="title"><?php the_title(); ?></h1>

          <?php bbp_get_template_part('bbpress/form', 'topic'); ?>

          <?php $app->action('after_primary'); ?>

        </div>
      </div>
      <!-- /primary content -->

      <?php get_sidebar(); ?>

    </div>
  </div>
</div>
<!-- /main content -->

<?php get_footer(); ?>
