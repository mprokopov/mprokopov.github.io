<?php /* ATOM/digitalnature */

   // This template is a nicer alternative to the comment_form() and atom_comment_form() functions.


  global $user_identity, $allowedtags;
  ksort($allowedtags);

  // get allowed tags
  $allowed = '';
  foreach($allowedtags as $tag => $attributes)
    $allowed .= '<code>'.htmlentities("<{$tag}>").'</code> ';

?>

<!-- comment form -->
<div class="comment new <?php if(get_option('show_avatars')) echo 'with-avatars'; ?>">

  <?php

  $labels = array(
    'author' => _a('Name').(get_option('require_name_email') ? " "._a("(required)") : ''),
    'email' => _a('E-mail').(get_option('require_name_email') ? " "._a("(required, will not be published)") : _a("(will not be published)")),
    'url' => _a('Website'),
  );

  // to keep compatibility with plugins
  $fields = array(
    'author' => (!$app->options('jquery') ? '<label for="author">'.$labels['author'].'</label> ' : '').'<input type="text" data-default="'.$labels['author'].'" name="author" id="author" class="validate required text clearField" value="'.esc_attr($app->commenter['comment_author']).'" size="40" />',
    'email'  => (!$app->options('jquery') ? '<label for="email">'.$labels['email'].'</label> ' : '').'<input type="text" data-default="'.$labels['email'].'" name="email" id="email" class="validate required text clearField" value="'.esc_attr($app->commenter['comment_author_email']).'" size="40" />',
    'url'    => (!$app->options('jquery') ? '<label for="url">'.$labels['url'].'</label> ' : '').'<input type="text" data-default="'.$labels['url'].'" name="url" id="url" class="validate required text clearField" value="'.esc_attr($app->commenter['comment_author_url']).'" size="40" />',
  );

  ?>

  <?php if(comments_open()): ?>
  <?php do_action('comment_form_before'); ?>
  <div id="respond">

    <?php if(get_option('comment_registration') && !is_user_logged_in()) : ?>
      <div class="error box"><?php sprintf(__('You must be <a href="%s">logged in</a> to post a comment.'), wp_login_url(apply_filters('the_permalink', get_permalink()))); ?></div>
    <?php do_action('comment_form_must_log_in_after'); ?>
    <?php else: ?>
     <form action="<?php echo site_url('/wp-comments-post.php'); ?>" method="post" id="commentform">

      <?php do_action('comment_form_top'); ?>

      <?php if(get_option('show_avatars')): ?>
      <div class="avatar">
        <?php echo $app->getAvatar($app->commenter['comment_author_email'], 48, false, $app->commenter['comment_author']);  ?>
      </div>
      <?php endif; ?>

      <div class="comment-head">
        <div class="ext clear-block">
        <?php if(is_user_logged_in()): ?>

           <?php printf(_a('Logged in as %s.'), '<a href="'.admin_url('profile.php').'">'.$user_identity.'</a>'); ?>
           <a href="<?php echo wp_logout_url(apply_filters('the_permalink', get_permalink())); ?>" title="<?php _ae('Log out of this account'); ?>"><?php _ae('Log out?'); ?></a>

        <?php else: ?>

           <?php if(!empty($app->commenter['comment_author'])): // existing visitor ?>

             <?php printf(_a('Welcome back %s.'), "<strong>{$app->commenter['comment_author']}</strong>"); ?>
             <?php if($app->options('jquery')): ?>
               <a href="#" class="toggle" data-target="comment-fields"><?php _ae('Change &raquo;'); ?></a>
             <?php endif; ?>

           <?php else: // new visitor ?>

           <?php endif; ?>

           <?php do_action('comment_form_before_fields'); ?>
           <div id="comment-fields" <?php if(!empty($app->commenter['comment_author']) && $app->options('jquery')) echo 'class="hidden"'; ?>>

           <?php foreach(apply_filters('comment_form_default_fields', $fields) as $name => $field): ?>
             <div class="row">
               <?php echo apply_filters("comment_form_field_{$name}", $field); ?>
             </div>
           <?php endforeach; ?>

           <?php do_action('comment_form_after_fields'); ?>
           </div>

        <?php endif; ?>
        </div>
      </div>

      <div class="comment-body">

         <!-- comment field -->
         <div class="comment-content clear-block">

             <!-- comment input -->
             <div class="row">
               <label for="comment"><?php _ae("Type your comment"); ?></label>
               <textarea name="comment" id="comment" class="validate required" rows="8" cols="50"></textarea>
             </div>
             <!-- /comment input -->

             <p class="form-allowed-tags">
               <?php printf(_a('You may use these %1$s tags: %2$s'), '<abbr title="HyperText Markup Language">HTML</abbr>', $allowed) ;?>
             </p>

             <div class="clear-block">
               <?php comment_id_fields(); ?>
               <?php do_action('comment_form', get_the_ID()); ?>
               <input type="hidden" name="redirect_to" value="<?php $app->commentPostRedirectURL(); ?>" />
             </div>

             <!-- comment submit and rss -->
             <div class="clear-block">
               <input name="submit" type="submit" id="submit" class="button alignleft" value="<?php _ae('Post Comment') ?>" />
               <?php if(is_singular() && get_option('thread_comments') && $app->options('jquery')): ?>
               <input name="cancel-reply" type="submit" id="cancel-reply" class="button alignleft hidden" value="<?php _ae('Cancel reply') ?>" />
               <?php endif; ?>
             </div>

         </div>
         <!-- comment field -->

      </div>
     </form>
    <?php endif; ?>
  </div>
  <?php do_action('comment_form_after'); ?>

  <?php else : ?>
    <div class="error box"><?php _ae('Comments are closed'); ?></div>
  <?php endif; ?>

</div>
<!-- /comment-form -->