<?php /* ATOM/digitalnature */

   // The template for the "page" post type. It acts for pages just like single.php does for posts
   // pagename.php, page-slug.php or page-id.php can override it.

 get_header();
?>

  <!-- main content: primary + sidebar(s) -->
  <div id="mask-3" class="clear-block">
   <div id="mask-2">
    <div id="mask-1">

      <!-- primary content -->
      <div id="primary-content">
       <div class="blocks clear-block">

         <h1 class="title">404</h1>

         <?php $app->action('before_primary'); ?>

         <p><?php _ae('The requested page was not found.'); ?></p>

         <?php $app->action('after_primary'); ?>

       </div>
      </div>
      <!-- /primary content -->

    </div>
   </div>
  </div>
  <!-- /main content -->

<?php get_footer(); ?>
