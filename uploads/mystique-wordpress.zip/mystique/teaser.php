<?php /* ATOM/digitalnature */

   // This is a generic template that styles post teasers on homepage and archive pages (or all pages except those of "singular" type).
   //
   // Priority (highest to lowest):
   //
   //   - teaser-ID.php
   //   - teaser-postType-postFormat.php
   //   - teaser-postType.php
   //   - teaser-postFormat.php
   //   - teaser.php

   // Notes:
   //
   // 1) To avoid typical global-scope problems, WP global variables are not initialized by default inside this template ($post, $wp_query etc.)
   //    The only initialized variable meant to be used here is $app (a reference to Atom::app());
   //
   // 2) The $app->post methods are not required, you can choose to use default WP functions instead. Atom methods are more flexible, and theoretically faster...
   //
   // 3) Notice the difference between getMethod() and Method().
   //    The first one will return the value, while the second one will output the value to the screen
   //
   // 4) In case you're writing your own template inside a child theme, you don't have to do any option checks, just choose to display what you want.
   //    That's the purpose of creating and using a child theme...


  ?>

  <?php if($app->options('post_title', 'post_date', 'post_category', 'post_tags', 'post_author', 'post_comments', 'post_content') === FALSE && $app->options('post_thumbs')): ?>

  <!-- post -->
  <div id="post-<?php the_ID(); ?>" <?php post_class('thumb-only'); ?>>
    <a class="post-thumb tt" id="thumb-<?php the_ID(); ?>" href="<?php $app->post->URL(); ?>" title="<?php $app->post->title(); ?>">
      <?php $app->post->thumbnail(); ?>
    </a>
  </div>
  <!-- /post -->

  <?php else: ?>

  <!-- post -->
  <div id="post-<?php the_ID(); ?>" <?php post_class('clear-block'); ?>>

    <div class="post-details">
      <?php if(!(is_sticky() && is_home()) && $app->options('post_thumbs')): ?>
      <a class="post-thumb" id="thumb-<?php the_ID(); ?>" href="<?php $app->post->URL(); ?>" title="<?php $app->post->title(); ?>">
        <?php $app->post->thumbnail(); ?>
      </a>
     <?php endif; ?>

      <?php if($app->options('post_title')): ?>
      <h2 class="title">
        <a href="<?php $app->post->URL(); ?>" rel="bookmark" title="<?php sprintf(_a('Permanent Link: %s'), $app->post->getTitle()); ?>"><?php $app->post->title(); ?></a>
      </h2>
      <?php endif; ?>

      <?php if($app->options('post_comments') && comments_open()): ?>
      <a class="comments" href="<?php $app->post->URL(); ?>#comments"><?php $app->post->commentCount(); ?></a>
      <?php endif; ?>

      <?php if(($app->options('post_date') || $app->options('post_category') || $app->options('post_author') || $app->options('post_comments')) && !(is_sticky() && is_home())): ?>
      <div class="post-std clear-block">
        <?php if($app->options('post_date')): ?>
        <div class="post-date"><span class="ext"><?php $app->post->date(); ?></span></div>
        <?php else: ?>
        <span class="ext"></span>
        <?php endif; ?>
        <div class="post-info">

          <?php if($app->options('post_author')): ?>
            <span class="a"><?php printf(_a('by %s'), $app->post->author->getNameAsLink()); ?></span>
          <?php endif; ?>

          <?php if($app->options('post_category') && $app->post->getTerms('category')): ?>
            <?php printf(_a('in %s'), $app->post->getTerms('category', ', ')); ?>
          <?php endif; ?>

          <?php //printf(' | '._an('%s view', '%s views', $app->post->getViews()), number_format_i18n($app->post->getViews())); ?>

        </div>
      </div>
      <?php endif; ?>

      <div class="post-content clear-block">
        <?php (is_sticky() && is_home()) ? the_content() : $app->post->content(); ?>
      </div>

      <?php if($app->options('post_tags') && $app->post->getTerms()): ?>
      <div class="post-extra">
         <div class="post-tags"> <?php $app->post->terms(); ?> </div>
      </div>
      <?php endif; ?>

    </div>

    <?php $app->controls('post-edit'); ?>
  </div>
  <!-- /post -->

  <?php endif; ?>


