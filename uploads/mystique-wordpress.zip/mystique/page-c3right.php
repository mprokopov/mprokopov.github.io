<?php /* ATOM/digitalnature

 Template Name: 3 column page (sidebars on the right)
 */
 
 include(TEMPLATEPATH . '/page.php');
 // exactly the same as page.php (only file name is needed for the check)
?>
